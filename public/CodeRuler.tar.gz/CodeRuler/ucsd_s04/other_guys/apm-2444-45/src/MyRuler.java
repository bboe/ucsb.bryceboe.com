import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */

public class MyRuler extends Ruler {

	protected Random rand = new Random();
	int pMove[] = new int[1023];
	int x;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "FerretBot";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 45";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		int direction = 2;
		x = 0;
		for(int i = 0; i < pMove.length; i++)
		{
			pMove[i] = rand.nextInt(8) + 1;
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		System.out.println("Timeout of:" + lastMoveTime + " on Current turn:" + World.getCurrentTurn());
		// put implementation here
		int moveTo;
		int size, i;
		int xx, yy;
		IKnight[] knights = getKnights();
		size = knights.length;
		
		ICastle[] castles = getCastles();
		size = castles.length;
		for(int a = 0; a < size; a++)
		{
			if(World.getCurrentTurn() < 40)
			{
				createKnights(castles[a]);
			}
			else
			{
				if(knights.length < (int)(World.getCurrentTurn() / 20 ) + 20 )
					createKnights(castles[a]);
				else
					createPeasants(castles[a]);
			}
		}
		IKnight[] enemies = World.getOtherKnights();
		int id = 0, d = 50000;
		for(int b = 0; b < enemies.length; b++)
		{
			if(getCastles()[0].getDistanceTo(enemies[b].getX(), enemies[b].getY()) < d)
			{
				id = b;
				d = getCastles()[0].getDistanceTo(enemies[b].getX(), enemies[b].getY());
			}
		}

		moveTo = 0;
		size = knights.length;
		for(i = 0; i < size; i++)
		{
			if(World.getCurrentTurn() < 10)
			{
				if(enemies.length == 0)
				{
					move(knights[i], rand.nextInt(8) + 1);					
				}
				else
				{
					if(World.getCurrentTurn() % 3 == 0)
						move(knights[i], rand.nextInt(8) + 1);
					else
						move(knights[i], knights[i].getDirectionTo( (enemies[id]).getX(), 
																(enemies[id]).getY() ));
				}
			}
			else
			{ 
				if(i%4 <= 1 && (World.getOtherCastles().length != 0))
				{
					move(knights[i], knights[i].getDirectionTo( (World.getOtherCastles()[0]).getX(), 
														(World.getOtherCastles()[0]).getY()));
					knightCapture(knights[i]);	
				}
				else if (i%4 <= 3 && (World.getOtherKnights().length != 0))
				{
					move(knights[i], knights[i].getDirectionTo( (World.getOtherKnights()[0]).getX(), 
															(World.getOtherKnights()[0]).getY() ));
					knightCapture(knights[i]);	
				}
				else if((World.getOtherPeasants().length != 0))
				{
					move(knights[i], knights[i].getDirectionTo( (World.getOtherPeasants()[0]).getX(), 
															(World.getOtherPeasants()[0]).getY() ));
					knightCapture(knights[i]);	
				}
				else
				{
					move(knights[i], rand.nextInt(8) + 1);
					knightCapture(knights[i]);	
				}						
			}
		}
	
		IPeasant[] peasants = getPeasants();
		size = peasants.length;
		moveTo = 0;
		xx = 0;
		yy = 0;
		for (i = 0; i < size; i++) {
			switch(pMove[i])
			{
				case 1: yy = -1; break;
				case 2: yy = -1; xx = 1; break;
				case 3: xx = 1; break;
				case 4: xx = 1; yy = 1; break;
				case 5: yy = 1; break;
				case 6: yy = 1; xx = -1; break;
				case 7: xx = -1; break;
				case 8: yy = -1; xx = -1; break;
				default: xx = 0; yy = 0; break;
			}
			if((peasants[i].getX() + xx) > 71)
			{
				System.out.println("(peasants[i].getX() + xx) >= 72");
				pMove[i] = 6;
				/*switch(pMove[i])
				{
					case 2: pMove[i] = 6;
					case 4: pMove[i] = 6;
				}*/
			}
			else if((peasants[i].getX() + xx) < 0)
			{
				System.out.println("(peasants[i].getX() + xx) < 0");
				pMove[i] = 2;
				/*switch(pMove[i])
				{
					case 6: pMove[i] = 2;
					case 8: pMove[i] = 2;
				}*/
			}
			if((peasants[i].getY() + yy) > 63)
			{
				System.out.println("(peasants[i].getY() + yy) >= 63");
				pMove[i] = 8;
				/*switch(pMove[i])
				{
					case 6: pMove[i] = 8;
					case 4: pMove[i] = 8;
				}*/
			}
			else if((peasants[i].getY() + yy) < 0)
			{
				System.out.println("(peasants[i].getY() + yy) < 0");
				pMove[i] = 4;
				/*switch(pMove[i])
				{
					case 2: pMove[i] = 4;
					case 8: pMove[i] = 4;
				}*/
			}

			if(World.getCurrentTurn() < 12)
			{
				if(World.getCurrentTurn() % 2 == 1)
					move(peasants[i], pMove[i]);
				else
					move(peasants[i], rand.nextInt(8) + 1);		
			}
			else if(World.getCurrentTurn() < 120)
			{
				int asdf = 0;
				if(i % 5 == 0 && (World.getOtherPeasants().length >= 2))
				{
					move(peasants[i], peasants[i].getDirectionTo(World.getOtherPeasants()[asdf].getX(), 
										World.getOtherPeasants()[asdf].getY()) );
					asdf++;
				}
				if(World.getCurrentTurn() % 5 == 0)
				{
					System.out.print("R");
					move(peasants[i], rand.nextInt(8) + 1);
				}
				else
				{
					if( (World.getCurrentTurn() % 20 == 0) && (i % (x%2 + 1) == 0) )
					{
						pMove[i] = (pMove[i]  + (rand.nextInt(8)*2) ) % 8;
						x++;
					}
					System.out.print("D" + pMove[i]);
					move(peasants[i], pMove[i]);
				}		
			}
			else
			{
				move(peasants[i], rand.nextInt(8) + 1);
			}
			if(peasants.length >= 3 && knights.length >= 2)
			{
				move(peasants[1], peasants[1].getDirectionTo(knights[0].getX(), knights[0].getY()));
				move(peasants[2], peasants[2].getDirectionTo(knights[1].getX(), knights[1].getY()));
			}
		}
	}
	
	public boolean knightCapture(IKnight knight)
	{
		for (int i = 1; i < 9; i++) {
				//find the position
				Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
				
				//make sure the position is valid mo
				if(np != null) 
				{
					IObject object = World.getObjectAt(np.x, np.y);
					if(object != null && !object.getRuler().equals(knight.getRuler()))
					{
						capture(knight,i);
						return true;
					}
				}
		}
		return false;
	}
	
	public void moveAndCapture(IKnight knight, IPeasant peasant)
	{
		//return if the peasant is null or has already been captured
		if(peasant == null || !peasant.isAlive())
			return;
		
		//find the next position in the direction of the peasant
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if(np != null) 
		{
			// if the peasant is in the adjacent square, capture it. Otherwise, try to keep moving
			if (peasant.equals(World.getObjectAt(np.x,np.y)))
				capture(knight, dir);
			else
				move(knight, dir);				
		}
	}
	
}