import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public IPeasant[] pes;
	public IKnight[] knights;
	public ICastle[] castles;
	public IObject object;
	int wherex, myFlag;
	int wherey;
	static int X_AXIS = 72;
	static int Y_AXIS = 64;
			 
	public String getRulerName() {
		return "Core Dumps";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 5";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		pes = getPeasants();
		knights = getKnights();
		castles = getCastles();
		setFlag( 0 );
		
			
		//System.out.println(object.getX());
		//wherey = object.getY();
		
		//System.out.println(wherex + ":" + wherey);
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		Random rand = new Random();
		System.out.println("blah");
		//int flag = getFlag();
		int savePos = 0;
			
			for( int i = 0; i < pes.length; i++){
				int xPos = pes[i].getX();
				int yPos = pes[i].getY();
				
				//System.out.println( "flag " + myFlag );
				if( yPos < Y_AXIS/2 && xPos < X_AXIS/2 && myFlag == 0 ){
					move( pes[i], MOVE_SE );
					move( knights[i], MOVE_S );
					//move( pes[i], rand.nextInt(8) + 1 );
					savePos = MOVE_SE;
					//setFlag( 1 );
					//System.out.println("move SE");
				}
				else if( yPos < Y_AXIS/2 && xPos > X_AXIS/2 && myFlag == 0 ){
					move( pes[i], MOVE_SW);
					move( knights[i], MOVE_S );
					//move( pes[i], rand.nextInt(8) + 1 );
					savePos = MOVE_SW;
					//setFlag( 1);
					//System.out.println(" move SW");
				}
				else if( yPos > Y_AXIS/2 && xPos < X_AXIS/2 && myFlag == 0 ){
					move( pes[i], MOVE_NE);
					move( knights[i], MOVE_N);
					//move( pes[i], rand.nextInt(8) + 1 );
					savePos = MOVE_NE;
					//setFlag( 1 );
					//System.out.println( "move NE");
				}
				else if( yPos > Y_AXIS/2 && xPos > X_AXIS/2 && myFlag == 0 ){
					 move( pes[i], MOVE_NW);
					 move( knights[i], MOVE_N);
					 //move( pes[i], rand.nextInt(8) + 1 );
					 savePos = MOVE_NW;
					 //setFlag( 1 );
					 //System.out.println( "move NW1");
				}
				else{
					move( pes[i], rand.nextInt(8) + 1 );
					if( xPos > X_AXIS/2 ) move( knights[i], MOVE_W);
					else move( knights[i], MOVE_E );
					//System.out.println("move NW2");
					setFlag( 1 );
						 
				}
				
				
				/*int randMove = rand.nextInt(8) +1;
				Point np = World.getPositionAfterMove(pes[i].getX(), pes[i].getY(), randMove);
				if( np == null ) move( pes[i], randMove );
				else move( pes[i], randMove + 1 );*/
			}
			for( int y = 0; y < knights.length; y++) {
				int randMove = rand.nextInt( 8 ) + 1;
				Point np = World.getPositionAfterMove(knights[y].getX(), knights[y].getY(), randMove);
				if( np == null ) knightCapture( knights[y] );
				else move( knights[y], randMove );//moveAndCapture(knights[y], pes[y]);				
			}
					

	}
	
	public boolean knightCapture(IKnight knights) {
		for (int i = 1; i < 9; i++) {
			Point np = World.getPositionAfterMove(
						knights.getX(), knights.getY(), i);
		
			if(np != null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if(object != null && !object.getRuler().equals(knights.getRuler())) {
					capture(knights, i);
					return true;
				}
			}	
		}
		return false;
		
	}

	public void moveAndCapture(IKnight knights, IPeasant peasants) {
			if(peasants == null || !peasants.isAlive()) {
				return;				
			}
			int dir = knights.getDirectionTo(peasants.getX(), peasants.getY());
			Point np = World.getPositionAfterMove(knights.getX(), knights.getY(), dir);
		
			if(np != null) {
				if(peasants.equals(World.getObjectAt(np.x, np.y))) {
					capture(knights, dir);	
				}
				else {
					move(knights, dir);
				}
			}
	}
	public void setFlag( int flag ){
		myFlag = flag;
		
	}
	public int getFlag(){
		return myFlag;
	}
	
}