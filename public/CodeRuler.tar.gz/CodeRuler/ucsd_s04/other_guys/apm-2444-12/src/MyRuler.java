import com.ibm.ruler.*;
import java.awt.Point;
import java.util.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	MyKnights Knights = new MyKnights( this );
	
	int castles;
	public int initialCorner;
	Point myCastle;

	public ICastle baseCastle;
	public ICastle nearestCastle;
	
	MyRuler RULER = this;
	
	int count;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Street Bums";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 12";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		
		
		count = 0;
		ICastle MyCastles[] = getCastles();
		
		baseCastle = MyCastles[0];
		
		createKnights( baseCastle );
		
		int x = baseCastle.getX();
		int y = baseCastle.getY();

		//myCastle = new Point( MyCastles[0].getX(), MyCastles[0].getY() );

		
		// get position
		if( x < 24 )
		{
			if( y < 21 )
				initialCorner = 8;
			else if( y < 42 )
				initialCorner = 1;	
			else initialCorner = 2;
		}
		else if( x < 48 )
		{
			if( y < 21 )
				initialCorner = 7;	
			else if( y < 42 )
				initialCorner = 1;	
			else initialCorner = 3;			
		}
		else
		{
			if( y < 21 )
				initialCorner = 6;
			else if( y < 42 )
				initialCorner = 5;	
			else initialCorner = 4;
		}
		
		
		nearestCastle = getNearestEnemyCastle();
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		

		
		
		Random rand = new Random();
		
		IKnight[] knights = getKnights();
		int direction;
		Point p;
		int size = knights.length;


		if( nearestCastle.getRuler() == this )
		{
			createKnights( nearestCastle );
			

			if( count > 20 )
				nearestCastle = getNearestEnemyCastle();

			
				for( int i = 0; i < size; i++ )
				{
					direction = rand.nextInt(9);
				
					p = World.getPositionAfterMove( knights[i].getX(), knights[i].getY(), direction );
					
					if( p != null )
					{	if( World.getObjectAt( p.x, p.y ) == null )
						{						

								move( knights[i], direction );
						}
						else capture( knights[i], direction );
					}
				}

			count++;
			
		
		}

		else
		{
		
			for( int i = 0; i < size; i++ )
			{
				direction = knights[i].getDirectionTo( nearestCastle.getX(), nearestCastle.getY() );
			
				p = World.getPositionAfterMove( knights[i].getX(), knights[i].getY(), direction );
				IObject object;
			
				if( (object = World.getObjectAt( p.x, p.y )) == null )
					move( knights[i], direction );
				else
				{
					if( object.getRuler() == this )
						direction++;
					capture( knights[i], direction );

				}
			}
		}
		
		
		IPeasant peasants[] = getPeasants();
		size = peasants.length;

		for( int i = 0; i < size; i++ )
		{
			
			move( peasants[i], rand.nextInt(9) );
			
		}
		
		//movePeasant();
		
		//System.err.println( lastMoveTime );
		//allAttackCastle( nearestCastle );
		
		//movePeasant();
		// put implementation here+
	}
	
	
	public ICastle getNearestEnemyCastle()
	{
		ICastle castles[] = World.getOtherCastles();

		int size = castles.length;
		double distance = 10000;
		double dest;

		int index = -1;
		
		int x = RULER.baseCastle.getX();
		int y = RULER.baseCastle.getY();
		
		for( int i = 0; i < size; i++ )
		{
			if( castles[i].getRuler() == RULER )
				continue;
			dest = castles[i].getDistanceTo( x, y );
			
			if( dest < distance )
			{
				distance = dest;
				index = i;
			}
		}
		
		if( index < 0 )
			return nearestCastle;
		return castles[index];
		
	}
	
	
	public void allAttackCastle( ICastle castle )
	{
		IKnight knights[] = RULER.getKnights();
		int size = knights.length;
		int dir;
		Point p;
		
		IKnight knight;
		
		int destX = castle.getX();
		int destY = castle.getY();
		
		for( int i = 0; i < size; i++ )
		{
			knight = knights[i];

			dir = knight.getDirectionTo( destX, destY );
			p = World.getPositionAfterMove( knight.getX(), knight.getY(), dir);
			
			if( p != null)
			{
				if( World.getObjectAt( p.x, p.y ) != null )
					RULER.capture( knight, dir );
				else
					RULER.capture( knight, dir );
				
			}
			
		}
		

		
	}
	
	public void movePeasant(){
		    IPeasant peaArr [] = getPeasants();
		    Random rand = new Random();
		    
		    for(int i= 0; i > peaArr.length; i++){
		    	
		    	Point p = World.getPositionAfterMove( (int)peaArr[i].getX(), (int)peaArr[i].getY(), (i+1)%7);
		    	
		    	if( peaArr[i].getX() >= 72 || peaArr[i].getX() <= 0
		    		|| peaArr[i].getY() >= 64 || peaArr[i].getY() <= 0){
		    		
		    		move(peaArr[i], rand.nextInt(9) );		
		    	}
		    	
		    	else if( World.getLandOwner( (int)p.getX(),(int)p.getY()) == null)
		    		move(peaArr[i], i+1);
		    		
		    	else
					move(peaArr[i], rand.nextInt(9) );		
		    }
	}
	
	public void loopPeasant(IPeasant peaArr [], int offset, int priority){
		//Loop the peasaat vector
		/*for(int i = 0; i < peaArr.length; i++){
					
			//Loop through all of the path option 	
			for(int j = 1; j <= 8; j++){
				int dir = i+ offset;
							
				if(i > 8){
					dir = i % 8;	
				}
							
				Point optPath = World.getPositionAfterMove(peaArr[i].getX(), peaArr[i].getX(), dir );
							
				if( World.getLandOwner( (int)(optPath.getX()), (int)(optPath.getY()) ) == null){
					move(peaArr[i], dir);
					return;
				}
							
			}
						
			//Did not find unoccupy square
			move(peaArr[i], priority);
		}*/
	}
	
	
}