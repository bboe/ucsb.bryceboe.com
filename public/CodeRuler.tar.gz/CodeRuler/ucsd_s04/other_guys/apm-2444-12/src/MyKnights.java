import com.ibm.ruler.*;
import java.awt.Point;

/*
 * Created on May 1, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author acm04al
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MyKnights {

	MyRuler RULER;
	boolean actionDone;


	public MyKnights( MyRuler ruler )
	{
		RULER = ruler;
		actionDone = true;
	}

	public void action()
	{
		ICastle castles[] = World.getOtherCastles();
		
		allAttackCastle( castles[0] );
		
		
		
		//allAttack( (RULER.initialCorner+1)%9 );
		

		
	}
	
	public void allAttackCastle( ICastle castle )
	{
		IKnight knights[] = RULER.getKnights();
		int size = knights.length;
		int dir;
		Point p;
		
		IKnight knight;
		
		int destX = castle.getX();
		int destY = castle.getY();
		
		for( int i = 0; i < size; i++ )
		{
			knight = knights[i];

			dir = knight.getDirectionTo( destX, destY );
			p = World.getPositionAfterMove( knight.getX(), knight.getY(), dir);
			
			if( p != null)
			{
				if( World.getObjectAt( p.x, p.y ) != null )
					RULER.capture( knight, dir );
				else
					RULER.capture( knight, dir );
				
			}
			
		}
		

		
	}
	
	
	public ICastle getNearestEnemyCastle()
	{
		ICastle castles[] = World.getOtherCastles();

		int size = castles.length;
		double distance = 10000;
		double dest;

		int index = 0;
		
		int x = RULER.baseCastle.getX();
		int y = RULER.baseCastle.getY();
		
		for( int i = 0; i < size; i++ )
		{
			if( castles[i].getRuler() == RULER )
				continue;
			dest = castles[i].getDistanceTo( x, y );
			
			if( dest < distance )
			{
				distance = dest;
				index = i;
			}
		}
		
		return castles[index];
		
	}
	
	
	public void allAttack( int corner )
	{
		
		int direction;
		int x = 0;
		int y = 0;

		
		if( actionDone == false )
			return;
		
		IKnight myKnights[] = RULER.getKnights();
		IKnight currentKnight;

		switch( RULER.initialCorner )
		{
			case( 1 ):
				x = 36;
				y = 0;
				break;
			case( 2 ):
				x = 72;
				y = 0;
				break;
			
			case( 3 ):
				x = 72;
				y = 32;
				break;
			case( 4 ):
				x = 72;
				y = 64;
				break;
			case( 5 ):
				x = 36;
				y = 64;
				break;
			case( 6 ):
				x = 0;
				y = 64;
				break;			
			case( 7 ):
				x = 0;
				y = 32;
				break;		
			case( 8 ):	
				x = 0;
				y = 0;
				break;
			
		}


		actionDone = true;
		
		

		

		
	}

}
