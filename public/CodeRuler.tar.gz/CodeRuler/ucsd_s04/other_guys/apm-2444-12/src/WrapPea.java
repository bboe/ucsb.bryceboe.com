import com.ibm.ruler.*;

/*
 * Created on May 1, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author acm04al
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WrapPea {
 	
 	public WrapPea( IPeasant p, int i){
 		peasant = p;
 		index = i;

 	}
 	public IPeasant peasant;
 	public int index;
 	
}
