import com.ibm.ruler.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
import java.util.*;
import java.awt.*;

public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	protected Random rand = new Random();

	 
	IKnight[]		a_knights;
	IPeasant[]		a_peasants;
	ICastle[]		a_castles;
	 
	ICastle[]		o_castles;
	int				oc_index; 
	 
	 
	 
	int				d_dir;
	int			castle_index;
	int			knight_index;
	int			peasant_index;
	
	
	public String getRulerName() {
		return "$$NQ$$";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "---Team 13---";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		oc_index = 0;
		
		
		castle_index = 0;
		knight_index = 0;
		peasant_index = 0;
		
		
		d_dir = 0;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {

		a_knights = getKnights();
		IKnight[]	attack_knights = getFirstHalf (a_knights);
		IKnight[]	defend_knights = getSecondHalf (a_knights);
		 
		a_peasants = getPeasants();
				
		a_castles = getCastles();
		
		o_castles = World.getOtherCastles();
	
		ICastle		mc = a_castles [rand.nextInt(a_castles.length)];
		createKnights (mc);
		createPeasants (mc);

		ICastle		op_castle = getClosestCastle (mc, o_castles);
		
		
		if (op_castle != null)
		{
			attack (attack_knights, op_castle);
			
		} else {
			moveKnightRandom (attack_knights);
		}




		movePeasantRandom (a_peasants);
			
	

		moveKnightDefend (defend_knights, d_dir++);
		

	}
	
	
	
	

	public ICastle
	getClosestCastle (ICastle mc, ICastle[] opp)
	{
		int[] len = new int[opp.length];
		for (int i = 0; i < opp.length; ++i)
		{
			len[i] = mc.getDistanceTo (opp[i].getX(), opp[i].getY() );
		}
		
		int s_index = 0;
		int current = 1000;
		
		for (int i = 0; i < len.length; ++i)
		{
			if (len[i] < current) 
			{
				current = len[i];
				s_index = i;
			}
		}
		
		return (opp[s_index]);
	}
	

	
	
	
	
	
	
	
	public void
	attack (IKnight[] att, ICastle op)
	{

		for (int i = 0; i < att.length; ++i)
		{
			
			if (op == null)
			{
				break;
				
			}
			
			
			int 		dir = att[i].getDirectionTo (op.getX(), op.getY());
			Point		point = World.getPositionAfterMove (att[i].getX(), att[i].getY(), dir);
			IObject 	object = World.getObjectAt (point.x, point.y);
			
			move (att[i], dir);
			knightCapture (att[i], point, dir);
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	public IKnight[]
	getFirstHalf (IKnight[] k)
	{
		
		int		asize = k.length;
		
		IKnight[] retArray = new IKnight[asize/2];
		
		for (int i = 0; i < asize/2 ; ++i)
		{
			retArray[i] = k[i];
		}
		
		return retArray;
	
	}	
	
	public IKnight[]
	getSecondHalf (IKnight[] k)
	{
		
		int		asize = k.length;
		
		IKnight[] retArray = new IKnight[asize/2];
		
		for (int i = 0; i < asize/2 ; ++i)
		{
		
			retArray[i] = k[asize/2 + i];
		}
		
		return retArray;
	}	
	
	
	
	public void
	moveKnightRandom (IKnight[] o)
	{
		for (int i = 0; i < o.length; ++i)
		{
			move (o[i], rand.nextInt(8) + 1);
		}
	}
	
	public void
	moveKnightDefend (IKnight[] k, int dir)
	{	
		for (int i = 0; i < k.length; ++i)
		{
			move (k[i], dir%8 + 1);
		}
	}
	
	
	
	public void
	movePeasantRandom (IPeasant[] o)
	{	
		for (int i = 0; i < o.length; ++i)
		{
			move (o[i], rand.nextInt(8) + 1);
		}
	}
	
	
	
	
	public boolean 
	knightCapture (IKnight k, Point p, int dir)
	{
		if (p != null)
		{
			IObject object = World.getObjectAt(p.x, p.y);
			if (object != null && !object.getRuler().equals(k.getRuler()))
			{
				capture (k, dir);
				return true;
			}
			
		}
		
		return false;
	}
	
	public ICastle
	getOpCastle (ICastle[] o, ICastle mycastle)
	{
		while (oc_index < o_castles.length)
		{
			if ( !o_castles[oc_index].getRuler().equals (mycastle.getRuler()))
			{
			
				return ( o_castles[oc_index]);
				
			} else {
				oc_index ++;
				
				if (oc_index == o_castles.length)
				{
					oc_index = 0;
				}
				
				continue;
			}
		}
		
		return null;
	}

}