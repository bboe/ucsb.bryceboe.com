import java.awt.Point;
import java.util.Random;
import java.util.Vector;

import com.ibm.ruler.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Dream Team";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 61";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
	    c=getCastles();
	    k=getKnights();
	    p=getPeasants(); 	
	    turnCount ++;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		c=getCastles();
		k=getKnights();
		p=getPeasants(); 
		ICastle[] oCastle = World.getOtherCastles();
		IPeasant[] oPeasant = World.getOtherPeasants();
		IKnight[] oKnight = World.getOtherKnights();
		
		Random rand  = new Random();
		Point np =new Point(0,0);
		Vector v = new Vector();
		int movePos =0;
	    if (turnCount ==1){ 
	    	for (int i=0; i<k.length; i++){
			   movePos =rand.nextInt(8)+1;	
	    	   move(p[i],movePos);
	    	   while (np != null){
	    	   	movePos =rand.nextInt(8)+1;
	    	    np = World.getPositionAfterMove(k[i].getX(),
	    	         k[i].getY(),movePos);
	    	    if (np != null)
	    	     break;
	    	   }
			   move(k[i],movePos);
	    	     		
	    	}
	    	turnCount++;
	   }
	   else{
	   	  int distance = 100;
	   	  int direction = -1;
	   	  int cindex=0;
	   	  int j, b;
	   	  for ( j=0; j<k.length; j++){
	   	  	for ( b=0; b<oCastle.length; b++){
	   	  	   int temp = k[j].getDistanceTo(oCastle[b].getX(),oCastle[b].getY());	
	   	  	   if (temp <distance){
	   	  	   	 distance = temp;
	   	  	   	 direction = k[j].getDirectionTo(oCastle[b].getX(),oCastle[b].getY());
	   	  	   	 cindex=b;
	   	  	   }
	   	  	}
	   	  	v.add(new Knight(distance,direction,j,cindex));
	   	  }
	   	  
	   	  for(int d=0; d<v.size(); d++){
	   	   /*move(k[((Knight)v.elementAt(d)).getKnightIndex()],
	   	  	   	oCastle[((Knight)v.elementAt(d)).getCastleIndex()]);*/
	   	  	int x =oCastle[((Knight)v.elementAt(d)).getCastleIndex()].getX();
			int y =oCastle[((Knight)v.elementAt(d)).getCastleIndex()].getY();
	   	    int castleDir = k[((Knight)v.elementAt(d)).getKnightIndex()].getDirectionTo(x,y);
          	
          	/*Point pt = World.getPositionAfterMove(k[((Knight)v.elementAt(d)).getKnightIndex()].getX(),
												  k[((Knight)v.elementAt(d)).getKnightIndex()].getY(),
												  castleDir);
			if(pt != null && !World.getObjectAt(pt.x,pt.y).getRuler().equals(
							  k[((Knight)v.elementAt(d)).getKnightIndex()].getRuler())){
				   capture(k[((Knight)v.elementAt(d)).getKnightIndex()], castleDir);											  
			} */
			move(k[((Knight)v.elementAt(d)).getKnightIndex()],
			     k[((Knight)v.elementAt(d)).getKnightIndex()].getDirectionTo(
			      x,y));
		      
			captureCastle(k[((Knight)v.elementAt(d)).getKnightIndex()],
							oCastle[((Knight)v.elementAt(d)).getCastleIndex()]);
							
			/*for(int w = 0; w <oPeasant.length; w++){
				capturePeasants(k[((Knight)v.elementAt(d)).getKnightIndex()], oPeasant[w]);
			}
			for(int z = 0; z<oKnight.length; z++){
				captureKnights(k[((Knight)v.elementAt(d)).getKnightIndex()], oKnight[z]);
			}*/
			
			//capturePeasant(k[((Knight)v.elementAt(d)).getKnightIndex()], oPeasant);
			/*for(int dir=1; dir<9; dir++){
			
				Point pt = World.getPositionAfterMove(k[((Knight)v.elementAt(d)).getKnightIndex()].getX(), 
							k[((Knight)v.elementAt(d)).getKnightIndex()].getY(),
															   dir);
				if(np != null){
					if(k[((Knight)v.elementAt(d)).getKnightIndex()].getRuler().equals(World.getObjectAt(np.x, np.y).getRuler()))
						capture(k[((Knight)v.elementAt(d)).getKnightIndex()], dir);
					else {
						move(k[((Knight)v.elementAt(d)).getKnightIndex()],
				 		k[((Knight)v.elementAt(d)).getKnightIndex()].getDirectionTo(
				  		x,y));
					}
				}  
			} 	 */
 			
			if (d < p.length)  {  
			  
			  while (np != null){
				movePos =rand.nextInt(8)+1;
				np = World.getPositionAfterMove(p[d].getX(),
					 p[d].getY(),movePos);
				if (np != null)
					 break;
				 }
			  move(p[d],movePos);
			}
	   	  }
	   	  
	   	  
	   	
	   }
		/*ICastle[] oCastle = World.getOtherCastles();
		int closest = 100;
		int castlex = -1;
		int castley = -1;
		int castledir = -1;
		int xBoundry =World.WIDTH;
		int yBoundry =World.HEIGHT;
		
		int [] knightdir = new int[k.length];
		if (turnCount == 1){
		    for (int i=0; i<k.length;i++){
		    	if (k[i].getX()
		    	k[i].getY()
		    		
		    }
			
		}
	    else if (turnCount ==2){
	    	
	    	
	    	
	    }
	    else {
	    
		for(int i = 0; i<oCastle.length; i++){
			for (int j =0; j< k.length ; j++){
				int tempdis = k[j].getDistanceTo(oCastle[i].getX(), oCastle[i].getY());
				if(tempdis < closest){
					closest = tempdis;
					castlex = oCastle[i].getX();
					castley = oCastle[i].getY();
					castledir = k[j].getDirectionTo(oCastle[i].getX(), oCastle[i].getY());
				}
				
			}
		}
*/		
	    }	
	 
	public void captureCastle(IKnight myknight, ICastle c){
			if(c == null ) return;
			
			int dir = myknight.getDirectionTo(c.getX(), c.getY());
			Point np = World.getPositionAfterMove(myknight.getX(), myknight.getY(),
													   dir);
			if(np != null){
					if(!World.getObjectAt(myknight.getX(), myknight.getY()).getRuler().equals(
											  myknight.getRuler())){
						capture(myknight, dir);
					}
					if(c.equals(World.getObjectAt(np.x, np.y))){
							capture(myknight, dir);
							createKnights(c);
							createPeasants(c);
					}
					else {
						move(myknight, dir);
					}
			}
	}
	public void capturePeasants(IKnight myknight, IPeasant p){
		
		if(p == null || p.isAlive()){
		     return;
		}
		int dir = myknight.getDirectionTo(p.getX(), p.getY());
		Point np = World.getPositionAfterMove(myknight.getX(), myknight.getY(),
											   dir);
		if(np != null){
			if(p.equals(World.getObjectAt(np.x, np.y)))
					capture(myknight, dir);
			else {
				move(myknight, dir);
			}
		}
	
	}
	public void captureKnights(IKnight myknight, IKnight p){
		
			if(p == null || p.isAlive()){
				 return;
			}
			int dir = myknight.getDirectionTo(p.getX(), p.getY());
			Point np = World.getPositionAfterMove(myknight.getX(), myknight.getY(),
												   dir);
			if(np != null){
				if(p.equals(World.getObjectAt(np.x, np.y)))
						capture(myknight, dir);
				else {
					move(myknight, dir);
				}
			}
	
		}
	static int turnCount = 0;
	IPeasant[] p =null;
	IKnight[] k =null;
	ICastle[] c = null;
}
class Knight {
	public int direction =0;
	public int distance =0;
	public int kindex =0;
	public int cindex=0;
	public Knight(int dir, int dis, int in, int in2){
		direction =dir;
		distance = dis;
		kindex =in;
		cindex=in2;
		
	}
	public int getDirection(){
		return direction;	
	}	
	public int getDistance(){
		return distance;	
	}
	
	public int getKnightIndex(){
		return kindex;
	}
	public int getCastleIndex(){
		return cindex;
	}
	
}
