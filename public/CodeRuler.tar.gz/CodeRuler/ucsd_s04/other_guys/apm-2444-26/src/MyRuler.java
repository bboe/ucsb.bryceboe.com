import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	private IRuler[] otherRulers;
	private IKnight[] ourKnights;
	private IPeasant[] ourPeasants;
	private ICastle [] otherCastles;
	private int[] closestKnight;
	private int[] bestDistances;
	private ICastle desiredCastle;
	boolean doHuntKnights = false;
	
	Random gen = new Random(System.currentTimeMillis());
	
	/* peasant global vars */
	private int enemyKnightX, enemyKnightY;
	
	private HashMap p_oldX;
	private HashMap p_oldY;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Team Ramrod";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 26";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		otherRulers = World.getOtherRulers();
		p_oldX = new HashMap();
		p_oldY = new HashMap();
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		initStep();
		
		orderCastles();
		orderKnights();
		orderPeasants();
	}
	
	private void orderKnights() {

		doCaptureCastle();
	
	}
	
	private void orderPeasants() {
		/*
		if (ourPeasants.length == 0) {
			return;
		}
		
		if (peasantLeader == null) {
			peasantLeader = ourPeasants[0];
		}
		decidePeasantMove();*/
		Point nextPoint = null;
		
		int dir = move_rand();
		int my_dir = 1;
		IRuler owner;
		boolean assigned = false;
		for (int i = 0; i < ourPeasants.length; i++) {
			assigned = false;
			for (int x = 1; x < 9; x++) {
				my_dir = x;
				nextPoint = World.getPositionAfterMove(ourPeasants[i].getX(), ourPeasants[i].getY(), my_dir);
				if (nextPoint == null) {
					continue;
				}
				if (World.getObjectAt(nextPoint.x, nextPoint.y) == null) {
					owner = World.getLandOwner(nextPoint.x, nextPoint.y);
					if (owner != null && !owner.getSchoolName().equals("Team 26")) {
						move(ourPeasants[i], my_dir);
						assigned = true;
						break;
					}
					else {
						move(ourPeasants[i], move_rand());
						assigned = true;
					}
				}
				else {
					// There's an object in the way
					int delta = (flip_coin()) ? 1 : -1;
					int direction = (my_dir + delta)%8 + 1;
					move(ourPeasants[i], direction);
					assigned = true;
				}
				
			}
			if (assigned == false) {
				move(ourPeasants[i], ((move_rand())%8)+1);
			}
			
		}
	}
	
	private void orderCastles() {
		ICastle[] castles = getCastles();
		if (castles.length == 0) return;
		createKnights(castles[0]);
		for (int x = 1; x < castles.length; x++) {
			createPeasants(castles[x]);
		}
	}
	
	private void initStep()
	{
		ourKnights = this.getKnights();
		otherCastles = World.getOtherCastles();
		ourPeasants = this.getPeasants();
		otherRulers = World.getOtherRulers();
	}
	

	private void doCaptureCastle()
	{
		int direction = -1;
		int distance = -1;
		Point nextPoint;
		IObject obstacle;
		
		if(ourKnights.length <= 0 )
		{
			//huntKnights();
			return;		
		}
		
		
		if(World.getOtherCastles().length <= 0)
		{
			//System.out.println("Capture Knights now;");
			huntKnights();
			return;
		}
		
		for(int i=0; i < ourKnights.length; i++)
		{
			direction = ourKnights[i].getDirectionTo( otherCastles[0].getX(), otherCastles[0].getY() );
			//distance = ourKnights[i].getDistanceTo( otherCastles[0].getX(), otherCastles[0].getY() );
			
			//detect obstacle
			nextPoint = World.getPositionAfterMove( ourKnights[i].getX(), ourKnights[i].getY(), direction );
			obstacle = World.getObjectAt(nextPoint.x, nextPoint.y);
			
			if(obstacle == null)
			{
				move(ourKnights[i], direction);
			}
			else if(isEnemy(obstacle))
			{
				//System.out.println("Knight " + i + " trying to capture " + obstacle.getClass());
				capture(ourKnights[i], direction);
			}
			else
			{
				int delta = (flip_coin()) ? 1 : -1;
				direction = (direction + delta)%8 + 1;
				move(ourKnights[i], direction);
			}
			
			

		}
		/*
		for(int i = 0; i < closestKnight.length; i++)
		{
			// -1 means we're at end of list to assign stuff
			if(closestKnight[i] < 0)
			{
				return;
			}
			
			direction = ourKnights[closestKnight[i]].getDirectionTo( otherCastles[i].getX(), otherCastles[i].getY() );
			if(bestDistances[i] < 2)
			{
				capture(ourKnights[closestKnight[i]], direction);
			}
			else
			{
				move(ourKnights[closestKnight[i]], direction);
			}
		}
		
		*/
		return;
	}
	
	
	private void huntKnights()
	{
		/*
		IKnight[] tempOtherRulerKnights = null;
		IKnight []worstRulerKnights = otherRulers[0].getKnights();
		for(int i = 0; i < otherRulers.length; i++)
		{
			tempOtherRulerKnights = otherRulers[i].getKnights();
			if(tempOtherRulerKnights.length > 0 && tempOtherRulerKnights.length > worstRulerKnights.length)
			{
				worstRulerKnights = tempOtherRulerKnights;			
			}					
		}
		
		if(worstRulerKnights.length <= 0)
		{
			System.out.println("returning, no worst found");
			return;
		}
		
		//find closest knight of theirs, to the first of ours
		IKnight currentKnight = ourKnights[0];
		int currentDistance = -1;
		int bestDistance = Integer.MAX_VALUE;
		IKnight theBestKnight = null;
		for(int i = 0; i < worstRulerKnights.length; i++)
		{
			currentDistance = worstRulerKnights[i].getDistanceTo(currentKnight.getX(), currentKnight.getY());
			if(currentDistance < bestDistance)
			{
				bestDistance = currentDistance;
				theBestKnight = worstRulerKnights[i];
			}
		}
		*/
		
		if(World.getOtherKnights().length <= 0) {
			return;
		}
		IObject theBestKnight = World.getOtherKnights()[0];
		
		if(theBestKnight == null)
		{
			theBestKnight = World.getOtherPeasants()[0];
			if(theBestKnight == null)
			{
				return;
			}
		}
		
		int direction = 1;
		Point nextPoint = null;
		IObject obstacle = null;
		
		for(int i=0; i < ourKnights.length; i++)
		{
			direction = ourKnights[i].getDirectionTo( theBestKnight.getX(), theBestKnight.getY() );
			
			
			//detect obstacle
			nextPoint = World.getPositionAfterMove( ourKnights[i].getX(), ourKnights[i].getY(), direction );
			obstacle = World.getObjectAt(nextPoint.x, nextPoint.y);
			
			if(obstacle == null)
			{
				move(ourKnights[i], direction);
			}
			else if(isEnemy(obstacle))
			{
				//System.out.println("Knight " + i + " trying to capture " + obstacle.getClass());
				capture(ourKnights[i], direction);
			}
			else
			{
				int delta = (flip_coin()) ? 1 : -1;
				direction = (direction + delta)%8 + 1;
				move(ourKnights[i], direction);
			}
			
			

		}
	}
	
	
	
	/* Peasant functions */
	private boolean scanForKnight(IPeasant peas) {
		int myX = peas.getX(), myY = peas.getY();
		IObject obj = null;
		
		int i = 0, j = 0;
		
		for (i = myX - 1; i < myX + 2; i++) {
			for (j = myY - 1; j < myY + 2; j++) {
				obj = World.getObjectAt(i, j);
				if (obj instanceof IKnight) {
					if (!obj.getRuler().getSchoolName().equals("Team 26")) {
						enemyKnightX = i;
						enemyKnightY = j;
						return true;
					}
				}
			}
		}
		return false;
	}
	
	private void decidePeasantMove() {
		
	}
	
	
	/* general functions */
	private int move_rand() {
		return gen.nextInt(8) + 1;
	}
	
	private boolean flip_coin() {
		int b = gen.nextInt(2);
		return (b == 1);
	}
	
	private boolean isEnemy(IObject obj) {
		return !obj.getRuler().getSchoolName().equals("Team 26");
	}
}