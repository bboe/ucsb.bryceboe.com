import java.awt.Point;
import java.util.Random;
import java.util.Vector;

import com.ibm.ruler.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	private int peasantDirection;

	private ICastle secondClosestCastle;

	private ICastle[] myCastles;

	private IPeasant[] myPeasants;

	private ICastle closestCastle;

	private IKnight[] myKnights;

	private ICastle[] otherCastles;

	private int closeCastleY;

	private int closeCastleX;

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Sir Paul Kube KBE";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 46";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		defendingKnights = new Vector();
		peasantDirection = 0;
		setOtherCastles(World.getOtherCastles());
		setMyKnights(getKnights());
		setMyPeasants(getPeasants());
		int closex = 0, closey = 0, closeid = 0, i = 0;
		int secid = 0, secx, secy;
		double closedistance = 0, secdistance = 0;
		IKnight knight = getKnight(1);
		for (i = 0; i < otherCastles.length; i++) {
			int tempx = otherCastles[i].getX();
			int tempy = otherCastles[i].getY();
			double tempdistance = knight.getDistanceTo(tempx, tempy);
			if (((closedistance == 0) || (tempdistance < closedistance))
				&& !(otherCastles[i]
					.getRuler()
					.getRulerName()
					.equals(getRulerName()))) {
				secid = closeid;
				secdistance = closedistance;
				secx = closex;
				secy = closey;
				closeid = i;
				closedistance = tempdistance;
				closex = tempx;
				closey = tempy;
			} else if (
				((secdistance == 0) || (tempdistance < secdistance))
					&& !(otherCastles[i]
						.getRuler()
						.getRulerName()
						.equals(getRulerName()))) {
				secid = i;
				secdistance = tempdistance;
				secx = tempx;
				secy = tempy;
			}
		}
		setClosestCastle(otherCastles[closeid]);
		setSecondClosestCastle(otherCastles[secid]);
	}

	/**
	 * @param castle
	 */
	private void setSecondClosestCastle(ICastle castle) {
		this.secondClosestCastle = castle;

	}

	/**
	 * @param peasants
	 */
	private void setMyPeasants(IPeasant[] peasants) {
		this.myPeasants = peasants;
	}

	/**
	 * 
	 */
	private ICastle getClosestCastle() {
		return closestCastle;
	}

	/**
	 * @param knights
	 */
	private void setMyKnights(IKnight[] knights) {
		this.myKnights = knights;
	}

	private IKnight getKnight(int i) {
		return this.myKnights[i];
	}

	/**
	 * @param castles
	 */
	private void setOtherCastles(ICastle[] castles) {
		this.otherCastles = castles;
	}

	/**
	 */
	private void setClosestCastle(ICastle ic) {
		this.closestCastle = ic;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		setMyKnights(getKnights());
		setMyPeasants(getPeasants());
		setMyCastles(getCastles());

		if (World.getOtherCastles().length < 3 && myKnights.length > 20) {
			for (int i = 0; i < myCastles.length; i++) {
				if (!(i % 3 == 0)) {
					createKnights(getCastle(i));
				} else {
					createPeasants(getCastle(i));
				}
			}
		} else if (myKnights.length < 15) {
			for (int i = 0; i < myCastles.length; i++) {
				int knightcount = myKnights.length;
				createKnights(getCastle(i));
			}
		} else {
			for (int i = 0; i < myCastles.length; i++) {
				createPeasants(getCastle(i));
			}
		}
		for (int i = 0; i < myKnights.length; i++) {
			if ((defendingKnights.contains(getKnight(i)))) {
				knightCapture(getKnight(i));
			} else if (World.getOtherCastles().length < 1) {
				move(getKnight(i), new Random().nextInt(8) + 1);
			} else if (
				getClosestCastle().getRuler().equals(
					getKnight(i).getRuler())) {
				setOtherCastles(World.getOtherCastles());
				setMyKnights(getKnights());
				setMyPeasants(getPeasants());
				int closex = 0, closey = 0, closeid = 0, j = 0;
				int secid = 0, secx, secy;
				double closedistance = 0, secdistance = 0;
				IKnight knight = getKnight(i);
				for (j = 0; j < otherCastles.length; j++) {
					int tempx = otherCastles[j].getX();
					int tempy = otherCastles[j].getY();
					double tempdistance = knight.getDistanceTo(tempx, tempy);
					if (((closedistance == 0)
						|| (tempdistance < closedistance))
						&& !(otherCastles[j]
							.getRuler()
							.getRulerName()
							.equals(getRulerName()))) {
						secid = closeid;
						secdistance = closedistance;
						secx = closex;
						secy = closey;
						closeid = j;
						closedistance = tempdistance;
						closex = tempx;
						closey = tempy;
					} else if (
						((secdistance == 0) || (tempdistance < secdistance))
							&& !(otherCastles[j]
								.getRuler()
								.getRulerName()
								.equals(getRulerName()))) {
						secid = j;
						secdistance = tempdistance;
						secx = tempx;
						secy = tempy;
					}
				}
				setClosestCastle(otherCastles[closeid]);
				setSecondClosestCastle(otherCastles[secid]);
				move(
					getKnight(i),
					getKnight(i).getDirectionTo(
						closestCastle.getX(),
						closestCastle.getY()));
				knightCapture(getKnight(i));
			} else {
					move(
						getKnight(i),
						getKnight(i).getDirectionTo(
							closestCastle.getX(),
							closestCastle.getY()));
					knightCapture(getKnight(i));
				
			}

			for (int in = 0; in < myPeasants.length; in++) {
				if (!peasantMove(getPeasant(in))) {
					if (new Random().nextBoolean()) {

						move(getPeasant(in), new Random().nextInt(8) + 1);
					} else {
						move(
							getPeasant(in),
							getPeasant(in).getDirectionTo(
								closestCastle.getX(),
								closestCastle.getY()));
					}
				}
			}

		}
	} /**
																																																																																												 * @param i
																																																																																									 * @return
																																																																																												 */
	private ICastle getCastle(int i) {
		return myCastles[i];
	} /**
															* @param i
															* @return
															*/
	private IPeasant getPeasant(int i) {
		return this.myPeasants[i];
	}

	void computeClosestCastle(IKnight knight) {
		setMyCastles(getCastles());
		setOtherCastles(World.getOtherCastles());
		int closex = 0, closey = 0, closeid = 0, i = 0;
		double closedistance = 0;
		for (i = 0; i < otherCastles.length; i++) {
			int tempx = otherCastles[i].getX();
			int tempy = otherCastles[i].getY();
			double tempdistance = knight.getDistanceTo(tempx, tempy);
			if (((closedistance == 0) || (tempdistance < closedistance))
				&& !(otherCastles[i]
					.getRuler()
					.getRulerName()
					.equals(getRulerName()))) {
				closeid = i;
				closedistance = tempdistance;
				closex = tempx;
				closey = tempy;
			}
		}
		setClosestCastle(otherCastles[closeid]);
	}

	public boolean knightCapture(IKnight knight) {
		for (int i = 1; i < 9; i++) {
			Point np =
				World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			if (np != null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if (object != null
					&& !object.getRuler().equals(knight.getRuler())) {
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}
	public boolean peasantMove(IPeasant peasant) {
		for (int i = 1; i < 9; i++) {
			Point np =
				World.getPositionAfterMove(peasant.getX(), peasant.getY(), i);
			if (np != null) {
				IRuler object = World.getLandOwner(np.x, np.y);
				if (object != null && !object.equals(peasant.getRuler())) {
					move(peasant, i);
					return true;
				}
			}
		}
		return false;
	}

	void setMyCastles(ICastle castles[]) {
		this.myCastles = castles;
	}
	Vector defendingKnights;
}