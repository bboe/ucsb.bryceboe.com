import com.ibm.ruler.*;
import com.sun.rsasign.n;

import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {

	private IKnight[] ourKnights;
	private IPeasant[] ourPeasants;
	private ICastle[] ourCastles;
	private int turns;
	private int currentIndex[][] = new int[4][4];
	private IPeasant[][][] otherPeasants = new IPeasant[4][4][40];
	
	
	private Random rand = new Random();
	
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return ".";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 35";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		
		/* initialize fields */
		ourKnights = getKnights();
		ourPeasants = getPeasants();
		ourCastles = getCastles();
		turns = 0;	
		//clusters = new int[4][4];
		createKnights(ourCastles[0]);
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		ourKnights = getKnights();
		ourPeasants = getPeasants();
		ourCastles = getCastles();
		
		int limit = ourKnights.length;
		int x, y, i, j, k;
		int bestClusterX = 0, bestClusterY = 0;
		int bestRatio = 0;
		int ratio, dist;
		int bestX, bestY;
		
		if(World.getCurrentTurn() > World.MAX_TURNS/2)
		{
			for(i = 0; i<ourCastles.length; i++)
				createPeasants(ourCastles[i]);
				
		}
		else
			for(i = 0; i<ourCastles.length; i++)
				createKnights(ourCastles[i]);
		findPeasantClusters();
		limit = ourKnights.length;
		for(i = 0; i<limit; i++)
		{
			ninjaOrder(ourKnights[i]);
		}
		limit = ourPeasants.length;
		for(i = 0; i<limit; i++)
		{
			handlePeasant(ourPeasants[i]);
		}
		
			
	}
	
	private void ninjaOrder(IKnight ninja)
	{
		if(ninja == null) return;
		ICastle[] others = World.getOtherCastles();
		int myX = ninja.getX();
		int myY = ninja.getY();
		int closest = 0;
		int dist = 10000000;
		int current = 0;
		int x = 0, y = 0;
		int highest; 
		int index;
		int limit;
		boolean peasants = false;
		if(others.length == 0) {
			peasants = true;	
			x = ninja.getX()/18;
			y = ninja.getY()/16;
			
			if(currentIndex[x][y] == 0) {
			
				move(ninja, rand.nextInt(8)+1);
				return;
			}	
		}
		if(!peasants)
			limit = others.length;
		else
			limit = currentIndex[x][y];
		for(int i = 0; i<others.length; i++)
		{
			if(!peasants)
				current = ninja.getDistanceTo(others[i].getX(), others[i].getY());
			else
				current = ninja.getDistanceTo(otherPeasants[x][y][i].getX(), otherPeasants[x][y][i].getY());
			if(current < dist)
			{
				dist = current;
				closest = i;
			}
		}
		
		Point np;
		int dir = ninja.getDirectionTo(others[closest].getX(), others[closest].getY());
		
		if(dist == 1)  /* we want to kill here */
		{
			dir = killDir(ninja, others[closest]);
			
			capture(ninja, dir);	
		}
		else {
			np = World.getPositionAfterMove(ninja.getX(), ninja.getY(), dir);
			if(np != null)
				move(ninja, dir);
			else 
			{
				x = ninja.getX();
				y = ninja.getY();
				IObject temp;
				for(int i = -1; i<=1; i++)
					for(int j = -1; j<=1; j++)
					{
						if((temp = World.getObjectAt(x+i, y+j)) != null)
						{
							if(!temp.getRuler().equals(ninja.getRuler()))
							{
								capture(ninja, killDir(ninja, temp));
							}
							else
							{
								move(ninja, ninja.getDirectionTo(x+i, y+j));
							}
						}
					}
				move(ninja, (dir+(int)(rand.nextInt(8)))%9);
			}
						
		
			
			}
	}
		
	
	private void findPeasantClusters()
	{
		for(int i = 0; i<4; i++)
			for(int j = 0; j<4; j++)
			{
				currentIndex[i][j] = 0;
			}
			
				
		IPeasant[] current = World.getOtherPeasants();
		int limit = current.length;
		int x, y;
		for(int i = 0; i<limit; i++)
		{
			x = current[i].getX()/18;
			y = current[i].getY()/16;
			if(currentIndex[x][y] < 40)
			{
				otherPeasants[x][y][currentIndex[x][y]] = current[i]; 
				currentIndex[x][y]++;
			}
		}
	}
	
	private void handlePeasant(IPeasant current)
	{
		if (current == null) return;
		int x = current.getX();
		int y = current.getY();
		for (int i=x-1; i<=x+1; i++) {
			for (int j=y-1; j<=y+1; j++) {
				if (World.getObjectAt(i, j) != null) continue;
				if (i<0 || i>72 || j<0 || j>64) continue;
				if (World.getLandOwner(i, j) == null || !World.getLandOwner(i, j).equals(current.getRuler())) {
					move(current, current.getDirectionTo(i, j));
					return;
				}
			}
		}
		move(current, rand.nextInt(8) + 1);
	}
	
	private int killDir(IObject x, IObject target)
	{
		int x1, x2, y1, y2;
		x1 = x.getX();
		x2 = target.getX();
		y1 = x.getY();
		y2 = target.getY();
		
		int diff1 = x1-x2;
		int diff2 = y1 -y2;
		
		if(diff1 > 0 && diff2 > 0)
			return 2;
		if(diff1 > 0 && diff2 < 0)
			return 6;
		if(diff1 > 0 && diff2 == 0)
			return 3;
		if(diff1 < 0 && diff2 > 0)
			return 6;
	 	if(diff1 < 0 && diff2 < 0)
			return 4;
		if(diff1 < 0 && diff2 == 0)
			return 7;
		if(diff1 == 0 && diff2 > 0)
			return 1;
		if(diff1 == 0 && diff2 < 0)
			return 5;
		return 0;
	}
}