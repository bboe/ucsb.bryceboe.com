import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */

public class MyRuler extends Ruler {
	Random rand;
	IPeasant Peasants[];
	IPeasant peasant;
	IKnight Knights[];
	IKnight knight;
	ICastle Castles[];
	IKnight knightSquad[];	// 4 team knights
	
	int iOwnLand;
	int iPrevOwnLand;
	
	int State;
	int peasantWanderState;
	boolean bMovePeasantsCenter;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Var";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "UCSD";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		State=0;
		bMovePeasantsCenter=false;
		peasantWanderState=0;
		//rand.setSeed((long)(Math.random()*1000.0));
	}

	public int getRandDir(){
		return Math.round((float)(Math.random()*8));

	}
	
	public int moveAwayCastle(ICastle castle, IObject obj){
		int dir;
		dir = castle.getDirectionTo(obj.getX(), obj.getY());
		return dir;
	}
	
	public int randWalkBias(IObject obj, int dirBias){
		int dir;
		
		if ( Math.random() > 0.25) {
			dir = dirBias;
		} else {
			dir=getRandDir();
		}
	
		return dir;
	}
	
	public void peasantTakeLand(){
		IPeasant peasants[]=getPeasants();
		if (peasants != null) {
			for ( int i=0; i < peasants.length; i ++){
				move(peasants[i],MOVE_N);
			}
		}
	}
	
	public boolean knightCapture(IKnight knight){
		for ( int i = 1; i < 9; i++) {
			// find the position
			Point np= World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			
			if (np!= null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if ( object != null && !object.getRuler().equals(knight.getRuler())){
					
					capture(knight, i);
					return true;
					
				}
				
			}
			
		}
		return false;
	}
	
	public boolean CanCapture(IKnight knight, int dir){
		int x,y;
		x=knight.getX();
		y=knight.getY();
		World.getPositionAfterMove(x,y,dir);
		IObject obj=World.getObjectAt(x,y);
		
		if(obj==null){
			return false;
		}
		
		int ic = getClosestCastle(knight.getX(),knight.getY());
		
		
		if (obj.equals(World.getOtherCastles()[ic])){
		//if (obj.isAlive()){
			System.out.println("kill castle");
			capture(knight, dir);
			return true;
		}
		IKnight knights[]=World.getOtherKnights();
		int size = knights.length;
		for (int i=0; i < size; i++) {
			if (obj.equals(knights[i])){
				//if (obj.isAlive()){
					System.out.println("kill knights");
					capture(knight, dir);
					return true;
				}
		}
		return false;
	}
	
	public void moveAndCapture(IKnight knight, IPeasant peasant){
		if (peasant==null || !peasant.isAlive()){
			return;
		}
		
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if ( np != null){
			
			if (peasant.equals(World.getObjectAt(np.x, np.y))){	
				capture(knight,dir);
			}else{
				move(knight,dir);
			}
		
		}
		
	}
	
	public int moveKnight(IKnight knight, int x, int y){
		return knight.getDirectionTo(x,y);
	}
	
	public int movePeasant(IPeasant peasant, int x, int y){
		return peasant.getDirectionTo(x,y);
	}
	
	public int getClosestCastle(int x, int y){
		ICastle castles[]=World.getOtherCastles();
		int j, dist, mdist;
		j=0;
		mdist=castles[j].getDistanceTo(x,y);
		for (int i = 1; i < castles.length; i++){
			dist=castles[i].getDistanceTo(x,y);
			if (dist < mdist){
				mdist=dist;
				j=i;
			}
		}
		return j;
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		iPrevOwnLand=iOwnLand;
		iOwnLand=getOwnedLandCount();
		
		int owned= iPrevOwnLand-iOwnLand;
		Math.abs(owned);
		if(owned > 5 ){
			bMovePeasantsCenter=false;
		} else {
			bMovePeasantsCenter=true;
		}
		
		long test;
		// =(int)Math.random()*8;
		//test=Math.round(Math.random()*100%8);
		//System.out.println("test: "+test);

		Castles= getCastles();
		Peasants=getPeasants();
		Knights=getKnights();
		int i;
		int size;
		size = Castles.length;
		for ( i=0; i>size; i++){
			createPeasants(Castles[i]);
			createKnights(Castles[i]);
		}

		

				
		size= Peasants.length;
		
		int dir=MOVE_N;
		int temp;
		for (i = 0; i < size; i++){
			peasant=Peasants[i];
			
			if ( bMovePeasantsCenter == true ) {	
				
				if (peasantWanderState==0){
				
					
					dir=randWalkBias(peasant, peasant.getDirectionTo(36,32));//center
					temp=peasant.getX()-36;
					Math.abs(temp);
					if (temp < 5 ){
						peasantWanderState=1;
					}
				}else if (peasantWanderState==1){
				
					dir=randWalkBias(peasant, peasant.getDirectionTo(36,50));
					temp=peasant.getY()-50;
					Math.abs(temp);
					if (temp < 5 ){
							peasantWanderState=2;
					}
				}else if (peasantWanderState==2){
					dir=randWalkBias(peasant, peasant.getDirectionTo(54,32));
					temp=peasant.getX()-54;
					Math.abs(temp);
					if (temp < 5 ){
							peasantWanderState=3;
					}
				} else if (peasantWanderState==3){{
								dir=randWalkBias(peasant, peasant.getDirectionTo(36,18));
								temp=peasant.getY()-18;
								Math.abs(temp);
								if (temp < 5 ){
									peasantWanderState=4;
								}
							}
				} else if (peasantWanderState==4){
					dir=randWalkBias(peasant, peasant.getDirectionTo(18,32));
					temp=peasant.getX()-18;
					Math.abs(temp);
					if (temp < 5 ){
						peasantWanderState=0;
					}
				}
			
			} else {
				dir = getRandDir();
			}
			//dir=randWalkBias(peasant,moveAwayCastle(Castles[0],peasant));
			//
			move(peasant,dir);
		}
		
		size = Knights.length;
		int ic;
		for (i = 0; i < size; i++){
			knight=Knights[i];
			move(knight,getRandDir());
			ic=getClosestCastle(knight.getX(), knight.getY());
			dir=moveKnight(knight, 
				World.getOtherCastles()[ic].getX(),World.getOtherCastles()[ic].getY());
			
			//dir=randWalkBias(knight,moveAwayCastle(Castles[0],knight));
			//dir = getRandDir();
			//CanCapture(knight,dir);
			//move(knight,dir);
			CanCapture(knight,dir);
			move(knight,dir);
			
		
		}
		

		// opening 
		//		create peasants
		//		create knights
		//		walk away from castle and random walk...
		//		
		//	
		// middle - expand
		// 		knight move towards center... attack peasants
		
		// not getting enough land
		//		trigger: delta land gain is zero		
		//		action: create more peasants and peasants wander more
		//
		// end - attack
		// knights attack nearest castle or if next to enemy
		// peasants attack it
		// 
		// peasants walk towards center

	}
}