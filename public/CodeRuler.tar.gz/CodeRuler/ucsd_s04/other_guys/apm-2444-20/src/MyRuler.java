import com.ibm.ruler.*;
import java.util.*;
import java.awt.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	 
	 protected Random rand = new Random();
	 
	 
	public String getRulerName() {
		return "Artificial Life";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 20";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */

    
    public void moveAndKillPeasant(IKnight knight, IPeasant peasant)
    {
    	
    	

		int x = knight.getX();
		int y = knight.getY();
		int[] value = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		
		//(1,8)
		//int dir = rand.nextInt(8)+1;
		//int next_dir = dir;
		for(int i=1; i<=8; i++)
		{
			
			//next_dir = ((next_dir + 1) % 8) + 1;
			
			//Point move_pos = World.getPositionAfterMove(x, y, next_dir);
			Point move_pos = World.getPositionAfterMove(x, y, i);
			
			if (move_pos == null)
			{
				//value[next_dir] = -1;
				value[i] = -1;
				continue;
				
			}
			
			
			IRuler owner = World.getLandOwner(move_pos.x, move_pos.y);
			
			if (this == owner)
			{
				//value[i] = 0;
				continue;
			}
	
			IObject obj = World.getObjectAt(move_pos.x, move_pos.y);
			
			
			if (obj != null && obj.getRuler() != this)
			{
			
				//move(peasant, i);
				//return;
				//value[i] = 1;
				capture(knight, i);
				//capture(knight, next_dir);
				return;
			}
			
			
			
		}
		
		
		/*
		while(true)
		{
		
			int d = rand.nextInt(8) + 1;
			
			if (value[d] != -1)
			{
				move(peasant, d);
				return;
			}
		}
		
    	*/
		
				if (peasant == null || !peasant.isAlive())
					return;
    		
				int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
    	
				Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
    	
				if (np != null)
				{
					if (peasant.equals(World.getObjectAt(np.x, np.y)))
						capture(knight,dir);
					else
						move(knight, dir);	
				}
				
    	
    	
    	
    }
	public void moveAndCaptureCastle(IKnight knight, ICastle castle)
		{
			if (castle == null)
				return;
    		
			int dir = knight.getDirectionTo(castle.getX(), castle.getY());
    	
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
    	
			if (np != null)
			{
				if (castle.equals(World.getObjectAt(np.x, np.y)))
					capture(knight,dir);
				
				else if (World.getObjectAt(np.x, np.y) == null)
				{
					move(knight, dir); 
				}
				else if (World.getObjectAt(np.x, np.y).getRuler() != this)
				{
					capture(knight, dir);
				}
				else
					move(knight, rand.nextInt(8) + 1);	
			}
		}
    
	public void movePeasant(IPeasant peasant)
	{
		int x = peasant.getX();
		int y = peasant.getY();
		int[] value = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		
		//(1,8)
		int dir = rand.nextInt(8)+1;
	    int next_dir = dir;
		for(int i=1; i<=8; i++)
		{
			
			next_dir = ((next_dir + 1) % 8) + 1;
			
			Point move_pos = World.getPositionAfterMove(x, y, next_dir);
			//Point move_pos = World.getPositionAfterMove(x, y, next_dir);
			
			if (move_pos == null)
			{
				value[next_dir] = -1;
				//value[i] = -1;
				continue;
				
			}
			
			
			IRuler owner = World.getLandOwner(move_pos.x, move_pos.y);
			
			if (this == owner)
			{
				//value[i] = 0;
				continue;
			}
	
			IObject obj = World.getObjectAt(move_pos.x, move_pos.y);
			
			
			if (obj == null)
			{
			
				//move(peasant, i);
				//return;
				//value[i] = 1;
				//move(peasant, i);
				move(peasant, next_dir);
				return;
			}
		}
		
		while(true)
		{
		
			int d = rand.nextInt(8) + 1;
			
			if (value[d] != -1)
			{
				move(peasant, d);
				return;
			}
		}
		
	}
	 
	IRuler[] otherRulers;
	//ICastle[] otherCastles;
	IPeasant[] otherPeasants;
	IKnight[] otherKnights; 
	int[][] world; 
	int min_castle = 0; 
	 
	public void initialize() {
		// put implementation here
		
		otherRulers = World.getOtherRulers();
		//otherCastles = World.getOtherCastles();
		otherPeasants = World.getOtherPeasants();
		otherKnights = World.getOtherKnights();
		
		ICastle[] ourCastle = getCastles();
				
	}
	
	
	

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		
		IKnight[] knights = getKnights();
		int num_k = knights.length;
			
		IPeasant[] peasants = getPeasants();
		int num_p = peasants.length;
		
		ICastle[] castles = getCastles();
		int num_c = castles.length;
		
		ICastle[] otherCastles = World.getOtherCastles();
		IPeasant[] otherP = World.getOtherPeasants();
		int num_op = otherP.length;
		
		//int[] p_index = new int[num_k];
	    //int[] min = new int[num_k];
	    /*
	    for (int i=0; i<num_op; i++)
	    {
	    	int dist = otherP[i].getDistanceTo();	
	    	
	    	
	    }
		*/
		for(int i=0; i<num_c; i++)
		{			
		
			if (num_p > 10)
				createKnights(castles[i]);
			else
				createPeasants(castles[i]);
				
		}		
		
        //attack nearest castle
		int p_index = 0;
		int j=0;
		for(int i=0; i<num_k; i++)
		{
			
			if (i<3)
				moveAndCaptureCastle(knights[i], otherCastles[0] );
			else
			     moveAndKillPeasant(knights[i], otherP[j]);
			
			
			if (j < num_op)
			{
							j++;
			}	
			//moveAndCaptureCastle(knights[i], otherCastles[0]  );
		}

        //move peasants
        for (int i=0; i<num_p; i++)
        {
			//move(peasants[i], 1);
        	//move(peasants[i], rand.nextInt(8) + 1);
        	movePeasant(peasants[i]);	
        }

		
	}
	
	
	
	
}