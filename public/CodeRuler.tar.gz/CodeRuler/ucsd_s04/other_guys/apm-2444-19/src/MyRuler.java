import com.ibm.ruler.*;
import java.awt.Point;
import java.util.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Border_Patrol";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 19";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {	
		p = getPeasants();
		int size = p.length;
		dir = new int[66];
		for(int i = 0; i < 66; i++){
			dir[i] = rand.nextInt(8)+1;
		}		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		IKnight[] k = getKnights();
		otherP = World.getOtherPeasants();
		otherC = World.getOtherCastles();
		int i = p.length;
		int kDir;		
		Point np;
	
		
		/*
		if( k[0].getDistanceTo( otherP[i].getX(), otherP[i].getY() ) < 44 ){
			move(k[0], k[0].getDirectionTo( otherP[i].getX(), otherP[i].getY() ) );
		}else{
			move(k[0], k[0].getDirectionTo(32,36) );
		}*/
		move(k[0], k[0].getDirectionTo( otherP[2].getX(), otherP[2].getY() ) );
		
		
		for( i = 1; i < k.length; i++){							
			kDir = k[i].getDirectionTo(otherC[0].getX(),otherC[0].getY());
			np = World.getPositionAfterMove(k[i].getX(), k[i].getY(), kDir);
			if( (np.x == otherC[0].getX()) && (np.y == otherC[0].getY()) ){
				capture(k[i], kDir);
			}else{
				move(k[i], kDir);
			}
		}
				
		p = getPeasants();
		for( i = 3; i < p.length; i++){	
				
			np = World.getPositionAfterMove(p[i].getX(), p[i].getY(), dir[i]);
			
			if( np == null ){				
				dir[i] = rand.nextInt(8)+1;				
			}else if( World.getObjectAt(np.x,np.y) != null ){
				dir[i] = rand.nextInt(8)+1;
			}
			/*					
			if( World.getLandOwner(np.x,np.y).equals(k[0].getRuler()) ){				
				dir[i] = rand.nextInt(8)+1;	
			}*/
			move(p[i], dir[i]);			
		}
		for( i = 0; i < 3; i++){
			move(p[i], p[i].getDirectionTo(otherP[i].getX(),otherP[i].getY() ) );
		}
		
		ICastle[] c = getCastles();
		for( i = 0; i < c.length; i++){
			if(getOwnedLandCount() < 500){
				createPeasants(c[i]);
			}else{
				createKnights(c[i]);
			}
		}
		
	}	
	private IPeasant[] p;
	private IPeasant[] otherP;
	private ICastle[] otherC;
	private IObject target;
	private int dir[];
	private Random rand = new Random();

	/*
					np = World.getPositionAfterMove(p[i].getX(), p[i].getY(), dir[i]);
					run = false;
					for(int eye = -1; eye < 2; eye++){
						for(int kay = -1; kay < 2; kay++){
							target = World.getObjectAt(np.x+eye, np.y+kay);
							if ( target != null ){						
								 if( target.getRuler() != p[i].getRuler() ){
									run = true;
								 }else{
									run = false;
									eye = kay = 3;
								 }
							}
						}
					}
					*/
	
}