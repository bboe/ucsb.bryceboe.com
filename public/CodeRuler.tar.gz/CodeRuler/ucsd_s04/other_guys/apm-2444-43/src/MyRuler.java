import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;


/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "gravity";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 43";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		rGen = new Random();
		peasants = new Vector();
		knights = new Vector();
		castles = new Vector();
		alt = 0;
		IPeasant[] ps = this.getPeasants();
		pOrders = new Hashtable();
		IKnight[] ks = this.getKnights();
		ICastle[] cs = this.getCastles();
		for(int i = 0; i < ps.length; i++)
			peasants.add(ps[i]);
		for(int i = 0; i < ks.length; i++)
			knights.add(ks[i]);
		for(int i = 0; i <cs.length; i++)
			castles.add(cs[i]);
		
		
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		Iterator itr = peasants.iterator();
		IPeasant[] psnts = this.getPeasants();
		IKnight[] knights = this.getKnights();
		ICastle[] castles = this.getCastles();
		//while(itr.hasNext()){
		for(int i = 0; i < psnts.length; i++)
			move(psnts[i],getPGravity(psnts[i].getX(), psnts[i].getY()));
		for(int i = 0; i < knights.length; i++)
		{
			if (!knightCapture(knights[i]))
				move(knights[i],getKGravity(knights[i].getX(), knights[i].getY()));			
		}
		for(int i = 0; i < castles.length; i++)
		{
			if(this.getPeasants().length > 20)
				this.createKnights(castles[i]);
			else this.createPeasants(castles[i]);
			alt = 1- alt;
		}
		
		
	
		
	}
	protected boolean knightCapture(IKnight knight)
	{
		for(int i=1; i < 9; i++)
		{
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			if(np!= null)
			{
				IObject object = World.getObjectAt(np.x, np.y);
				if(object != null && !object.getRuler().equals(knight.getRuler()))
				{
					capture(knight, i);
					return true;
				}
			}
		}return false;
	}
	
	protected int getKGravity(int x, int y)
	{
		moveVector mv = new moveVector(rGen.nextInt(8) + 1,1);
		ICastle[] cstls = World.getOtherCastles();
		IPeasant[] psnts = World.getOtherPeasants();
		IKnight[] knights = World.getOtherKnights();
		for(int i=0 ; i < cstls.length; i ++)
		{
			int dist = cstls[i].getDistanceTo(x,y);
			int dir = cstls[i].getDirectionTo(x, y);
			mv = mv.add(new moveVector(dir, -1000 * 2*i));
		}
		for(int i=0 ; i < psnts.length && i < 20; i ++)
				{
					int dist = psnts[i].getDistanceTo(x,y);
					int dir = psnts[i].getDirectionTo(x, y);
					mv = mv.add(new moveVector(dir, -10/(dist + 5)));
				}
//		for(int i=0 ; i < knights.length && i <20; i ++)
//						{
//							int dist = knights[i].getDistanceTo(x,y);
//							int dir = knights[i].getDirectionTo(x, y);
//							mv = mv.add(new moveVector(dir, -5));
//						}
		if(x < 5)
				mv = mv.add(new moveVector(3,100));
				if( x > 67)
				mv = mv.add(new moveVector(7,100));
				if(y < 5)
				mv = mv.add(new moveVector(5,100));
				if(y > 59)
				mv = mv.add(new moveVector(1,100));
				return mv.getDir();
	}
	protected int getPGravity(int x, int y)
	{
		evilKnights = World.getOtherKnights();
		int[] directions = {0,0,0,0,0,0,0,0}; 
		moveVector mv = new moveVector(rGen.nextInt(8) + 1,rGen.nextInt(5) + 1);
		int maxDir = 1;
		int maxDist = 0;
		boolean zeros = false;
		int firstZero = 1;
		IPeasant[] myps = this.getPeasants();
		for(int i = 0; i <  evilKnights.length && i < 10; i++)
		{
			int dist = evilKnights[i].getDistanceTo(x, y);
			int dir = (evilKnights[i].getDirectionTo(x, y));
			mv = mv.add(new moveVector(dir, 100/(dist + 5)));
			
		}
		for(int i = 0; i <  myps.length && i < 10; i++)
				{
					int dist = myps[i].getDistanceTo(x, y);
					int dir = (myps[i].getDirectionTo(x, y));
					mv = mv.add(new moveVector(dir, 100/(dist + 5) ));
			
				}
		ICastle[] cstl = this.getCastles();
		for(int i = 0; i < cstl.length; i++)
		{
			mv = mv.add(new moveVector(cstl[i].getDirectionTo(x,y), 10));
		}
		ICastle[] cstl2 = World.getOtherCastles();
		for(int i=0 ; i < cstl2.length; i ++)
				{
					int dist = cstl2[i].getDistanceTo(x,y);
					int dir = cstl2[i].getDirectionTo(x, y);
					mv = mv.add(new moveVector(dir, -100 * i/(dist + 5)));
				}
		if(x < 5)
		mv = mv.add(new moveVector(3,100));
		//else if (x < 30)
		//mv = mv.add(new moveVector(3,rGen.nextInt(100) + 1));
		if( x > 67)
		mv = mv.add(new moveVector(7,100));
		//else if (x > 30)
		//mv = mv.add(new moveVector(7,rGen.nextInt(100) + 1));
		if(y < 5)
		mv = mv.add(new moveVector(5,100));
		//else if(y < 30)
		//mv = mv.add(new moveVector(5,rGen.nextInt(100) + 1));
		if(y > 59)
		mv = mv.add(new moveVector(1,100));
		//else if(y> 30)
		//mv = mv.add(new moveVector(1,rGen.nextInt(100) + 1));
		
		if(World.getLandOwner(x+1,y)!= this)
		mv = mv.add(new moveVector(3,100));
		if(World.getLandOwner(x-1,y)!= this)
				mv = mv.add(new moveVector(7,100));
		if(World.getLandOwner(x+1,y+1)!= this)
				mv = mv.add(new moveVector(2,100));
		if(World.getLandOwner(x+1,y-1)!= this)
				mv = mv.add(new moveVector(4,100));
		if(World.getLandOwner(x-1,y+1)!= this)
				mv = mv.add(new moveVector(8,100));
		if(World.getLandOwner(x-1,y-1)!= this)
				mv = mv.add(new moveVector(6,100));
		if(World.getLandOwner(x,y+1)!= this)
				mv = mv.add(new moveVector(1,100));
		if(World.getLandOwner(x,y-1)!= this)
				mv = mv.add(new moveVector(5,100));
		return mv.getDir();
		
		
	}
	
	protected class moveVector
	{
		
		private int Vdir;
		private int Vpower;
		private Point pt;
		public moveVector(int dir, int power)
		{
			 pt = new Point(0,0);
			 Vdir = dir; Vpower = power;
			if(Vdir == 1)
				{
					pt.y = Vpower;
				}
				else if(Vdir == 2)
				{
					pt.y = Vpower/2;
					pt.x = Vpower/2;
				}
				else if(Vdir == 3)
				{
					pt.x = Vpower;
				}
				else if(Vdir == 4)
				{
					pt.y = - Vpower/2;
					pt.x = Vpower/2;
				}
				else if(Vdir == 5 )
				{
					pt.y = - Vpower;
				}
				else if (Vdir == 6)
				{
					pt.y = -Vpower/2;
					pt.x = -Vpower/2;
				}
				else if (Vdir == 7)
				{
					pt.x = -Vpower;
				}
				else if(Vdir == 8)
				{
					pt. y = Vpower/2;
					pt.x =-Vpower/2;
				}
		}
		public moveVector add(moveVector v)
		{
			Point np = new Point();
			double power;
			int newPower;
			int newDir = 1;
			Point zero = new Point(0,0);
			np.x = this.pt.x += v.pt.x;
			np.y = this.pt.y += v.pt.y;
			power = zero.distance(np);
			newPower = (new Integer((int)power)).intValue();
			if( np.y == 0)
			{
				if(pt.x > 0)
					newDir = 3;
				else newDir = 5;
			}
			else if(np.x == 0)
			{
				if(pt.y>0) newDir = 1; else newDir = 5;
			}
			else if(np.x > 0 && np.y > 0) newDir = 2;
			else if(np.x>0 && np.y < 0) newDir = 4;
			else if(np.x < 0 && np.y> 0)newDir = 8;
			else if(np.x< 0 && np.y<0)newDir = 6;
			return new moveVector(newDir, newPower);
			
		}
		public int getDir()
		{
			return Vdir;
		}
		public int getPower()
		{
			return Vpower;
		}
		
		
	}
	//Information about our assets
	protected Random rGen;
	protected Vector peasants;
	protected Vector knights;
	protected Vector castles;
	protected Vector kGravity;
	protected Vector pGravity;
	protected Hashtable pOrders;
	protected int alt;
	//Information about enemy assets
	protected IKnight[] evilKnights;
	protected Vector evilCastles;
}