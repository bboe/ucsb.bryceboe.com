import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	Vector otherCastles = new Vector();
	int[] moveXzero = {2,3,4};
	int[] moveYzero = {4,5,6};
	int[] moveX64 = { 6,7,8};
	int[] moveY72 = { 8,1,2}; 
	static int count = 0;
	static int select;
	static int getCastle = 0;
	static int numCastles= 0;
	/*
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "zzzzzz";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team50";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		int distance;
		//	get position of other castles
		ICastle[] ic = World.getOtherCastles();
		int castleX, castleY;
		for (int i = 0; i < ic.length; i++) {
			castleX = ic[i].getX();
			castleY = ic[i].getY();
			Position p = new Position(castleX, castleY);
			otherCastles.add(p);
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		int landOwned;
		ICastle[] castle= getCastles();
		//get how much land we have
		landOwned = getOwnedLandCount();
		
		// moving people
		peasantMove();
		knightMove();
		
		if(landOwned < 500) {
			count = count++ % 3;
			switch(count) {
				case 1:
					createKnights(castle[0]);
					break;
				case 2:
					createPeasants(castle[0]);
					break;
				case 3:
					createPeasants(castle[0]);
					
			}
		}
	}
	
	private void peasantMove() {
		IPeasant[] peasant = getPeasants();
		Random rand = new Random();
		int size = peasant.length;
		int moveTo;
		for (int i = 0; i<size; i++) {
			moveTo = rand.nextInt(8) + 1;
			Point p = World.getPositionAfterMove(peasant[i].getX(), 
						peasant[i].getY(),moveTo);
			if (p != null) {
				move (peasant[i], moveTo);					
			}
			
			else {
				if(peasant[i].getX() == 0) {
					move(peasant[i], moveXzero[rand.nextInt(3)]);
				}
				
				else if(peasant[i].getX() == World.WIDTH) {
					move(peasant[i], moveX64[rand.nextInt(3)]);
				}
				else if(peasant[i].getY() == World.HEIGHT) {
					move(peasant[i], moveY72[rand.nextInt(3)]);
				}
				
				else if(peasant[i].getY() == 0) {
					move(peasant[i], moveYzero[rand.nextInt(3)]);
				}
			}
		}
	}
	
	private void knightMove() {
		    IKnight[] knight = getKnights();
		 	int dir;
		 	int temp = numCastles;
		    numCastles = getCastles().length;

		    Position p = (Position)otherCastles.get(getCastle);
		if(temp < numCastles) { getCastle++; }
			for (int i = 4; i<knight.length; i++) {
				
				dir = knight[i].getDirectionTo(p.getX(), p.getY());
				move(knight[i], dir);
				capture(knight[i], dir);
			}
	}
	
	public class Position {
		int x;
		int y;
		
		
		public Position(int x, int y) {
			this.x = x;
			this.y = y;
		}
		
		public int getX() { return x; }
		public int getY() { return y; }
	}
}