import java.awt.Point;
import java.util.Hashtable;
import java.util.Random;
import java.util.Vector;

import com.ibm.ruler.ICastle;
import com.ibm.ruler.IKnight;
import com.ibm.ruler.IObject;
import com.ibm.ruler.IPeasant;
import com.ibm.ruler.IRuler;
import com.ibm.ruler.Ruler;
import com.ibm.ruler.World;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */

public class MyRuler extends Ruler {
	
	public static final int DIRECTION = 3;
	
	public static final int OUR_KNIGHT = 0;
	public static final int ENEMY_KNIGHT = 0;
	
	public static final int OUR_TERR = 0;
	public static final int ENEMY_TERR = 8;
	
	public static final int ENEMY_PEASANT = 2;
	public static final int OUR_PEASANT = 0;
	
	public static final int EMPTY_TERR = 6;
	
	private int initDirection;
	
	private int nextNexDirection = 1;
	
	protected Random rand = new Random();
	
	private Vector lastMoves;
	
	private Hashtable friendly;
	
	private int pLastNumObj;
	private int kLastNumObj;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Team 17";
		
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 17";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		
		int direction = 1;
		this.friendly = new Hashtable();
		
		this.lastMoves = new Vector();
		
		IKnight[] knights = this.getKnights();
		for (int i=0; i<knights.length; i++) {
			this.friendly.put(new Integer(knights[i].getId()), knights[i]);
		
			
		}
		
		IPeasant[] peasants = this.getPeasants();
		for (int i=0; i<peasants.length; i++) {
			this.friendly.put(new Integer(peasants[i].getId()), peasants[i]);
		
			this.lastMoves.add(new Integer(direction));
			direction = (direction % 8) + 1;
		}
		
		this.pLastNumObj = peasants.length;
		this.kLastNumObj = knights.length;
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		
		IKnight[] knights = getKnights();
		IPeasant[] peasents = this.getPeasants(); 
		
		int pobjects = peasents.length;
		int kobjects = knights.length;
		
		if (pobjects > 17){
			if (kobjects < 13) {
				ICastle[] castles = this.getCastles();
				for(int i = 0; i<castles.length; i ++) {
					this.createKnights(castles[i]);	
				}
			} else {
				ICastle[] castles = this.getCastles();
				for(int i = 0; i<castles.length; i ++) {
					this.createPeasants(castles[i]);	
				}
			}
		} else {
			ICastle[] castles = this.getCastles();
			for(int i = 0; i<castles.length; i ++) {
				this.createPeasants(castles[i]);	
			}
		}
		
		if (pobjects > this.lastMoves.size()) {
			this.nextNexDirection = (this.nextNexDirection % 8) + 1;
			
			this.lastMoves.add(new Integer(this.nextNexDirection));
		}
		
		if (lastMoveTime > 400) {
			pobjects = this.pLastNumObj - 2;
			kobjects = this.kLastNumObj - 2;
		}
		
		for(int i=0; i<pobjects; i++) {
			movePeasant(peasents[i], i);
		}
		
		for(int i=0; i<kobjects; i++) {
			moveKnight(knights[i], i);
		}
		
		this.pLastNumObj = pobjects;
		this.kLastNumObj = kobjects;
	}
	
	
	private void moveKnight(IKnight knight, int knightNumber) {
		
		ICastle attackCastle = null;
	
		ICastle[] castles = World.getOtherCastles();
		if (castles != null && castles.length > 0) {
			attackCastle = castles[castles.length - 1];
		}
		
		int direction = knight.getDirectionTo(attackCastle.getX(), attackCastle.getY());
		
		Point point = World.getPositionAfterMove(knight.getX(), knight.getY(), direction);
		
		
		IObject obj = World.getObjectAt(point.x, point.y);
		if (obj != null){
			if (!obj.getRuler().equals(knight.getRuler())){
				this.capture(knight,direction); 
			}
			else{
				this.move(knight, (direction % 8) + 1);
			}
		}
		else {
			this.move(knight, direction);
		}

		
		
	}
	
	
	private int calcKnight(Point point) {
		
		int pvalue = 0;
	
		if (World.getObjectAt(point.x, point.y) != null) {
			return 0;
		}
	
		if (rand.nextInt(3) <= 1){
			pvalue += 3;
		}
	
		IRuler ruler = World.getLandOwner(point.x, point.y);
		if (ruler == null) {
			pvalue += this.EMPTY_TERR;
		} else {
			if (ruler != this) {
				pvalue += this.ENEMY_TERR;
			} else {
				pvalue += this.OUR_TERR;
			}
		}
	
		for (int i=1; i<9; i++) {
			Point nextPoint = World.getPositionAfterMove(point.x, point.y, i);
		
			if (nextPoint != null) {
				IObject obj = World.getObjectAt(nextPoint.x, nextPoint.y);
			
				if (obj != null) {
					if (obj instanceof IKnight) {
						if (this.friendly.contains(new Integer(obj.getId()))){
							pvalue += this.OUR_KNIGHT;
						} else {
							pvalue += this.ENEMY_KNIGHT;
						}
				
					} else {  // peasant
						if (this.friendly.contains(new Integer(obj.getId()))){
							pvalue += this.OUR_PEASANT;
						} else {
							pvalue += this.ENEMY_PEASANT;
						}
					}
				}
			} 
		}


		return pvalue;
	}
	
	
	private void movePeasant(IPeasant peasant, int peasantNumber) {
		
		int[] pvalue = new int[8];
		
		int counter = 0;
		
		int direction;
		
		direction = ((Integer)this.lastMoves.elementAt(peasantNumber)).intValue();
		
		int max = 0;
		
		for (int i=0; i<pvalue.length; i++) {
			Point nextPoint = World.getPositionAfterMove(peasant.getX(), peasant.getY(), i+1);
			
			if (nextPoint == null) {
				pvalue[i] = 0;
			} else {
				pvalue[i] = calcPeasants(nextPoint);	
				
				if (i+1 == direction) {
					pvalue[i] += DIRECTION;
				}
			}
			
			if (pvalue[i] > pvalue[max]) {
				max = i;
			}
			
		}
		
		this.move(peasant, max+1);
		
		/*
		if (max < 8)
			this.lastMoves.set(peasantNumber, new Integer(max+1));
		*/
		
			
	}
	
	private int calcPeasants(Point point) {
		
		int pvalue = 0;
		
		if (World.getObjectAt(point.x, point.y) != null) {
			return 0;
		}
		
		if (rand.nextInt(3) <= 1){
			pvalue += 5;
		}
		
		IRuler ruler = World.getLandOwner(point.x, point.y);
		if (ruler == null) {
			pvalue += this.EMPTY_TERR;
		} else {
			if (ruler != this) {
				pvalue += this.ENEMY_TERR;
			} else {
				pvalue += this.OUR_TERR;
			}
		}
		
		for (int i=1; i<9; i++) {
			Point nextPoint = World.getPositionAfterMove(point.x, point.y, i);
			
			if (nextPoint != null) {
				IObject obj = World.getObjectAt(nextPoint.x, nextPoint.y);
				
				if (obj != null) {
					if (obj instanceof IKnight) {
						if (this.friendly.contains(new Integer(obj.getId()))){
							pvalue += this.OUR_KNIGHT;
						} else {
							pvalue += this.ENEMY_KNIGHT;
						}
					
					} else {  // peasant
						if (this.friendly.contains(new Integer(obj.getId()))){
							pvalue += this.OUR_PEASANT;
						} else {
							pvalue += this.ENEMY_PEASANT;
						}
					}
				}
			} 
		}
	
	
		return pvalue;
	}
	
	/*
	private int isSafe(Point point) {
		
		for (int i=1; i<9; i++) {
			System.out.println("point: "+ point);
			
			Point nextPoint = World.getPositionAfterMove(point.x, point.y, i);
			
			if (nextPoint != null) {
				
				IObject obj = World.getObjectAt(nextPoint.x, nextPoint.y);
				
				if (obj != null) {
					
					if (obj instanceof IKnight) {
						if (! this.friendly.contains(new Integer(obj.getId()))){
							return this.UN_SAFE;
						} else {
							return this.VERY_SAFE;
						}
						
					} else {  // peasant
						if (! this.friendly.contains(new Integer(obj.getId()))){
							return this.VERY_SAFE;
						} else {
							return this.UN_SAFE;
						}
					}
				}
			} else {
				return this.UN_SAFE;
			}
		}
		
		
		return this.SAFE;
	}
	*/
	
	
}