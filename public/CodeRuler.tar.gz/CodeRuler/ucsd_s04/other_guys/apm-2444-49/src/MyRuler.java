import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	public int part;
	
	protected Random rand = new Random();
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Drunk Ruler";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 49";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		part = 0;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		//System.out.println(lastMoveTime);
		ICastle [] castles = getCastles();
		//System.out.println(castles.length);
		if (castles.length == 1)
		{
			createPeasants(castles[0]);
		}
		else if (castles.length == 2)
		{
			createPeasants(castles[0]);
			createKnights(castles[1]);
		}
		else 
		{
			for (int i=0; i<castles.length; i++)
			{
				if (i % 3 == 0)
					createKnights(castles[i]);
				else
					createPeasants(castles[i]);
			}
		}
		IPeasant[] peasants = getPeasants();
		int psize = peasants.length;
		//int [] dirs=new int[psize];
		IKnight[] knights = getKnights();
				moveKnights(knights);
		for (int i = part; i < psize; i++){	
			movePeasant(peasants[i], i);
		}
		
		
	
		// put implementation here
	}
	public boolean capt(IKnight kn, int dir)
	{
		Point np;
		np = World.getPositionAfterMove(kn.getX(), kn.getY(), dir);
		if (np != null)
		{
			IObject object = World.getObjectAt(np.x, np.y);
			if (object != null && !object.getRuler().equals(kn.getRuler()))
			{
			
				capture(kn, dir);
				return true;
			}
		}
		return false;			
	}
	public void moveKnights (IKnight [] knight)
	{
		int size = knight.length;
		ICastle[] castles = World.getOtherCastles();
		int dir;
		Point np;
		
		//for (int i = 0; i<size; i++)
		//{
		//	move(knight[i], rand.nextInt(8) + 1);
		//}
				
		
		for (int i = 0; i<size; i++)
		{
			int cn = 0;
			if (castles.length !=0)
			{
				cn=i%castles.length;
			
				dir = knight[i].getDirectionTo(castles[cn].getX(), 
				castles[cn].getY());	
				if (!capt(knight[i], dir))
		 			move (knight[i], dir );
			}
			else
			{
				dir = rand.nextInt(8)+1;
				if (!capt(knight[i], dir))
					move (knight[i], dir );
			}
		}
		/*for (int i = castles.length; i < size; i++)
		{
			dir = knight[i].getDirectionTo(36, 32);
			if (!capt(knight[i], dir))
				move(knight[i], dir);
		}*/	
	}
	public void movePeasant(IPeasant pst, int ind)
	{
		int shift =  3*(ind)+1;
		if (ind > 10) shift = shift + 1;
		//Point [] corners = { new Point(shift, shift), new Point(32-shift, shift),
		//	new Point(32-shift, 36-shift), new Point(shift, 36-shift)};
		
		int cur_x = pst.getX();
		int cur_y = pst.getY();
		
		if (!(cur_x==shift || cur_x == 71-shift || 
				cur_y==shift || cur_y==63-shift))
		{
			int tx= shift;
			int ty = shift;
			
			int difx = cur_x - shift;
			int dify = cur_y - shift;
			if (difx > 36)
			{
				tx = 71-shift;
			}
			if (dify > 32)
			{
				ty = 63-shift;
			}
			move(pst, pst.getDirectionTo(tx, ty));
		}
		else
		{
			// vertucal down on the left
			if (cur_x==shift)
			{
				if (cur_y != 63-shift)
				{
					move(pst, pst.getDirectionTo(shift, 63- shift));
				}
				else
				{
					move(pst, pst.getDirectionTo(71-shift, 63-shift));
				}
			}
			
			// horizontal toright at the bottom
			else if (cur_y==63-shift)
			{
				if (cur_x != 71-shift)
				{
					 move(pst, pst.getDirectionTo(71-shift, 63-shift));
				}
				else
				{
					 move(pst, pst.getDirectionTo(71-shift, shift));
				}
			}
			// vertucal up on the right
			else if (cur_x==71-shift)
					 {
						 if (cur_y != shift)
						 {
							 move(pst, pst.getDirectionTo(71-shift, shift));
						 }
						 else
						 {
							 move(pst, pst.getDirectionTo(shift, shift));
						 }
					 }
			// horizontal toleft at the top
			else if (cur_y==shift)
					 {
						 if (cur_x != shift)
						 {
							 move(pst, pst.getDirectionTo(shift, shift));
						 }
						 else
						 {
							 move(pst, pst.getDirectionTo(shift, 63-shift));
						 }
					 }
			
		}
		
		
		/*int x;
		int y;
		IObject obj;
		if ((World.getCurrentTurn() % 3) == 0 )
			move(pst, pst.getDirectionTo(36, 32));
		else
		{   
			int dir =  rand.nextInt(8) + 1;
			Point np = World.getPositionAfterMove(pst.getX(), pst.getY(), dir);
			if (np != null)
			{
				if ((obj = World.getObjectAt(np.x, np.y)) instanceof IKnight)
				{
					if (obj.isAlive()) //&& !obj.getRuler().equals(pst.getRuler()))
					{
						move(pst, (dir + 3) % 8 + 1);		
					}			
				}
									
			}
			move (pst, dir);
		}*/
	}
}
	
