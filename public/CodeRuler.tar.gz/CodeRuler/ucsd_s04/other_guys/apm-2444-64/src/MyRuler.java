import com.ibm.ruler.*;
import java.awt.Point;
import java.util.Vector;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */


public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	
	class Area
	{
		public Area()
		{
		}
		double quality;
		
	}
	
	static final int n=4;
	Area areas[][]=new Area[n][n];
	
	Point kOrders[];
	Point pOrders[];
	
	Point knightClump;
	 
	double iangle;
	double iradius;
	boolean clumped;
	 
	public String getRulerName() {
		return "Sir Finn Crisp";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 64";
	}
	
	public void orderKnights()
	{
		/*
		IKnight[] k=getKnights();
		for(int i=0;i<k.length;++i)
		{
			int rDir = (int)(8*Math.random());
			move(k[i],rDir);
		}*/
		
		clumpKnights();
	}
	
	public void tryMove (IObject obj, int direction,int counter) {
		counter++;
		if(counter>8)
			return;
		direction = direction % 8 + 1;
		Point toPoint = World.getPositionAfterMove(obj.getX(), obj.getY(),
				direction);
		if(toPoint==null)
		{
			if(obj instanceof IPeasant)
			{
				IPeasant[] p=getPeasants();
				for(int i=0;i<p.length;++i)
				{
					pOrders[i].x=(int)(160*Math.random())-70;
					pOrders[i].y=(int)(160*Math.random())-60;
									
				}
			}
			
			//System.out.println("hitting edge");
			return;
		}
		
		//if(toPoint.x >= 72 || toPoint.x < 0 || toPoint.y>=64 || toPoint.y<0)
		//	tryMove (obj, direction+1,counter+1);
		IObject moveToObj = World.getObjectAt(toPoint.x, toPoint.y);
		if (moveToObj == null)
		{
			if(obj instanceof IPeasant)
				move((IPeasant)obj, direction);
			else
				move((IKnight)obj, direction);
		}
		else 
		{
			if(obj instanceof IKnight )
			{
				if(moveToObj instanceof IPeasant 
				|| moveToObj instanceof IKnight 
				|| moveToObj instanceof ICastle)
				{
					capture((IKnight)obj,direction);
				}
				else
					tryMove (obj, direction+1,counter+1);
			}
			else
				tryMove (obj, direction+1,counter+1);
		}
	}
	
	public void moveTo(IObject obj,Point p)
	{
		tryMove(obj,obj.getDirectionTo(p.x,p.y),0);
	}
	
	
	public void clumpKnights()
	{
		IKnight[] k=getKnights();
		int n2=k.length;
		
		for(int i=-n2/2;i<n2/2;++i)
		{
			moveTo(k[i+n2/2],new Point(knightClump.x+i,knightClump.y));
		}
		/*
		for(int i=-n2/4;i<n2/4;++i)
		{
			Point p = new Point(0,i);
			moveTo(k[i+n2],new Point(knightClump.x+i,knightClump.y));
		}*/
		
		
	}
	
	public void knightAttack()
	{
		IKnight[] k=getKnights();
		IKnight[] other_knights=World.getOtherKnights();
		IPeasant[] other_peasants=World.getOtherPeasants();
		
		Vector close_knights= new Vector();
		Vector close_peasants= new Vector();
		
		for(int i=0;i<other_peasants.length;++i)
		{
			if(other_peasants[i].getDistanceTo(knightClump.x,knightClump.y)<k.length)
			{
				close_peasants.addElement(other_peasants[i]);
			}
		}
		
		for(int i=0;i<other_knights.length;++i)
		{
			if(other_knights[i].getDistanceTo(knightClump.x,knightClump.y)<k.length)
			{
				close_knights.addElement(other_knights[i]);
			}
		}
		
		if(close_knights.size()==0 && close_peasants.size()==0)
		{
			clumpKnights();
			return;
		}
		
		if(close_peasants.size()!=0)
		{		
			for(int j=0;j<k.length;++j)
			{
				IPeasant prey;
				int closest=-1;
				for(int i=0;i<close_peasants.size();++i)
				{
					int distance = k[i].getDistanceTo(
						((IPeasant)close_peasants.get(i)).getX(),
						((IPeasant)close_peasants.get(i)).getY()
						);
					if(distance<0 || distance<closest)
					{
						closest=distance;
						prey=(IPeasant)close_peasants.get(i);
					}
				}
			}	
		}
		else if(close_knights.size()!=0)
		{
			for(int j=0;j<k.length;++j)
			{
				for(int i=0;i<close_knights.size();++i)
				{
					IKnight prey;
					int closest=-1;
					int distance = k[i].getDistanceTo(
						((IKnight)close_knights.get(i)).getX(),
						((IKnight)close_knights.get(i)).getY()
						);
					if(distance<0 || distance<closest)
					{
						closest=distance;
						prey=(IKnight)close_knights.get(i);
					}						
				}
				
			}	
		}
		else
			clumpKnights();
	}
	
	public void orderPeasants()
	{
		IPeasant[] p=getPeasants();
		for(int i=0;i<p.length;++i)
		{
			moveTo(p[i],pOrders[i]);
			//move(p[i],MOVE_E);		
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
	
		
	}
	public void update()
	{
		
		iangle=0;
		iradius=20;
		IPeasant[] p=getPeasants();
		// System.out.println("length is "+p.length);
		pOrders = new Point[p.length];
		// System.out.println("pOrders is "+pOrders.length);
		
		ICastle castle;
		ICastle baddie = World.getOtherCastles()[0];
				//System.out.println("knight clump at "+baddie.getX()+" "+baddie.getY());
				knightClump = new Point(baddie.getX(),baddie.getY());
		if(getCastles()!=null)
		{
				castle = getCastles()[0];
				createKnights(castle);
		}
		else
			castle = baddie;
			
		//knightClump = new Point(30,30);
		
		for(int i=0;i<p.length;++i)
		{
			iangle=i/((double)(p.length))*360.0;
			Point pp= new Point();
			//System.out.println("dist is "+p[i].getDistanceTo(castle.getX(),castle.getY()));
			if( p[i].getDistanceTo(castle.getX(),castle.getY())<iradius-1 )
			{
				pp.x = (int)(iradius*Math.cos(iangle)) + p[i].getX();
				pp.y = (int)(iradius*Math.sin(iangle)) + p[i].getY();
				pOrders[i]=pp;
			}
			else if (p[i].getDistanceTo(castle.getX(),castle.getY())>2)
			{
				pp.x=castle.getX();
				pp.y=castle.getY();
				pOrders[i]=pp;				
			}
			
			// System.out.println(iangle+" "+iradius);
				
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		update();
		orderPeasants();
		orderKnights();
	
	}
}