import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {

	protected Random rand = new Random();
	
	class Group {
		IKnight gknights[];
		IPeasant gpeasants[];
		int direction;
		
		private void moveGroup()
		{
			for(int i=0;i<MAX_KNIGHTS_PER_GROUP;i++)
			{
				if(gknights[i] != null)
				{
					capture(gknights[i], direction);
				}
			}
			for(int i=0;i<MAX_PEASANTS_PER_GROUP;i++)
			{
				if(gpeasants[i] != null)
				{
					move(gpeasants[i], direction);
				}
			}
		}
	}
	
	IKnight unassignedKnights[];
	IPeasant unassignedPeasants[];
	IKnight knights[];
	IPeasant peasants[];
	ICastle ourCastles[];
	ICastle theirCastles[];
	int distToCastle[];
	int peasantDir[];
	
	int MAX_NUM_GROUPS = 45;
	int MIN_KNIGHTS_PER_GROUP = 3;
	int MIN_PEASANTS_PER_GROUP = 5;
	int MAX_KNIGHTS_PER_GROUP = 3;
	int MAX_PEASANTS_PER_GROUP = 2;
	int MAX_NUM_CASTLES = 5;
	
	Group groups[];
	boolean freeGroup[];
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "MagiShoe";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 60";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		int x,y;
		
	//	knights = getKnights();
//		peasants = getPeasants();
	//	theirCastles = World.getOtherCastles();
	//	ourCastles = getCastles();
		
		peasantDir = new int[MAX_NUM_GROUPS];
	/*	for(int i =0;i<MAX_NUM_CASTLES;i++){
			x = castles[i].getX();
			y = castles[i].getY();
			distToCastle[i] = getDistanceTo(x,y);
		} */
		
	//nitGroups();
//createGroups();	
	}
	
	private int getFreeGroup()
	{
		for(int i=0;i<MAX_NUM_GROUPS;i++)
		{
			if(freeGroup[i])
				return i;
		}
		return -1;
	}
	
	private int getKnightDir(IKnight k)
	{
		Point newPos;
		int myx, myy;
		IObject foo;
		
		myx = k.getX();
		myy = k.getY();
		
		for(int i = 1; i < 9;i++)
		{
			newPos = World.getPositionAfterMove(myx,myy,i);
			if(newPos == null)
				continue;
			foo = World.getObjectAt(newPos.x,newPos.y);
			if(foo != null)
				if(foo.getRuler() != this)
					return i;
		}
		return 0;
	}
	private int getPeasantDir(IPeasant k)
	{
		Point newPos;
		int myx, myy;
		IObject foo;
		
		myx = k.getX();
		myy = k.getY();
		if((World.getCurrentTurn() % 100) < 50)
		{
		for(int i = 1; i < 9;i++)
		{
			newPos = World.getPositionAfterMove(myx,myy,i);
			if(newPos != null)
			{
				foo = World.getObjectAt(newPos.x,newPos.y);
				if(foo == null && World.getLandOwner(newPos.x, newPos.y) != this)
					return i;
			}
		}
		}
		else
		{
				for(int i = 8; i > 0;i--)
				{
					newPos = World.getPositionAfterMove(myx,myy,i);
					if(newPos != null)
					{
						foo = World.getObjectAt(newPos.x,newPos.y);
						if(foo == null && World.getLandOwner(newPos.x, newPos.y) != this)
							return i;
					}
				}
		}
		return 0;
	}
	
	private int min(int x, int y)
	{
		if(x<y)
			return x;
		return y;	
	}
	private int max(int x, int y)
	{
		if(x>y)
			return x;
		return y;	
	}
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		Point newPos;
		ourCastles = getCastles();
		theirCastles = World.getOtherCastles();
		knights = getKnights();
		peasants = getPeasants();
		int currCastle;
		int x,y,direction;
		
		if(World.getCurrentTurn() % 20 == 0)
			for(int i = 0;i<MAX_NUM_GROUPS;i++)
				peasantDir[i]= rand.nextInt(8) + 1;
		
		int kgroups = knights.length / MAX_KNIGHTS_PER_GROUP;
		int pgroups = peasants.length / MAX_PEASANTS_PER_GROUP;
		
		kgroups = max(kgroups, 1);
		pgroups = max(pgroups,1);
		for(int i=0;i<=kgroups;i++)
		{
			if(theirCastles.length > 0)
			{
				currCastle = i % theirCastles.length;
				for(int j=i*MAX_KNIGHTS_PER_GROUP;j<min(knights.length, ((i+1)*MAX_KNIGHTS_PER_GROUP));j++)
				{
					x = knights[j].getX();
					y = knights[j].getY();
					direction = getKnightDir(knights[j]);
					if(direction == 0)
						direction = knights[j].getDirectionTo(theirCastles[currCastle].getX(), theirCastles[currCastle].getY());
			
					newPos = World.getPositionAfterMove(x,y,direction);
					if(World.getObjectAt(newPos.x, newPos.y) == null)	
						move(knights[j], direction);
					else
						capture(knights[j],direction);	
				}
			}
			else
			{
				for(int j=i*MAX_KNIGHTS_PER_GROUP;j<min(knights.length,((i+1)*MAX_KNIGHTS_PER_GROUP));j++)
				{
					x = knights[j].getX();
					y = knights[j].getY();
					do{
						direction = rand.nextInt(8) + 1;
					}while((newPos = World.getPositionAfterMove(x,y,direction)) != null);
					
					if(World.getObjectAt(newPos.x, newPos.y) == null)	
						move(knights[j], direction);
					else
						capture(knights[j],direction);	
				}
			}
		}
		for(int i=0;i<=pgroups;i++)
		{
			for(int j=i*MAX_PEASANTS_PER_GROUP;j<min(peasants.length, ((i+1)*MAX_PEASANTS_PER_GROUP));j++)
			{
				direction = getPeasantDir(peasants[j]);
				if(direction == 0)
				{
					if(rand.nextInt(2) % 2 == 0)
						direction = peasantDir[i];
					else
						direction = rand.nextInt(8) + 1;	
				}
				move(peasants[j], direction);
			}
		}
		
		for(int i=0;i<ourCastles.length;i++)
		{
			if(knights.length < 10)
				createKnights(ourCastles[i]);
			else
			{
				if(i%2 == 0)
					createPeasants(ourCastles[i]);
				else
					createKnights(ourCastles[i]);
			}
		}
	
		//for(int i = 0;i<ourCastles.length;i++)
		//	createPeasants(ourCastles[i]);
		
	}
}