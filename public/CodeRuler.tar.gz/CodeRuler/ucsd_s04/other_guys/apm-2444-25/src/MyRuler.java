import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		//return "Gummybear 1 loves Sweet CottonCandy aka GISC";
		return "GummyBear" ;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 25";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
// put implementation here
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	 protected Random rand = new Random();

	public void orderSubjects(int lastMoveTime) {
	int old_curr_turn=World.getCurrentTurn();
		
	///while(true)//World.getCurrentTurn()!=World.MAX_TURNS)	
	//{
		//int new_curr_turn=World.getCurrentTurn();
		
		//if(new_curr_turn!=old_curr_turn)
		//{
		//	break;
		//}
		//1 Castle 10 peasants 10 knight
		
		//moving Knight
		IKnight[] knights = getKnights();
		IPeasant[] peasants = getPeasants();
		ICastle[] castle = getCastles();
	
		//createPeasant();
	
	
		int	sizep = peasants.length;
		for (int i = 0; i < sizep; i++) {
			
			CreateNew();
			int csize =castle.length;
									createKnights(castle[csize-1]);
			int next_movep; 
			next_movep=rand.nextInt(8);
			Point np = World.getPositionAfterMove(peasants[i].getX(),peasants[i].getY(),next_movep);
				if(np != null)// && !obj_check.getRuler().equals(knights[i].getRuler()))
				{
					//IObject obj_check = World.getObjectAt(np.x,np.y);
					//if (obj_check.isAlive()&& obj_check!=null && obj_check.getRuler().getRulerName().toString()!="GummyBear")
					move(peasants[i], next_movep + 1);
							
				}	
		}
		int	sizek = knights.length;
		
		//Random movement and Capture
		for(int i=0;i<6;i++)
		{
			CreateNew();
			int next_movek; 
						next_movek=rand.nextInt(8);
						Point np = World.getPositionAfterMove(knights[i].getX(),knights[i].getY(),next_movek);
							if(np != null)
							{
								move(knights[i],next_movek + 1);
								if (knightCapture(knights[i])==true)
								{
									move(knights[i],next_movek + 1);
								}
							}
		}
			
		for (int i = 6; i < sizek; i++) {
			CreateNew();
	
			int next_movek; 
			next_movek=rand.nextInt(8);
			Point np = World.getPositionAfterMove(knights[i].getX(),knights[i].getY(),next_movek);
				if(np != null)
				{
					
					move(knights[i],next_movek + 1);
					ICastle[] castle_other=World.getOtherCastles();
					int num_castles = castle_other.length;
					IObject obj_check = World.getObjectAt(np.x,np.y);
					//if (obj_check.)
					int seed = rand.nextInt(num_castles+1);
						move(knights[i],next_movek + 1);
						CaptureCastle(knights[i],castle_other[seed]);
						CreateNew();
						
				
				
							
				}
					
						
		}
		
		


	
	}
	
	
		
	public void moveAndCapturePeasant(IKnight knight, IPeasant peasant) {
		// return if the peasant is null or has already been captured
		if (peasant == null || !peasant.isAlive())
			return;
	
		// find the next position in the direction of the peasant
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			// if the peasant is in the adjacent square, capture it. Otherwise, try to keep moving
			if (peasant.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}
	
	

	public boolean knightCapture(IKnight knight) {
		for (int i = 1; i < 9; i++) {
			// find the position
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);

			// make sure the position is a valid move
			if (np != null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if (object != null && !object.getRuler().equals(knight.getRuler())) {
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}

public void CreateNew()
{
	
	IKnight[] knights = getKnights();
		IPeasant[] peasants = getPeasants();
		ICastle[] castle = getCastles();
	int ksize =knights.length;
	int psize = peasants.length;
	int csize =castle.length;
	while (csize!=0)
	{
		if (psize>ksize)
			createKnights(castle[csize-1]);
		else
			createPeasants(castle[csize-1]);
		csize--;
	}
	
	
}
	public void moveAndCaptureKnight(IKnight knight, IPeasant peasant) {
		// return if the peasant is null or has already been captured
		if (peasant == null || !peasant.isAlive())
			return;
	
		// find the next position in the direction of the peasant
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			// if the peasant is in the adjacent square, capture it. Otherwise, try to keep moving
			if (peasant.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}

	public void CaptureCastle(IKnight knight, ICastle castle) {
		if (castle == null || !castle.isAlive())
			return;
		CreateNew();
		
		int dir = knight.getDirectionTo(castle.getX(), castle.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			if (castle.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}
		
		
		
}