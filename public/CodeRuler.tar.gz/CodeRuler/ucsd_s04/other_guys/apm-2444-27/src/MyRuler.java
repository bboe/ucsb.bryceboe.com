import java.awt.Point;
import java.util.Random;

import com.ibm.ruler.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	static int[] dirs1 = {Ruler.MOVE_SW, Ruler.MOVE_N, Ruler.MOVE_SE};
	static int[] dirs2 = {Ruler.MOVE_W, Ruler.MOVE_SE, Ruler.MOVE_NE, Ruler.MOVE_SW, Ruler.MOVE_E};
	
	static int dir1 = dirs1[0];
	static int dir2 = dirs2[0];
	static int count1 = 0;
	static int count2 = 0;
	
	static IKnight[] enemyKnights;
	static IPeasant[] enemyPeasants;
	//static IKnight[] ourKnights;
	
	protected Random rand = new Random();
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "YGGL";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 27";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		
		//ICastle [] enemyCastles = World.getOtherCastles();
		
		enemyKnights = World.getOtherKnights();
		enemyPeasants = World.getOtherPeasants();
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
	
		
		//IKnight[] knights = getKnights();
		ICastle[] castles = getCastles();
		
		for (int i = 0; i < castles.length; i++)
		{
			createPeasants(castles[i]);
			createKnights(castles[i]);
		}
	
		//assignKnightsToKill();
		
		int knightSize = getKnights().length;
		


		if ( World.getOtherCastles().length > 0) {	
			assignKnightsToCastle(0, knightSize/2, 0);
			assignKnightsToCastle(knightSize/2 +1, knightSize, 1);
		}
		else {
			assignKnightsToKnights(0, knightSize/2);
			assignKnightsToPeasants(knightSize/2+1, knightSize);
		}
		
		assignPeasants();
		
		
	}

	public void assignKnightsToPeasants(int start, int end) {
		IKnight[] knights = getKnights();
		
		IKnight target = null;
		/*
		for (int j=0; j < enemyKnights.length; j++)
		{
			if (enemyKnights[j].isAlive())
				target = enemyKnights[j];
		}
		*/
		
		int nextTarget = 0;
		
		for (int k=start; k < end; k++)
		{
			
			if (nextTarget == (enemyPeasants.length - 1)) {
				enemyPeasants = World.getOtherPeasants();
				nextTarget = 0;
			}
			
			
			for (;nextTarget < enemyPeasants.length; nextTarget++) {
				if (enemyPeasants[nextTarget].isAlive()) {
					moveAndCapture( knights[k], enemyPeasants[nextTarget++]);
					break;
				}
				else {
					//
				}
			}
		}
	}

	public void assignKnightsToKnights(int start, int end) {
		IKnight[] knights = getKnights();
		
		IKnight target = null;
		/*
		for (int j=0; j < enemyKnights.length; j++)
		{
			if (enemyKnights[j].isAlive())
				target = enemyKnights[j];
		}
		*/
		
		int nextTarget = 0;
		
		for (int k=start; k < end; k++)
		{
			
			if (nextTarget == (enemyKnights.length - 1)) {
				enemyKnights = World.getOtherKnights();
				nextTarget = 0;
			}
			
			
			for (;nextTarget < enemyKnights.length; nextTarget++) {
				if (enemyKnights[nextTarget].isAlive()) {
					moveAndCapture( knights[k], enemyKnights[nextTarget++]);
					break;
				}
				else {
					//
				}
			}
		}
	}

	public void moveAndCapture(IKnight knight, IObject enemyKnight) {
		// return if the peasant is null or has already been captured
		if (enemyKnight == null || !enemyKnight.isAlive())
			return;
	
		// find the next position in the direction of the peasant
		int dir = knight.getDirectionTo(enemyKnight.getX(), enemyKnight.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			// if the peasant is in the adjacent square, capture it. Otherwise, try to keep moving
			if (enemyKnight.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}

	public void assignKnightsToCastle(int start, int end, int castle) {
		
		
		IKnight[] knights = getKnights();
		ICastle [] enemyCastles = World.getOtherCastles();
	
		int x;
		int y;
		
		if (enemyCastles.length>0) {
		
			 x = enemyCastles[castle].getX();
			 y = enemyCastles[castle].getY();
		}
		else {
			return;
		}
		
		int dir;
		Point np;
		IObject obj;
		
		if (end > knights.length) {
			end = knights.length;
		}
		
		for (int i = start; i < end; i++) {
				dir = knights[i].getDirectionTo(x, y);
				
				np = World.getPositionAfterMove(knights[i].getX(), knights[i].getY(), dir);
				
				if (np != null) {
					obj = World.getObjectAt(np.x,np.y);
					
					if (obj != null && !obj.getRuler().equals(knights[i].getRuler())) {
						capture(knights[i], dir);
						
					}
					else {
						move(knights[i], dir);
					}
				}
				else {
					for (int j=1; j < 9; j++) {
						if (j != dir) {
						
							np = World.getPositionAfterMove(knights[i].getX(), knights[i].getY(), j);
							
							if (np != null) {
								obj = World.getObjectAt(np.x,np.y);
					
								if (obj != null && !obj.getRuler().equals(knights[i].getRuler())) {
									capture(knights[i], j);
									
								}
								else {
									move(knights[i], dir);
								}
							}
					}
				}
			}
		}
				
	}
	
	public void assignPeasants() {
		/***
		IPeasant[] peasants = getPeasants();
		IObject obj;
		
		int size = peasants.length;
		
		for (int i = 0; i < size/2; i ++) {
			obj = null;
			
			Point np = World.getPositionAfterMove(peasants[i].getX(), peasants[i].getY(), dir1);
			if (np != null) {
			
				obj = World.getObjectAt(np.x,np.y);
			}
			else if (np == null || obj != null){
				dir2 = dirs2[(count2++)%dirs2.length];
			}
			move(peasants[i], dir1);
		}
		
		for (int i = size/2 + 1; i < dirs2.length; i ++) {
			
			obj = null;
			Point np = World.getPositionAfterMove(peasants[i].getX(), peasants[i].getY(), dir2);
			
			if (np != null) {
			
				obj = World.getObjectAt(np.x,np.y);
			}
			else if (np == null || obj != null){
				dir2 = dirs2[(count2++)%dirs2.length];
			}
			
			move(peasants[i], dir2);
		}
	}
	
	***/
	IPeasant[] peasants = getPeasants();
	int size = peasants.length;
	IObject obj;
	
	for (int i = 0; i < size; i ++) {
			obj = null;
			
			Point np = World.getPositionAfterMove(peasants[i].getX(), peasants[i].getY(), dir1);
			if (np != null) {
			
				obj = World.getObjectAt(np.x, np.y);
			}
			else if ((np == null) || (obj != null)){
				dir1 = dirs1[(count1++)%dirs1.length];
			}
			move(peasants[i], dir1);
	}
		
/***
	for (int i = 0; i < size; i++) {
		move(peasants[i], rand.nextInt(8) + 1);
	}
	***/
}

}

