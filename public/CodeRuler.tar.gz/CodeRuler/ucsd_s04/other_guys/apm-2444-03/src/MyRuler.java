import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;


/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "MR";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 3";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		//System.out.println("Runing");
	}

	protected Random rand = new Random();
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		//System.out.println("Moving");
		ICastle[]		myCastles = this.getCastles();
		IPeasant[]		myPeasants = this.getPeasants();
		IKnight[]		myKnights = this.getKnights();
		IPeasant		tempP;
		IKnight			tempK;
		ICastle			tempC;
		
		int				initNextLoc;
		boolean			movable = false;
		int				currentX;
		int				currentY;
		Object			ObjAtNextLoc;
		int counter = 0;
		int				realNextLoc;
		
		int firstTeam 	= myPeasants.length / 2;
		Point np;
		// Peasants first team ovement
		for ( int i = 0; i < firstTeam; ++i){
			//System.out.println("Loop1");
			tempP = myPeasants[i];
			initNextLoc = (i % 8) + 1;
			
			currentX = tempP.getX();
			currentY = tempP.getY();
			
			// check the next location if it is movable
			counter = 0;
			movable = false;
			while (movable == false){
				initNextLoc = (initNextLoc % 8 ) + 1;
				counter ++;
				np = World.getPositionAfterMove( currentX, currentY, initNextLoc);
				
				if ( np == null || np.x > 72 || np.x < 0 || np.y > 64 || np.y < 0){
					initNextLoc = (initNextLoc % 8 ) + 1;
				}
				else {

					// the land is not mine
					if ( World.getLandOwner(np.x, np.y) == null ||
					!World.getLandOwner(np.x, np.y).getRulerName().equals("MR")){
						if ( World.getObjectAt(np.x, np.y) == null){
							movable = true;			
						}
					}
					if ( counter >= 8){

							movable = true;			
							if (currentX > 36 && currentY > 32){
								initNextLoc = 8;
							}
							else if ( currentX < 36 && currentY <32){
								initNextLoc = 4;
							}
							else if ( currentX > 36 && currentY < 32){
								initNextLoc = 6;
							}
							else {
								initNextLoc = 2;
							}
					}
					
				}

			}
				
			this.move(tempP, initNextLoc);
		}
		

		//Peasants Second Team
		for ( int i = firstTeam; i < myPeasants.length; ++ i){
			
			initNextLoc = rand.nextInt(8) + 1;
			tempP = myPeasants[i];
			
			currentX = tempP.getX();
			currentY = tempP.getY();
			movable = false;
			counter = 0;
			while (movable == false){
				initNextLoc = (initNextLoc % 8 ) + 1;
				counter ++;
				np = World.getPositionAfterMove( currentX, currentY, initNextLoc);
				if ( np == null || np.x > 72 || np.x < 0 || np.y > 64 || np.y < 0){

				}
				else {
					// the land is not mine
					initNextLoc = (initNextLoc % 8 ) + 1;
					if ( World.getLandOwner(np.x, np.y) == null ||
					!World.getLandOwner(np.x, np.y).getRulerName().equals("MR")){
						if ( World.getObjectAt(np.x, np.y) == null){
							movable = true;			
						}
					}
					if ( counter >= 8){

							movable = true;		
						if (currentX > 36 && currentY > 32){
							initNextLoc = 8;
						}
						else if ( currentX < 36 && currentY <32){
							initNextLoc = 4;
						}
						else if ( currentX > 36 && currentY < 32){
							initNextLoc = 6;
						}
						else {
							initNextLoc = 2;
						}	

					}
					
				}
			
			}
			this.move(tempP, initNextLoc);
		}
		
		int CX = 0;
		int CY = 0;
		boolean kill = false;
		if ( myCastles.length > 0){
			CX = myCastles[0].getX();
			CY = myCastles[0].getY();
		}
		int awayFromCastle;
		
		int xdiff, ydiff;
		
		// Knights Movement( first 8) guide castle
		for ( int i = 0; i < myKnights.length; ++i){
			tempK = myKnights[i];
			currentX = tempK.getX();
			currentY = tempK.getY();
			xdiff = currentX - CX;
			ydiff = currentY - CY;	
			
			if ( xdiff > 0){
				if ( ydiff > 0){
					move(tempK, 8);
				}
				else if ( ydiff == 0){
					move(tempK, 7);
				
				}
				else{
					move(tempK, 6);
				}
			}
			else if ( xdiff == 0){
				if ( ydiff > 0){
					move(tempK, 1);
				}
				else if ( ydiff == 0){
					
				
				}
				else{
					move(tempK, 5);
				}	
				
			}
			else{
				if ( ydiff > 0){
					move(tempK, 2);
				}
				else if ( ydiff == 0){
					move(tempK, 3);
				
				}
				else{
					move(tempK, 4);
				}
			}
			
			for ( int j = 1; j < 10; ++j){
				np = World.getPositionAfterMove(currentX, currentY, j);
				
				
				if ( np != null && World.getObjectAt(np.x, np.y) != null &&
					 !World.getObjectAt(np.x, np.y).getRuler().getRulerName().equals("MR") ){
					this.capture(tempK, j);
					break;
				}
			
			}
		}
		
		// other Knight
		for ( int i = 100; i < myKnights.length; ++i){
			tempK = myKnights[i];
			initNextLoc = rand.nextInt(8) + 1;
			
			currentX = tempK.getX();
			currentY = tempK.getY();
			
			// check the next location if it is movable
			counter = 0;
			movable = false;
			kill = false;
			
			while (movable == false){
				initNextLoc = (initNextLoc % 8 ) + 1;
				counter ++;
				np = World.getPositionAfterMove( currentX, currentY, initNextLoc);
				if ( np == null || np.x > 72 || np.x < 0 || np.y > 64 || np.y < 0){

				}
				else {
					// the land is not mine

					if ( World.getObjectAt(np.x, np.y) != null&&
					!World.getObjectAt(np.x, np.y).getRuler().getRulerName().equals("MR") ){
							movable = true;		
							kill = true;	
					}
					if ( counter >= 8){

							movable = true;			
						if (currentX > 36 && currentY > 32){
							initNextLoc = 8;
						}
						else if ( currentX < 36 && currentY <32){
							initNextLoc = 4;
						}
						else if ( currentX > 36 && currentY < 32){
							initNextLoc = 6;
						}
						else {
							initNextLoc = 2;
						}

					}
					
				}

			
			}
			
			
			
			
			this.move(tempK, initNextLoc);
			if (kill == true){
				
				this.capture(tempK, initNextLoc);
			}
		}
		
		
		
		
		// Castles Actions
		for ( int i = 0; i < myCastles.length; ++i){
			tempC = myCastles[i];
			if ( World.getCurrentTurn() > 60 && myKnights.length >= myPeasants.length){
				this.createPeasants(tempC);
			}
			else {
				this.createKnights(tempC);
			}
		}
		
	}
	
}