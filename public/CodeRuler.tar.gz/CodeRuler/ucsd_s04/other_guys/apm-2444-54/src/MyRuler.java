import com.ibm.ruler.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	IPeasant[] edgePeasants;
	IPeasant[] allPeasants;
	boolean circ0, circ2, circ3, circ4, circ1;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "UCSDPC";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 54";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		IPeasant[] peas = getPeasants();
		edgePeasants = new IPeasant[5];
		for(int i = 0; i<5; i++) {
			edgePeasants[i] = peas[i];
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		allPeasants = getPeasants();
		for(int i = 0; i < 5 ; i++)
			move(edgePeasants[i], edgePeasants[i].getDirectionTo(i,i));
	}
	
	private boolean isPeasantEdge(IPeasant peasant) {
		for(int i = 0; i < allPeasants.length; i++) {
			
		}
		return true;
	}
}