import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;


/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	protected Random rand = new Random();
	private IRuler [] otherRulers  = null;
	private ICastle[] otherCastles = null;
	private IKnight[] otherKnights = null;
	private boolean random         = true;
	private boolean flag 		   = true;
	private boolean flag2 		   = true;
	private int counter            = 0;
	
	public String getRulerName() {
		return "Kit-Kat";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 63";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		otherCastles = World.getOtherCastles();	
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		
		ICastle nearestCastle = null;
		int counter   		  = 0;
		int X,Y               = 0;
		int direction         = 0;
		IKnight[] knights     = getKnights();
		IPeasant[] peasants   = getPeasants();
		int size = knights.length;
		int knightSent        = size/2;
		counter++;
		
		
		//get the nearest castle
		nearestCastle = findNearestCastle();
		X = nearestCastle.getX();
		Y = nearestCastle.getY();
		
		for (int i = 0; i < size  ; i++, counter++) {
			if(random)
				move(knights[i], rand.nextInt(8) + 1);
			else{
				if(i < knightSent){
					direction = knights[i].getDirectionTo(X,Y);	
					move(knights[i], direction);
				}		
			}
			knightCapture(knights[i]);		
			random = false;
		}
	
		size = peasants.length;
		for (int i = 0; i < size  ; i++, counter++) {
				move(peasants[i], rand.nextInt(8) + 1);
		}	
	
			
	}
	
	public boolean knightCapture(IKnight knight) {
		for (int i = 1; i < 9; i++) {
			// find the position
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);

			// make sure the position is a valid move
			if (np != null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if (object != null && !object.getRuler().equals(knight.getRuler())) {
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}
	
	
	public ICastle findNearestCastle(){
		
		int shortest = 0;
		int temp     = 0;
		int X,Y      = 0;
		 	
		otherCastles = World.getOtherCastles();
		otherKnights = World.getOtherKnights();
			
		if(otherCastles.length == 0){
			counter++;
			otherCastles = this.getCastles();
			if(counter == otherCastles.length -1)
				counter = 0;
			
			return otherCastles[counter];
		}	
		
		ICastle c = otherCastles [0];
		X = otherCastles[0].getX();
		Y = otherCastles[0].getY();
		
		ICastle mycastle[] = this.getCastles();	
		//System.out.println ("Size " + mycastle.length);
		if (mycastle.length == 0)
			shortest = 0;
		else
			shortest = (mycastle[0]).getDistanceTo(X,Y);
		
		if(flag && (mycastle.length > 0)) {
			createKnights(mycastle[0]);
			flag = false;
		}
		else if (!flag && (mycastle.length > 0)){
			createPeasants (mycastle [0]);
			flag = true;
		}
		else
		;
		
		for(int i = 1; i < otherCastles.length; i++){
			X = otherCastles[i].getX();
			Y = otherCastles[i].getY();
			
			if (mycastle.length == 0)
				temp = 0;
			else
				temp = (mycastle[0]).getDistanceTo(X,Y);
			if(shortest > temp){
				shortest = temp;
				c = otherCastles[i];
			}
		}
		
		return 	c;
	}
	
	public void moveAndCapture(IKnight knight, IPeasant peasant) {
		// return if the peasant is null or has already been captured
		if (peasant == null || !peasant.isAlive())
			return;
	
		// find the next position in the direction of the peasant
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			// if the peasant is in the adjacent square, capture it. Otherwise, try to keep moving
			if (peasant.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}	
}