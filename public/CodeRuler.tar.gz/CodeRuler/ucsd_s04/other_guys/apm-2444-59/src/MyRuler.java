import com.ibm.ruler.*;
import com.sun.rsasign.o;
import java.util.*;
import java.awt.Point;


/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	int xcastle, ycastle;
	int attackCount = 0;
	int timeCount = 0;
	
	public String getRulerName() {
		return "Kingdom";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team59";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		ICastle[] castles = this.getCastles();
		xcastle = castles[0].getX();
		ycastle = castles[0].getY();
		IKnight[] knights = getKnights();
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		for (int i = 0; i < getCastles().length; i++)
		{
			if (getKnights().length > getPeasants().length)
				createPeasants(getCastles()[i]);
			else
				createKnights(getCastles()[i]);
		}		
		
		movePeasant();
		attackCastle();
	}
	protected Random rand = new Random();
	
	public void movePeasant()
	{
		IPeasant[] p = getPeasants();
		int dir, x, y;
		int center;
		int counter = 0;
		ICastle[] c = World.getOtherCastles();
		for (int i = 0; i < p.length; i++)
		{
			x = p[i].getX();
			y = p[i].getY();
			dir = rand.nextInt(8) + 1;
			center = p[i].getDirectionTo(World.WIDTH/2, World.HEIGHT/2);
			switch (dir)
			{
				case 8:				
				if (i < getPeasants().length)
				if (!p[i].getRuler().equals(World.getLandOwner(x - 1 , y - 1))
					&& World.getObjectAt(x - 1, y - 1) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;
				case 1:				
				if (i < getPeasants().length)
				if (!p[i].getRuler().equals(World.getLandOwner(x , y - 1))
					&& World.getObjectAt(x, y - 1) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;
				case 2:		
				if (i < getPeasants().length)		
				if (!p[i].getRuler().equals(World.getLandOwner(x + 1 , y - 1))
					&& World.getObjectAt(x + 1, y - 1) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;
									
				case 7:			
				if (i < getPeasants().length)
					
					if (!p[i].getRuler().equals(World.getLandOwner(x - 1 , y))
					&& World.getObjectAt(x - 1, y) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;
									
				case 3:			
				if (i < getPeasants().length)	
				if (!p[i].getRuler().equals(World.getLandOwner(x + 1 , y))
										&& World.getObjectAt(x + 1, y) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;
									
									
				case 6:			
				if (i < getPeasants().length)	
				if (!p[i].getRuler().equals(World.getLandOwner(x - 1 , y + 1))
					&& World.getObjectAt(x - 1, y + 1) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;	
				case 5:			
				if (i < getPeasants().length)	
				if (!p[i].getRuler().equals(World.getLandOwner(x, y + 1))
					&& World.getObjectAt(x, y + 1) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;	
									
				case 4:			
				if (i < getPeasants().length)	
					if (!p[i].getRuler().equals(World.getLandOwner(x + 1 , y + 1))
						&& World.getObjectAt(x + 1, y + 1) == null)
					{
						move(p[i], dir);	  
					}
					else
					{
						if (counter > 3)
						{
							counter = 0;
							move(p[i], center); 
						} 
						else
							counter++;
					} 
					break;	
														
			}			 
		}
	}
	
	public void attackCastle(){
		boolean flag = false;
		IKnight[] k = getKnights();
		ICastle[] c = World.getOtherCastles();	
		if (attackCount >= c.length)
			attackCount = 0;
			
		timeCount++;
		boolean temp;
		
		int dir = rand.nextInt(8) + 1;
		
		for (int i = 0; i < Math.round(k.length*0.3); i++)
		{
			if (World.getObjectAt(xcastle, ycastle).getRuler().equals(this))
			{
				temp = attack(k[i]);
				if (!temp)
					move(k[i], dir);
			}
			else
			{
				temp = attack(k[i]);
				if (!temp)
					move(k[i], k[i].getDirectionTo(xcastle, ycastle));
			}
		}
		
		attackCount = getClosest(xcastle, ycastle);
		if (attackCount == -1)
		{
			flag = true;
		}
		for (int i = (int)Math.round(k.length*0.3); i < k.length; i++)
		{
			if (flag)
			{
				temp = attack(k[i]);
				if (!temp)
					move(k[i], dir);
			}
			else
			{	
				temp = attack(k[i]);
				if (!temp)
					move(k[i], k[i].getDirectionTo(c[attackCount].getX(), c[attackCount].getY()));
			}	
		}
	}
	
	public int getClosest(int x, int y)
	{
		ICastle[] c = World.getOtherCastles();
		if (c.length == 0)
			return -1;
			
		double distance;
		int retval = 0;
		double min = World.WIDTH*World.HEIGHT;
		
		for (int i = 0; i < c.length; i++)
		{
			distance = c[i].getDistanceTo(x, y);
			if (min > distance)
			{
			 	min = distance;
			 	retval = i;
			}
		}
		return retval;
	}
	
	public boolean attack(IKnight k)
	{
		int x = k.getX();
		int y = k.getY();
		
		IObject o1 = World.getObjectAt(x-1, y-1);
		if (o1 != null && !o1.getRuler().equals(k.getRuler()))
		{
			capture(k, 8);
			return true;
		}
		IObject o2 = World.getObjectAt(x, y-1);
		if (o2 != null && !o2.getRuler().equals(k.getRuler()))
		{
			capture(k, 1);
			return true;
		}
		IObject o3 = World.getObjectAt(x+1, y-1);
		if (o3 != null && !o3.getRuler().equals(k.getRuler()))
		{
			capture(k, 2);
			return true;
		}
		IObject o4 = World.getObjectAt(x-1, y);
		if (o4 != null && !o4.getRuler().equals(k.getRuler()))
		{
			capture(k, 7);
			return true;
		}
		IObject o5 = World.getObjectAt(x+1, y);
		if (o5 != null && !o5.getRuler().equals(k.getRuler()))
		{
			capture(k, 3);
			return true;
		}
		IObject o6 = World.getObjectAt(x-1, y+1);
		if (o6 != null && !o6.getRuler().equals(k.getRuler()))
		{
			capture(k, 6);
			return true;
		}
		IObject o7 = World.getObjectAt(x, y+1);
		if (o7 != null && !o7.getRuler().equals(k.getRuler()))
		{
			capture(k, 5);
			return true;
		}
		IObject o8 = World.getObjectAt(x+1, y+1);
		if (o8 != null && !o8.getRuler().equals(k.getRuler()))
		{
			capture(k, 4);
			return true;
		}
		
		return false;
	}
	public int getAttack(IObject o1, IObject o2)
	{
		int x1, x2, y1, y2;
		x1 = o1.getX();
		x2 = o2.getX();
		y1 = o1.getY();
		y2 = o2.getY();
		if (x2 == x1 -1 && y2 == y1 - 1)
			return 8;
		if (x2 == x1 && y2 == y1 - 1)
			return 1;
			
		if (x2 == x1 + 1 && y2 == y1 - 1)
			return 2;
		if (x2 == x1 - 1 && y2 == y1)
			return 7;
		if (x2 == x1 + 1  && y2 == y1)
			return 3;
		if (x2 == x1 -1 && y2 == y1 + 1)
			return 6;
		if (x2 == x1 && y2 == y1 + 1)
			return 5;
		if (x2 == x1 +1 && y2 == y1 + 1)
			return 4;	
		
		return 0;
	}

}
