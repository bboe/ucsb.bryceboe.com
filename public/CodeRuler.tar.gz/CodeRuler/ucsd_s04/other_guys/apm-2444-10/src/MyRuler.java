import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	private int dir = -1;
	private Random rand = new Random();
	private static final int knight_formation_turns = 10;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Prelude Power";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 10";
	}

	public void checkProduction(){
		ICastle[] castle = getCastles();
		int landCount = getOwnedLandCount();
		int numTurns = World.getCurrentTurn();
		boolean change = false;
		
		if(landCount > 4000 && (numTurns%4 == 0))
			change = true;
		
		else if(landCount > 2000 && (numTurns%6 == 0))
			change = true;	
		
		else if(landCount > 1000 && (numTurns%8 == 0))
			change = true;		
	
		else if(landCount > 500 && (numTurns%10 == 0))
			change = true;		
			
		else if(landCount > 250 && (numTurns%12 == 0))
			change = true;	
			
		else if(landCount > 250 && (numTurns%12 == 0))
			change = true;		
		
		else if(landCount > 125 && (numTurns%14 == 0))
			change = true;		
		
		else{
			change = false;
			return;
		}
		
		for(int i=0; i<castle.length; i++){
			int r = rand.nextInt(2);
			if(r == 1){
				createPeasants(castle[i]);
			}
			else
				createKnights(castle[i]);
		}

	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		ICastle[] castle = getCastles();
		for(int i=0; i<castle.length; i++)
			createKnights(castle[i]);
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		int index;
		int k_size;
		int p_size;
			
		IKnight[] knight = getKnights();
		IPeasant[] peasant = getPeasants();
		
		k_size = knight.length;
		p_size = peasant.length;
		
		orderKnights();
		orderPeasants();
		
		// check castle production after move
		checkProduction();
	}
	
	public IObject knightCapture(IKnight knight){
		for(int i = 1; i < 9; i++){
			// find position
			
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			if(np != null){
				IObject object = World.getObjectAt(np.x, np.y);
				if(object != null && 
					!object.getRuler().equals(knight.getRuler())){
					capture(knight, i);
					return object;
				}
			}
		}	
		return null;
	}
	
	private void orderKnights(){
		int index;
		int k_size;
		int c_size;
		int numToKeep;
		boolean randomize = false;
			
		IKnight[] knight = getKnights();
		
		IKnight[] otherKnight = World.getOtherKnights();
		IPeasant[] otherPeasant = World.getOtherPeasants();
		ICastle[] castle = getCastles();
		ICastle[] otherCastle = World.getOtherCastles();
		IObject targetObject = null;
		if(otherCastle.length>0 )
			targetObject = otherCastle[0];
		else if(otherKnight.length > 0)
			targetObject = otherKnight[0];
		else if(otherPeasant.length > 0)
			targetObject = otherPeasant[0];
		else
			randomize = true;
		
		k_size = knight.length;
		c_size = castle.length;
		numToKeep = 3*c_size;
		
		for ( index = 0; index < k_size; index++){
			IKnight thisKnight = knight[index];
	
			// keep the knight by the castle?		
			if(index < numToKeep){
				IObject toCapture = knightCapture(thisKnight);
				if(toCapture != null){
					moveAndCaptureObject(thisKnight, toCapture);
				}
				continue;
			}
			
			if(randomize = true){
				move(thisKnight, rand.nextInt(8)+1);
			}
			
			dir = thisKnight.getDirectionTo(targetObject.getX(), targetObject.getY() );	
			Point np = World.getPositionAfterMove(thisKnight.getX(), thisKnight.getY(), dir);
			IObject object = World.getObjectAt(np.x, np.y);
			if(object != null
				&& !object.getRuler().equals(thisKnight.getRuler()) )
					capture(thisKnight, dir);
			else
				move(thisKnight, dir);
		}
	}
	
	private void orderPeasants(){
		int index;
		int k_size;
		int p_size;
		int c_size;
		
		IKnight[] knight = getKnights();
		IPeasant[] peasant = getPeasants();
		ICastle[] castle = getCastles();
		
		k_size = knight.length;
		p_size = peasant.length;
		c_size = castle.length;
		
		int kept_knights = 3*c_size;
		
		for (index = 0; index < p_size; index++){
			IPeasant thisPeasant = peasant[index];
			int r = rand.nextInt(2);
			if(r == 0)
				move (thisPeasant, rand.nextInt(8)+1);
			else{
				int knight_index = (kept_knights + 1);
				if(k_size>0)
					knight_index = knight_index % k_size;
				int followDir = thisPeasant.getDirectionTo(knight[knight_index].getX(),
				knight[knight_index].getY());
				move(thisPeasant, followDir);
			}
		}
	}
	
	
	public void moveAndCaptureObject(IKnight knight, IObject object){
		if(object instanceof IPeasant){
			IPeasant peasant = (IPeasant)object;
			if(peasant == null || !peasant.isAlive())
				return;
		}
		
		int dir = knight.getDirectionTo(object.getX(), object.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if(np != null){
			if(object.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}

}