import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	private IPeasant []numPeasants;
	private IKnight  []numKnights;
	private ICastle  []otherCastles;
	private ICastle  []myCastles;
	
	private IRuler   []otherRulers;
	private ICastle   temp;
	private IKnight  []otherKnights;
	private IPeasant []otherPeasants;
	protected Random rand = new Random();
	int shortestCastle;
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "iGot0wned";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "TEAM 62";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		numPeasants = getPeasants();
				numKnights = getKnights();
				otherCastles = World.getOtherCastles();
				otherRulers = World.getOtherRulers();
		myCastles = getCastles();
		for(int i = 0; i < otherCastles.length-1; i++)
			for(int j=1; j < otherCastles.length; j++)		
					if(otherCastles[i].getDistanceTo(otherCastles[i].getX(),
					otherCastles[i].getY()) > 
					otherCastles[j].getDistanceTo(otherCastles[j].getX(),
				otherCastles[j].getY())){ 
		
						   temp = otherCastles[j];
						   otherCastles[j]=otherCastles[i];
						   otherCastles[i] = temp;
				}  
		
		
		
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		/*numPeasants = getPeasants();
						numKnights = getKnights();
						otherCastles = World.getOtherCastles();
						otherRulers = World.getOtherRulers();
				myCastles = getCastles();
				for(int i = 0; i < otherCastles.length-1; i++)
					for(int j=1; j < otherCastles.length; j++)		
							if(otherCastles[i].getDistanceTo(otherCastles[i].getX(),
							otherCastles[i].getY()) > 
							otherCastles[j].getDistanceTo(otherCastles[j].getX(),
						otherCastles[j].getY())){ 
		
								   temp = otherCastles[j];
								   otherCastles[j]=otherCastles[i];
								   otherCastles[i] = temp;
						}  */
		
		
		
		
		
		myCastles = getCastles();
		Point np;
		Point np1;
		Point np2;
		otherKnights = World.getOtherKnights();
		otherPeasants= World.getOtherPeasants();
		int shortestKnight;
		int shortestPeasant;
		numPeasants = getPeasants();
		numKnights = getKnights();
		for(int i = 0; i < myCastles.length; i++) {
			createPeasants(myCastles[i]);
			createKnights(myCastles[i]);
		}
 		for(int i= 0; i < numKnights.length; i++) {
 			if(numKnights[i].isAlive()){
				shortestCastle = numKnights[i].getDirectionTo(otherCastles[0].getX(),otherCastles[0].getY());
				shortestKnight = numKnights[i].getDirectionTo(otherKnights[i].getX(), otherKnights[i].getY());
				shortestPeasant = numKnights[i].getDirectionTo(otherPeasants[i].getX(), otherPeasants[i].getY());
				np = World.getPositionAfterMove(numKnights[i].getX(), numKnights[i].getY(), shortestCastle);
				
 				if(otherCastles[0].equals(World.getObjectAt(np.x, np.y))) {
 					System.out.println("comes here");	
 					
                	capture(numKnights[i], shortestCastle);
 				}
                if ( numNuts(otherKnights, shortestKnight)) { 	
                	System.out.println("now here" + numKnights[i]);
                   	capture(numKnights[i], shortestKnight);
                }     	
                if ( numNuts1(otherPeasants, shortestPeasant))
               		capture(numKnights[i], shortestPeasant);
            	else
            		move(numKnights[i], shortestCastle);
 			}    
 		}
 		
 		sendPeasants(numPeasants, 0, true);
		//sendKnights(numKnights, shortestCastle);  	  
	}
	
	public void sendPeasant(IPeasant peasant, int direction) {
		move(peasant, direction);
	}
	
	public void sendPeasants(IPeasant [] peasants, int direction, boolean flag) {
		if(!flag)
			for(int i =0 ; i < peasants.length; i++)
				move(peasants[i], direction);
		else
			for(int i = 0; i < peasants.length; i++)
				move(peasants[i], rand.nextInt(8) + 1);
	}
	
	public void sendKnights(IKnight [] knights, int direction) {
		for(int i =0 ; i < knights.length; i++)
			move(knights[i], direction);
	}
	
	public boolean numNuts(IKnight [] knights, int shortestCastle) {
		Point np;
		
		for(int i =0; i < knights.length; i++) {
			for(int j = 0; j < numKnights.length; j++) {
			
				
			shortestCastle = numKnights[j].getDirectionTo(knights[i].getX(),knights[i].getY());
			np = World.getPositionAfterMove(numKnights[j].getX(), numKnights[j].getY(), shortestCastle);
			if(knights[i].equals(World.getObjectAt(np.x, np.y)))
				return true;
			}
		}
		return false;
	}
	
	public boolean numNuts1(IPeasant [] peasants, int shortestCastle) {
			Point np;
			for(int i =0; i < peasants.length; i++) {
				for(int j = 0; j < numKnights.length; j++) {
				
				shortestCastle = numKnights[j].getDirectionTo(peasants[i].getX(),peasants[i].getY());
				np = World.getPositionAfterMove(numKnights[j].getX(), numKnights[j].getY(), shortestCastle);
				if(peasants[i].equals(World.getObjectAt(np.x, np.y)))
					return true;
				}
			}
			return false;
		}
	//public void knightCapture(IKnight [] knights, int x, int y) {
		//for(int i = 0; i
	
}