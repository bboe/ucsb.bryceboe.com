import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "G1S_b";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 15";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		//knights = this.getKnights();
		mine = this.getCastles();
		my_castle = mine[0];
		my_x = my_castle.getX();
		my_y = my_castle.getY();
		init();
		rand = new Random();
	}

	public void init() {
		castles = World.getOtherCastles();
		size = castles.length;
		castle_dist = new int[size];
		int MIN = 10000;
		//my_x = knights[0].getX();
		//my_y = knights[0].getY();
		for( int i = 0; i < size; i++ ) {
			c_dist = my_castle.getDistanceTo(castles[i].getX(), castles[i].getY());
			if( c_dist <= MIN ) {
				MIN = c_dist;	
				next = i;
			}
		}
	}

	public void captureRange(IKnight k, ICastle c) {
		int x = k.getX();
		int y = k.getY();
		if( k.getDistanceTo(c.getX(), c.getY()) < 2 && !CC) {
			CC = true;
			return;	
		}
		IObject o;
		for( int i = -1; i < 2; i++ ) {
			for( int j = -1; j < 2; j++ ) {
				o = World.getObjectAt(x+i, y+j);
				if( o != null && !o.getRuler().equals(k.getRuler())) {
					capture(k, k.getDirectionTo(x+i, y+j));
				}
					
			}
		}
	}

	public void knightMove(IKnight k, IObject o) {
		int dir = k.getDirectionTo(o.getX(), o.getY());
		Point np = World.getPositionAfterMove(k.getX(), k.getY(), dir);
		
		
		if( np != null ) {
			if( o.equals(World.getObjectAt(np.x, np.y)) ) {
				capture(k, dir);
			}
			else
				move(k, dir);
		}
	}

	public void growStuff() {
		mine = this.getCastles();
		size = mine.length;
		for( int i = 0; i < size; i++ ) {
			if( rand.nextInt(5) < 2 )
				createPeasants(mine[i]);
			else
				createKnights(mine[i]);
		}
			
	}

	public void peasantMove(IPeasant p) {
		int x = p.getX();
		int y = p.getY();
				
		Point np = World.getPositionAfterMove(x, y, dir);
		if( np != null ) {
			if( World.getLandOwner( np.x, np.y ).equals(p.getRuler()) )
				dir = rand.nextInt(8);
		

		}
		else {
			dir = rand.nextInt(8);

		}

		move(p, dir);
 	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		CC = false;
		growStuff();
		knights = this.getKnights();
		size = knights.length;
		ICastle next_castle = castles[next];
		int toCastle;
		for( int i = 0; i < size; i++ ) {
			knightMove(knights[i], next_castle);
			captureRange(knights[i], next_castle);
		}
		peasants = this.getPeasants();
		size = peasants.length;
		//olds_pos = new Point[size];
		for( int i = 0; i < size; i++ ) {
//			dir = (dir % 8) + 1;
			peasantMove(peasants[i]);
		}
	}
	
	//Point[] olds_pos;
	boolean CC = false;
	IKnight[] knights;
	IPeasant[] peasants;
	ICastle[] castles, mine;
	ICastle my_castle;
	int my_x, my_y, size, my_id, next, c_count, c_dist;
	int[] castle_dist;
	Random rand;
	int dir;
}