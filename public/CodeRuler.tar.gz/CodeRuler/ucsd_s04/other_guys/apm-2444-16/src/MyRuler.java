import com.ibm.ruler.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
import java.util.*;
import java.awt.Point;

public class MyRuler extends Ruler {
	protected Random rand = new Random();
	protected WeakHashMap knight_tasks = new WeakHashMap(),
		peasant_tasks = new WeakHashMap();
	protected Point castles[];
	protected IKnight k[];
	protected IPeasant p[];
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Royal Rib";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 16";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		rand = new Random();
		ICastle c[] = World.getOtherCastles();
		castles = new Point[c.length + 1];
		for (int i = c.length - 1; i >= 0; i--){
			castles[i]=new Point(c[i].getX(),c[i].getY());
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		doCastles();
		doKnights();
		doPeasants();	
	}
	protected void doKnights() {
		IKnight curk;
		knight_task kt;
		int size = k.length;
		for (int i = 0; i < size; i++) {
			curk = k[i];
			kt = (knight_task)knight_tasks.get(curk);
			if (kt == null){
				kt = new knight_task();
				knight_tasks.put(curk, kt);
			}
			kt.move(curk);
		}		
	}
	protected void doCastles() {
		k = getKnights();
		p = getPeasants();
		int knights = k.length;
		ICastle[] c = getCastles();
		if (castles[castles.length - 1] == null) {
			castles[castles.length - 1]=new Point(c[0].getX(),c[0].getY());
		}
		if (castles == null)
			return;
		if (knights < 10 || (knights <= 25 && 4*knights < p.length)) {
			for (int i = c.length - 1; i >= 0; i--){
				createKnights(c[i]);				
			}
		} else {
			for (int i = c.length - 1; i >= 0; i--){
				createPeasants(c[i]);				
			}			
		}
	}
	protected void doPeasants() {
		IPeasant cur;
		peasant_task pt;
		if (p.length < 50) {
			for (int i = p.length - 1; i >= 0; i--){
				cur = p[i];
				pt = (peasant_task)peasant_tasks.get(cur);
				if (pt == null) {
					pt = new peasant_task();
					pt.chooseDest();
					peasant_tasks.put(cur, pt);
				}
				pt.move(cur);
			}
		} else {
			for (int i = p.length - 1; i >= 0; i--){
				move(p[i],(rand.nextInt(8)+1));							
			}
		}
	}
	protected class knight_task {
		boolean guarding = false;
		int target = rand.nextInt(castles.length);
		int lastx = -1, lasty = -1;
		int stuck_count = -1;
		public void move (IKnight k){
			if (knightCapture(k))
				return;
			int x = k.getX(), y = k.getY();
			if (lastx == x && lasty == y)
				stuck_count++;
			else
				stuck_count = -1;
			if (stuck_count > 5){
				if (!guarding)
					target = rand.nextInt(castles.length);
				else {
					MyRuler.this.move(k, rand.nextInt(8)+1);
					return;
				}
					
			}
				
			Point dest = castles[target];
/*			if (dest == null) {
				System.err.println("no castle " + target);
				return;
			}
			if (x == dest.x && y == dest.y) {
				target++;
				if (target >= castles.length)
					target -= castles.length;
				dest = castles[target];
			}*/
			int dir;
			if (x == dest.x)
				dir = y < dest.y ? 4 : 8;
			else if (x < dest.x)
				dir = y < dest.y ? 3 : y == dest.y ? 2: 1;
			else
				dir = y < dest.y ? 5 : y == dest.y ? 6 : 7;
			MyRuler.this.move(k, dir + rand.nextInt(3));
			return;
		}
		public boolean knightCapture(IKnight knight) {
			boolean start_guarding = false;
			for (int i = 1; i < 9; i++) {
				Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
				if (np != null) {
					IObject object = World.getObjectAt(np.x, np.y);
					if (object == null)
						continue;
					boolean mine = object.getRuler().equals(knight.getRuler());
					if (!guarding && mine && object instanceof ICastle) {
						if (rand.nextBoolean())
							start_guarding = true;
						else
							target = rand.nextInt(castles.length);
					} else if (object != null && !object.getRuler().equals(knight.getRuler())){
						capture(knight, i);
						return true;
					}
				}
			}
			if (start_guarding)
				guarding = true;
			return false;
		}
	}
	protected class peasant_task {
		Point dest = new Point();
		boolean wandering;
		int direction = 1, minx, miny,
			 maxx, maxy;
		int lastx =-1, lasty=-1;
		public void move(IPeasant p){
			int x = p.getX(), y = p.getY();
			int dir;
			if (!wandering) {
				if (x == dest.x && y == dest.y) {
					wandering = true;
					//System.err.println("pawn at " +x+","+y+" finished traveling, now wandering");
				} else {
					if (lastx == x && lasty == y)
						chooseDest();
					lastx = x;
					lasty = y;
					if (x == dest.x)
						dir = y < dest.y ? 5 :  1;
					else if (x < dest.x)
						dir = y < dest.y ? 4 : y == dest.y ? 3 : 2;
					else
						dir = y < dest.y ? 6 : y == dest.y ? 7 : 8;
					MyRuler.this.move(p, dir);
					return;
				}
			}
			//System.err.println("pawn at " +x+","+y+" wandering");			

			if (x == lastx && y == lasty) {
				MyRuler.this.move(p,(rand.nextInt(8)+1));
				chooseDest();
				return;
			}
			lastx = x;
			lasty = y;
			boolean turn = false;
			if (x < minx) {
				minx = x;
				turn = true;
			}
			if (y < miny) {
				miny = y;
				turn = true;
			}
			if (x > maxx) {
				maxx = x;
				turn = true;
			}
			if (y > maxy) {
				maxy = y;
				turn = true;
			}
			if (turn) {
//				System.err.print("pawn at " +x+","+y+" turning from "+direction);
				direction = (direction + 2) & 7;
//				System.err.println(" to "+direction);
			}
			MyRuler.this.move(p, direction);
		}

		public void chooseDest() {
			wandering = false;
			dest.x = rand.nextInt(World.WIDTH);
			dest.y = rand.nextInt(World.HEIGHT);
			minx = Integer.MAX_VALUE;
			miny = minx;
			maxx = Integer.MIN_VALUE;
			maxy = maxx;			
		}
	}
}