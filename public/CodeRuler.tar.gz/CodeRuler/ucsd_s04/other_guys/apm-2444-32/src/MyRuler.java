import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	protected IObject prey;
	protected Random rand = new Random();
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "     huh?";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 32";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 * 
	 * Called to give you a chance to do initialization. This method
	 * will be called at the beginning of each match, and you will
	 * have a limited amount of time to do initialization. All of your
	 * objects and your opponents' objects will already exist.
	 */
	public void initialize() {
		// put implementation here
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		IKnight sirs[] = getKnights();
		IPeasant peons[] = getPeasants();
		ICastle hives[] = getCastles();
		ICastle seigeTargets[] = World.getOtherCastles();
		int nextmov=0, prevmov=0;
		for( int i = 0; i < hives.length; i++){
			createKnights(hives[i]);
			createPeasants(hives[i]);
		}
		for( int i = 0; i < sirs.length; i++){
//			if( seigeTargets.length != 0){
//				for( int j = 0; j<seigeTargets.length; j++)
//					seigeCastle(sirs[i], seigeTargets[j]);
//			}
			if(knightCapture( sirs[i] )){
				huntDown(sirs[i],prey);
			}
			else{
				if( sirs[i].getX() > World.WIDTH-1){
					nextmov = rand.nextInt(6)+4;
					if( nextmov > 8 )
						nextmov = 1;
				}
				else if( sirs[i].getX() < 1){
					nextmov = rand.nextInt(6)+1;
				}
				if( sirs[i].getY() > World.HEIGHT-1){
					nextmov = rand.nextInt(8)+1;
					if( nextmov < 7 || nextmov > 3)
						nextmov -= 3;
				}
				else if( sirs[i].getY() < 1){
					nextmov = rand.nextInt(7)+1;
					if( nextmov < 3)
						nextmov += 2;
				}
				else{
					nextmov = rand.nextInt(8)+1;
				}
				move(sirs[i], nextmov);
			}
			
		}
		for( int i = 0; i < peons.length; i++){
			if( peons[i].getX() > World.WIDTH-1){
				nextmov = rand.nextInt(6)+4;
				if( nextmov > 8 )
					nextmov = 1;
			}
			else if( peons[i].getX() < 1){
				nextmov = rand.nextInt(6)+1;
			}
			if( peons[i].getY() > World.HEIGHT-1){
				nextmov = rand.nextInt(8)+1;
				if( nextmov < 7 || nextmov > 3)
					nextmov -= 3;	
			}
			else if( peons[i].getY() < 1){
				nextmov = rand.nextInt(7)+1;
				if( nextmov < 3)
					nextmov += 2;
			}
			else
				nextmov = rand.nextInt(8)+1;
			move(peons[i], nextmov);
		}
	}
	public boolean knightCapture(IKnight sir){
		for( int i = 1; i < 9; i++){
			//find position
			Point np = World.getPositionAfterMove(sir.getX(), sir.getY(), i);
			
			//make sure position is a valid move
			if( np != null){
				IObject obj = World.getObjectAt(np.x, np.y);
				if( obj != null && !obj.getRuler().equals(sir.getRuler())){
					prey = obj;
					capture(sir, i);
					return true;
				}
			}
		}
		return false;
	}
	public void huntDown(IKnight sir, IObject prey){
		if( prey == null || !prey.isAlive())
			return;
		int dir = sir.getDirectionTo(prey.getX(), prey.getY());
		Point np = World.getPositionAfterMove(sir.getX(), sir.getY(), dir);
		if(np!=null){
			if(prey.equals(World.getObjectAt(np.x, np.y)))
				capture(sir, dir);
			else
				move(sir, dir);
		}
	}
	public void seigeCastle(IKnight sir, ICastle mine){
		int nextmov;
		if( !mine.getRuler().equals(sir.getRuler()))
			nextmov = mine.getDirectionTo(mine.getX(), mine.getY());
		
			
	}
}