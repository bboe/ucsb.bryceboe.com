import com.ibm.ruler.*;
import java.io.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "HashTaybo�";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 44";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		
	}
	
	
	protected Random rand = new Random();
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		int curx, cury;
		int min = 99999;
		int currentmin, mincastle, pdir;
		mincastle = 0;
		IPeasant[] peasants = getPeasants();
		IKnight[] knights = getKnights();
		ICastle[] castles = getCastles();
		IKnight[] otherKnights = World.getOtherKnights();
		int curdist;
		int min1 = 10000;
		int closestknight = 0;
		
		for(int h=0; h < otherKnights.length; h++ )
				{
					curdist = knights[0].getDistanceTo(otherKnights[h].getX(), 
					otherKnights[h].getY());
					if(curdist < min1) 
					{
						min1 = curdist;
						closestknight = h;
					} 
				}
		
		
		//****PEASANTS IDE		
		int size = peasants.length;
		for (int i = 0; i < size; i++) {
			min = 99999;
			curx = peasants[i].getX();
			cury = peasants[i].getY();
			int ash1 = rand.nextInt(10);
			
			if(ash1 < 5)
				{
					int ran = rand.nextInt(8) + 1;
					Point np1 = World.getPositionAfterMove(curx,cury, ran);
					if(np1 != null)
						{
							if(checkforknight(peasants[i]) == -1)
								move(peasants[i], rand.nextInt(8) + 1 ); 
							else 
								move(peasants[i], checkforknight(peasants[i]));
						}				
							 
					}
				
			else
			{
			for(int j=0;j<8; j++)
			{
				Point np = World.getPositionAfterMove(curx,cury, j);
				if(np != null)
				{
				
					IRuler ash = World.getLandOwner(np.x,np.y);
					if(ash == null) {
						if(checkforknight(peasants[i]) == -1)
							move(peasants[i], j); 
						else 
							move(peasants[i], checkforknight(peasants[i]));
						break;
						}
					
					else if( !ash.getRulerName().equals(getRulerName()) )
					{
						if(checkforknight(peasants[i]) == -1)
							move(peasants[i], j); 
						else 
							move(peasants[i], checkforknight(peasants[i]));
						break;
					}
				}
				
			}
		}
			
		}
		
	//KNIGHTS****************************************	
		int sizek = knights.length;
		int sizeathome = sizek/3;
		
		int ourcastle = 0;;
		int mindist= 1000;
		int currdist =0 ;
		int closestcastle =0;
		int closestpeasant = 0;
		ICastle[] otherCastles = World.getOtherCastles();
		IPeasant[] otherPeasants = World.getOtherPeasants();

		for(int h=0; h < otherCastles.length; h++ )
		{
			currdist = knights[0].getDistanceTo(otherCastles[h].getX(), 
			otherCastles[h].getY());
			if(currdist < mindist) 
			{
				mindist = currdist;
				closestcastle = h;
			} 
		}
		
		for(int h=0; h < otherPeasants.length; h++ )
				{
					currdist = knights[0].getDistanceTo(otherPeasants[h].getX(), 
					otherPeasants[h].getY());
					if(currdist < mindist) 
					{
						mindist = currdist;
						closestpeasant = h;
					} 
				}
				
		
		for(int j=0; j<knights.length; j++)
		{
			//if(j==10) break;
			int dir;
			if(otherCastles.length == 0)
			{
				if(otherPeasants.length == 0)
				dir = knights[j].getDirectionTo(otherKnights[closestknight].getX(),otherKnights[closestknight].getY());
				else
				dir = knights[j].getDirectionTo(otherPeasants[closestpeasant].getX(),otherPeasants[closestpeasant].getY());
				
				
			}
			
			else
				dir = knights[j].getDirectionTo(otherCastles[closestcastle].getX(),otherCastles[closestcastle].getY());
			
			
			if(knightCapture(knights[j]));
			else
				move(knights[j], dir);
			
			
			
		}
		
		
		System.out.println(ourcastle);
		for(int i=0; i<castles.length;i++)
		{
			int die = rand.nextInt(10)+1;
			
			if(otherKnights.length==0 && otherCastles.length == 0)
				createPeasants(castles[i]);
			else
			{
				
					
				if( knights.length < 20 )
					createKnights(castles[i]);
			
				else if(die < 6) createKnights(castles[i]);
				else createPeasants(castles[i]);
		//if(peasants.length < 45 && knights.length > 20 && 
		//	peasants.length 
		//	createPeasants(castles[i]);
		
		}
		}	
		/*for(int i=0; i<sizeathome; i++)
		{
			int rank;		
			curx = knights[i].getX();
			cury = knights[i].getY();
			while(true)
			{	
				rank = rand.nextInt(8)+1;	
				Point np = World.getPositionAfterMove(curx,cury, rank);
				if(np == null) continue;
				//System.out.println(castles[ourcastle].getDistanceTo(np.x, np.y));
				if( castles[0].getDistanceTo(np.x, np.y) < 11)
				{
					if(np != null)
					{
						if(knightCapture(knights[i]));
						else
							move(knights[i], rank);
						break;
					}
				}
				//System.out.println("DIE");
			}
			
		}
		
		for( int i =sizeathome ; i < sizek; i ++)
		{
			curx = knights[i].getX();
			cury = knights[i].getY();
			
			
		}*/
	}	

	



//	   for a particular knight, attempt to capture the first opposing peasant or knight
//	   that is in an adjacent square. Returns true if it was able to find something to
//	   capture, and false if there were no opponents surrounding it.

	public boolean knightCapture(IKnight knight) {
		for (int i = 1; i < 9; i++) {
			// find the position
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);

			// make sure the position is a valid move
			if (np != null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if (object != null && !object.getRuler().equals(knight.getRuler())) {
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}


//	   for a particular knight, move toward and then capture the given opposing peasant. This
//	   method will not attempt to capture any other peasants or knights and will keep trying
//	   to move toward the peasant even if there is another peasant or knight in the way


	public void moveAndCapture(IKnight knight, IPeasant peasant) {
		// return if the peasant is null or has already been captured
		if (peasant == null || !peasant.isAlive())
			return;
	
		// find the next position in the direction of the peasant
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			// if the peasant is in the adjacent square, capture it. Otherwise, try to keep moving
			if (peasant.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}

public int checkforknight(IPeasant peas)
{
	int dist = -1;
	int curx = peas.getX();
	int cury = peas.getY();
	for(int i=1; i< 9; i++)
	{
	
	Point np = World.getPositionAfterMove(curx, cury, i);

				// make sure the position is a valid move
				if (np != null) 
				{
					IObject object = World.getObjectAt(np.x, np.y);
					if (object != null && object instanceof IKnight) 
					{
						dist = i;
						break;
					}
				}
	}
	
	if(dist == 1) return 5;
	if(dist == 2) return 6;
	if(dist == 3) return 7;
	if(dist == 4) return 8;
	if(dist == 5) return 1;
	if(dist == 6) return 2;
	if(dist == 7) return 3;
	if(dist == 8) return 4;
				
	
	return	dist;
	
	
	}


	
	
}