import com.ibm.ruler.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "No pixels for oil";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 66";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		
		defknights = new IKnight [DK];
	
		for (int i = 0; i < DK; i++)
			defknights[i] = (getKnights())[i];
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here

		float dir [] = new float[9];
		IPeasant [] peasants = this.getPeasants();
		
		boolean panicmode = false;
		ICastle [] castles = getCastles();
		if (castles.length == 0)
			panicmode = true;
		else if (castles.length == 1) {
			if (peasants.length < Pthreshold1)
				createPeasants(castles[0]); 
			else
				createKnights(castles[0]);
		}
		
		else if (castles.length == 2) {
			if (peasants.length < Pthreshold2) {
				createPeasants(castles[0]); 
				createPeasants(castles[1]);
			}
			else {
				createKnights(castles[0]);
				createKnights(castles[1]);
			}
		}
		
		else {
			if (peasants.length < Pthreshold3) {
				for (int i = 0; i < castles.length; i++) {
					createPeasants(castles[i]);
				}
			}
			else {
				createPeasants (castles[0]);
				for (int i = 1; i < castles.length; i++) {
					createPeasants(castles[i]);
				}
			}
		}
		
	
		
		
		for (int k = 0; k < peasants.length; k++) {
			IPeasant p = peasants[k];
			dir = new float[9];
			for (int i=-1*Pradius1; i <= Pradius1; i++) {
				for (int j = -1*Pradius1; j <= Pradius1; j++) {
					int x = i + p.getX();
					int y = j + p.getY();
					//System.err.println ("x: " + x + ", y: " + y);
					if ((!((i == 0) && (j ==0))) &&
						(x >= 0) && (x <= 71) &&
						(y >= 0) && (y <= 63)) {
							//System.err.println ("Peasant # " + k + "is considering options");
							if (isLandNotOurs(x,y)) {
								//System.err.println ("Peasant # " + k + " sees green pastures");
								IRuler r = World.getLandOwner(x, y);
								if (r == null)
									dir[p.getDirectionTo (x,y)] += P2NL/
									Math.pow(p.getDistanceTo(x,y), P2Lpower);
								else
									dir[p.getDirectionTo (x,y)] += P2OL/
									Math.pow(p.getDistanceTo(x,y), P2Lpower);
							}
							else
								dir[p.getDirectionTo (x,y)] += P2FL/
								Math.pow(p.getDistanceTo(x,y), P2Lpower);
															
							//interact w/other objects	
							IObject o = World.getObjectAt(x,y);
							if ((o!=null) && isK(o) && !isOurs(o))
								dir[p.getDirectionTo (x,y)] += P2OK/p.getDistanceTo(x,y);
							
							//if anything adjoining, make very undesirable
							if ((Math.abs(i) == 1) || (Math.abs(j) == 1)) {
								if (o != null) {
									dir[p.getDirectionTo (x,y)] += -10000;
								}
							}
						}
						else {
							if (!((i==0) && (j==0)))
								dir[p.getDirectionTo(x,y)] += P2wall/p.getDistanceTo(x,y);
						}
				}
			}
			
			for (int i = 0; i < peasants.length; i++) {
				IPeasant op = peasants[i];
				int x = op.getX();
				int y = op.getY();
				
				if (op != p)
				dir[p.getDirectionTo (x,y)] += 
								P2FP/p.getDistanceTo(x,y);
			}
			
			//int dirchoose = (int)Math.round(Math.floor(Math.random()*8) + 1);
			//dirchoose = dirchoose %8;
			
			double x = dir[MOVE_E] - dir[MOVE_W] + .707*dir[MOVE_NE] +
			.707*dir[MOVE_SE] - .707*dir[MOVE_NW] - .707*dir[MOVE_SW];
			
			double y = dir[MOVE_S] - dir[MOVE_N] + .707*dir[MOVE_SE] +
			.707*dir[MOVE_SW] - .707*dir[MOVE_NE] - .707*dir[MOVE_NW];
			
			double theta = Math.atan(Math.abs(y)/Math.abs(x))*180/Math.PI;
	
			int dirchoose = MOVE_N;
					
			if (x >= 0) {
				if (y >= 0) {
					//1st quadrant
					if (theta < 22.5)
						dirchoose = MOVE_E;
					else if (theta < 45+22.5)
						dirchoose = MOVE_SE;
					else
						dirchoose = MOVE_S;
				}
				else {
					//4th quadrant
					if (theta < 22.5)
						dirchoose = MOVE_E;
					else if (theta < 45+22.5)
						dirchoose = MOVE_NE;
					else
						dirchoose = MOVE_N;
				}
			}
			else
			if (y >= 0) {
				//2nd quadrant
				if (theta < 22.5)
					dirchoose = MOVE_W;
				else if (theta < 45+22.5)
					dirchoose = MOVE_SW;
				else
					dirchoose = MOVE_S;
			}
			else {
				//3rd quadrant
				if (theta < 22.5)
					dirchoose = MOVE_W;
				else if (theta < 45+22.5)
					dirchoose = MOVE_NW;
				else
					dirchoose = MOVE_N;
			}
				
			

			/*
			for (int i = 1; i <= 8; i++) {
				System.err.println (k + ": direction " + i + ", rating: " + dir[i]);
				if (dir[i] > dir[dirchoose])
					dirchoose = i;
			}*/
			
			move (p, dirchoose);
		}
		
		IKnight [] knights = this.getKnights();
		IKnight [] ofknights = new IKnight[knights.length - DK];
		
		for (int i = 0; i < DK; i++) {
			if (!defknights[i].isAlive())
				defknights[i] = knights[knights.length -1]; 
		}
		
		int i1 = 0;
		for (int i =0; i < knights.length; i++) {
			boolean dup = false;
			for (int j = 0; j < DK; j++) {
				if (defknights[j] == knights[i]) {
					dup = true;
				}
			}
			if (!dup) {
				ofknights[i1] = knights[i];
				i1++;
			}
		}
		
		for (int l = 0; l < ofknights.length; l++) {
			IKnight k = ofknights[l];
			dir = new float[9];
			
			IKnight [] oknights = World.getOtherKnights();
			

			
			for (int i = 0; i < oknights.length; i++) {
				
				//TODO: take into account 2nd-order defense w/opp. knights
				IKnight ok = oknights[i];
				int x = ok.getX();
				int y = ok.getY();
				dir[k.getDirectionTo (x,y)] += 
					K2OK/k.getDistanceTo(x,y);
				
				float so = 0;
				for (int j = 0; j < castles.length; j++) {
					x = (castles[j]).getX();
					y = (castles[j]).getY();
					//so += K2OK2FC/ok.getDistanceTo(x,y);
				}
				
				x = ok.getX();
				y = ok.getY();
				dir[k.getDirectionTo(x,y)] += so;

			}
			
			ICastle [] ocastles = World.getOtherCastles();
			for (int i = 0; i < ocastles.length; i++) {
				ICastle oc = ocastles[i];
				int x = oc.getX();
				int y = oc.getY();
				dir[k.getDirectionTo (x,y)] += 
					K2OC/k.getDistanceTo(x,y);
			}
			
			IPeasant [] opeasants = World.getOtherPeasants();
			for (int i = 0; i < opeasants.length; i++) {
				IPeasant op = opeasants[i];
				int x = op.getX();
				int y = op.getY();
				dir[k.getDirectionTo (x,y)] += 
					K2OP/k.getDistanceTo(x,y);
			}		
			
		
			//int dirchoose = (int)Math.round(Math.floor(Math.random()*8) + 1);
			//dirchoose = dirchoose %8;
			/*
			for (int i = 1; i <= 8; i++) {
				if (dir[i] > dir[dirchoose])
					dirchoose = i;
			}*/
			
			//start knight choose quadrants
			double xd = dir[MOVE_E] - dir[MOVE_W] + .707*dir[MOVE_NE] +
			.707*dir[MOVE_SE] - .707*dir[MOVE_NW] - .707*dir[MOVE_SW];
			
			double yd = dir[MOVE_S] - dir[MOVE_N] + .707*dir[MOVE_SE] +
			.707*dir[MOVE_SW] - .707*dir[MOVE_NE] - .707*dir[MOVE_NW];
			
			double theta = Math.toDegrees(Math.atan(Math.abs(yd)/Math.abs(xd)));
	
			
			int dirchoose = MOVE_N;
					
			if (xd >= 0) {
				if (yd >= 0) {
					//1st quadrant
					if (theta < 22.5)
						dirchoose = MOVE_E;
					else if (theta < 45+22.5)
						dirchoose = MOVE_SE;
					else
						dirchoose = MOVE_S;
				}
				else {
					//4th quadrant
					if (theta < 22.5)
						dirchoose = MOVE_E;
					else if (theta < 45+22.5)
						dirchoose = MOVE_NE;
					else
						dirchoose = MOVE_N;
				}
			}
			else
			if (yd >= 0) {
				//2nd quadrant
				if (theta < 22.5)
					dirchoose = MOVE_W;
				else if (theta < 45+22.5)
					dirchoose = MOVE_SW;
				else
					dirchoose = MOVE_S;
			}
			else {
				//3rd quadrant
				if (theta < 22.5)
					dirchoose = MOVE_W;
				else if (theta < 45+22.5)
					dirchoose = MOVE_NW;
				else
					dirchoose = MOVE_N;
			}			
			
			
			//end knight choose quadrants
			
			int x = k.getX();
			int y = k.getY();
			if (dirchoose == MOVE_N) {
				y--;
			}
			if (dirchoose == MOVE_NW) {
				y--;
				x--;
			}
			if (dirchoose == MOVE_W) {
				x--;
			}
			if (dirchoose == MOVE_SW) {
				x--;
				y++;
			}
			if (dirchoose == MOVE_S) {
				y++;
			}
			if (dirchoose == MOVE_SE) {
				y++;
				x++;
			}
			if (dirchoose == MOVE_E) {
				x++;
			}
			if (dirchoose == MOVE_NE) {
				x++;
				y--;
			}
			
			IObject o = World.getObjectAt (x, y);
			
			if ((o != null) && !isOurs(o))
				capture (k, dirchoose);
			else				
				move (k, dirchoose);
		}
		
		for (int l = 0; l < defknights.length; l++) {
					IKnight k = defknights[l];
					dir = new float[9];
			
					IKnight [] oknights = World.getOtherKnights();
			
					for (int i = 0; i < oknights.length; i++) {
				
						//TODO: take into account 2nd-order defense w/opp. knights
						IKnight ok = oknights[i];
						int x = ok.getX();
						int y = ok.getY();
						dir[k.getDirectionTo (x,y)] += 
							K2OK/k.getDistanceTo(x,y);
				
						float so = 0;
						for (int j = 0; j < castles.length; j++) {
							x = (castles[j]).getX();
							y = (castles[j]).getY();
							so += K2OK2FC/ok.getDistanceTo(x,y);
						}
				
						x = ok.getX();
						y = ok.getY();
						dir[k.getDirectionTo(x,y)] += so;

					}
					
	
					
					/*
					ICastle [] ocastles = World.getOtherCastles();
					for (int i = 0; i < ocastles.length; i++) {
						ICastle oc = ocastles[i];
						int x = oc.getX();
						int y = oc.getY();
						dir[k.getDirectionTo (x,y)] += 
							K2OC/k.getDistanceTo(x,y);
					}
			
					IPeasant [] opeasants = World.getOtherPeasants();
					for (int i = 0; i < opeasants.length; i++) {
						IPeasant op = opeasants[i];
						int x = op.getX();
						int y = op.getY();
						dir[k.getDirectionTo (x,y)] += 
							K2OP/k.getDistanceTo(x,y);
					}*/		
			
		
					//int dirchoose = (int)Math.round(Math.floor(Math.random()*8) + 1);
					//dirchoose = dirchoose %8;
					/*
					for (int i = 1; i <= 8; i++) {
						if (dir[i] > dir[dirchoose])
							dirchoose = i;
					}*/
			
					//start knight choose quadrants
					double xd = dir[MOVE_E] - dir[MOVE_W] + .707*dir[MOVE_NE] +
					.707*dir[MOVE_SE] - .707*dir[MOVE_NW] - .707*dir[MOVE_SW];
			
					double yd = dir[MOVE_S] - dir[MOVE_N] + .707*dir[MOVE_SE] +
					.707*dir[MOVE_SW] - .707*dir[MOVE_NE] - .707*dir[MOVE_NW];
			
					double theta = Math.toDegrees(Math.atan(Math.abs(yd)/Math.abs(xd)));
	
			
					int dirchoose = MOVE_N;
					
					if (xd >= 0) {
						if (yd >= 0) {
							//1st quadrant
							if (theta < 22.5)
								dirchoose = MOVE_E;
							else if (theta < 45+22.5)
								dirchoose = MOVE_SE;
							else
								dirchoose = MOVE_S;
						}
						else {
							//4th quadrant
							if (theta < 22.5)
								dirchoose = MOVE_E;
							else if (theta < 45+22.5)
								dirchoose = MOVE_NE;
							else
								dirchoose = MOVE_N;
						}
					}
					else
					if (yd >= 0) {
						//2nd quadrant
						if (theta < 22.5)
							dirchoose = MOVE_W;
						else if (theta < 45+22.5)
							dirchoose = MOVE_SW;
						else
							dirchoose = MOVE_S;
					}
					else {
						//3rd quadrant
						if (theta < 22.5)
							dirchoose = MOVE_W;
						else if (theta < 45+22.5)
							dirchoose = MOVE_NW;
						else
							dirchoose = MOVE_N;
					}			
			
			
					//end knight choose quadrants
			
					int x = k.getX();
					int y = k.getY();
					if (dirchoose == MOVE_N) {
						y--;
					}
					if (dirchoose == MOVE_NW) {
						y--;
						x--;
					}
					if (dirchoose == MOVE_W) {
						x--;
					}
					if (dirchoose == MOVE_SW) {
						x--;
						y++;
					}
					if (dirchoose == MOVE_S) {
						y++;
					}
					if (dirchoose == MOVE_SE) {
						y++;
						x++;
					}
					if (dirchoose == MOVE_E) {
						x++;
					}
					if (dirchoose == MOVE_NE) {
						x++;
						y--;
					}
			
					IObject o = World.getObjectAt (x, y);
			
					if ((o != null) && !isOurs(o))
						capture (k, dirchoose);
					else				
						move (k, dirchoose);
				}
		
		
		
		//land group codes
		/*
		int landset[][] = new int [72][64];
		for (int i = 0; i < 72; i++) {
			for (int j = 0; j < 64; j++) {
				landset[i][j] = -2;
			}
		int landsetsize[][] = new int [72][64];
		int landsetclosest [][] = new int [72][64];
		
		for (int i = 0; i < 72; i++) {
			for (int j = 0; k < 64; j++) {
				if  (isLandNotOurs (i, j)) {
					int set = -1;
					for (int k = -1; k <= 1; k++) {
						for (int l = -1; l <= 1; l++) {
							int x = i + k;
							int y = j + l;
							if (!((l == 0) && (k ==0)) &&
								(x >= 0) && (x <= 71) &&
								(y >= 0) && (y >= 63)) {
								if (isLandNotOurs (x, y)) {
									if (landset[x][y] >= 0)
									set = landset[x][y];
								}}
						}}
					if (set != -1) {
						landset[i][j] = set;
						landsetsize[set%64][set/64]++;
						
						
					}
					else {
						landset[i][j] = (j*64)+i;
						landsetsize[i][j]++;
						landsetclosest = (j*64)+i;
					}
				}}}
				
				else
					landset [i][j]=-1;
		*/		
	}
	
	private boolean isLandNotOurs (int x, int y) {
		IRuler r = World.getLandOwner(x, y);
		return ((r != null) && (!(r.getSchoolName()).equals(
		"Team 66")));
	}
	
	private boolean isC (IObject o) {
		return (((o.getClass()).getName()).equals("ICastle"));
	}
	
	private boolean isK (IObject o) {
			return (((o.getClass()).getName()).equals("IKnight"));
	}
	
	private boolean isP (IObject o) {
			return (((o.getClass()).getName()).equals("IPeasant"));
	}
	
	private boolean isOurs (IObject o) {
			return (this == o.getRuler());
	}
	
	
	static int P2OK  = -20;
	static int P2OL = 500;
	static int P2NL = 400;
	static int P2FL = -30;
	static int P2wall = -500;
	static int P2FP = -40;
	static int K2OC = 500;
	static int K2OK = 100;
	static int K2OK2FC = 150;
	static int K2OK2FK = 20;
	static int K2OK2FP = 10;
	static int K2OP = 20;
	static int K2wall = -500;
	static int Pradius1 = 20;
	static int Kradius1 = 50;
	static int Pthreshold1 = 12;
	static int Pthreshold2 = 17;
	static int Pthreshold3 = 25;
	static double odration = .66; 
	static double P2Lpower = .5;
	static int DK = 3;
	
	IKnight defknights [];
}