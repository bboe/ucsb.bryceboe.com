import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	protected Random rand = new Random();
//	protected int[] targets;
	protected IObject target;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Your Mother";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 51";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
//		ICastle[] otherCastles = World.getOtherCastles();
		
		ICastle[] myCastles = getCastles();
		
		target = World.getOtherCastles()[0];
		
		for(int i = 0; i < myCastles.length; i++)
		{
			createKnights(myCastles[i]);
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		IPeasant[] peasants = getPeasants();
		for(int i = 0; i < peasants.length; i++)
		{
			int dir = rand.nextInt(8) + 1;
			IObject o = objectInWay(peasants[i], dir);
			if(o != null){ dir += 4; dir = dir % 8 + 1;}
			move(peasants[i], dir);
		}

		IObject[] otherCastles = World.getOtherCastles();
		IObject[] otherPeasants = World.getOtherPeasants();
		IObject[] otherKnights = World.getOtherKnights();
		
		if(!target.isAlive() || target.getRuler().getRulerName().equalsIgnoreCase(getRulerName()))
		{
			if(otherCastles.length > 0) target = otherCastles[0];
			else
			{
				if(otherKnights.length > 0)
					target = otherKnights[0];
				else
				{
					if(otherPeasants.length > 0)
						target = otherPeasants[0];
					else
					{
						for(int i = 0; i < getCastles().length; i++)
						{
							createPeasants(getCastles()[i]);
						}
						return;
					}
				}
			}
		}
/*		else
		{
			if(!targetIsCastle(target) && (otherCastles.length > 0))
				target = otherCastles[0];
		}
*/		
		int targX = target.getX();
		int targY = target.getY();
			
		IKnight[] knights = getKnights();
		for(int i = 0; i < knights.length; i++)
		{
			int dir = knights[i].getDirectionTo(targX, targY);
			
			int j = objectAround(knights[i]);
			if(j > 0)
			{
				capture(knights[i], j);
			}
			else
			{
				IObject o = objectInWay(knights[i], dir);
				if(o == null) move(knights[i], dir);
				else move(knights[i], rand.nextInt(8) + 1);
			}
		}
		
		if(lastMoveTime > 450) return;
		
		ICastle[] myCastles = getCastles();
		for(int i = 0; i < myCastles.length; i++)
		{
			if(((i / 2 )* 2) == i)
				createKnights(myCastles[i]);
			else createPeasants(myCastles[i]);
		}
	}
	
	private boolean targetIsCastle(IObject o)
	{
		IObject[] oCastles = World.getOtherCastles();
		for(int i = 0 ; i < oCastles.length; i++)
		{
			if(o.getId() == oCastles[i].getId()) return true;
		}
		
		return false;
	}
	
	private boolean closestWall(IObject obj)
	{
		int x = World.WIDTH - obj.getX();
		int y = World.HEIGHT - obj.getY();
		int dir = 0;
		
		if((y / World.HEIGHT) < (x / World.WIDTH))
		{
			return true;
		}
		
		return false;
	}
	
	private IObject objectInWay(IObject o, int dir)
	{
		Point p = World.getPositionAfterMove(o.getX(), o.getY(), dir);
		if(p == null)
		{
			p = new Point();
			p.x = o.getX();
			p.y = o.getY();
		}
		return World.getObjectAt(p.x, p.y);
	}
	
	private int objectAround(IObject o)
	{
		for(int i = 1; i < 9; i++)
		{
			IObject o2 = objectInWay(o, i);
			if(o2 != null)
			{
				if(!o2.getRuler().getRulerName().equalsIgnoreCase(getRulerName()))
				{
					return i;
				}
			}
		}
		return 0;
	}
	
/*	private int getNextX(IObject o, int dir)
	{
		int nextX = 0;
		switch(dir)
		{
			case 2: nextX = 1; break;
			case 3: nextX = 1; break;
			case 4: nextX = 1; break;
			case 6: nextX = -1; break;
			case 7: nextX = -1; break;
			case 8: nextX = -1; break;
		}
		
		nextX += o.getX();
		
		return nextX;
	}
	
	private int getNextY(IObject o, int dir)
	{
		int nextY = 0;
		switch(dir)
		{
			case 1: nextY = 1; break;
			case 2: nextY = 1; break;
			case 4: nextY = -1; break;
			case 5: nextY = -1; break;
			case 6: nextY = -1; break;
			case 8: nextY = 1; break;
		}
		
		nextY += o.getY();
		
		return nextY;
	}
*/
}
