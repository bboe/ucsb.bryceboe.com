import com.ibm.ruler.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	public String getRulerName() {return "Xilinx_Sucks";}

	public String getSchoolName() {return "Team 39";}

	int turnCounter=0; 
	int nextPawn = 1;

	public void initialize() {
		createPeasants(getCastles()[0]);
	}

/*		// put implementation here
		
		//get all castles
		//get all pawns
		//initialize landPlots
		int xxx = 0;
		int yyy = 0;
		//for (; xxx <= 64; xxx+=18, yyy+=16) {
		
			
			
	}

	landPlot[][]lar = new landPlot[4][4];
*/
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */


//int [] dir;
//int dirc=11;

void movePawn(){
	IPeasant[] ps = peasants;

	IObject iob = null;
	
	for (int i = 0; i < ps.length; i++) {
		
		IPeasant p = ps[i];
		int cur_x = p.getX();
		int cur_y = p.getY();
		int d = i%8;
		if (d == 0) d = 8;
		switch (d) {
			
					case 1: iob = World.getObjectAt(cur_x, cur_y - 1);
							break;
					case 2: iob = World.getObjectAt(cur_x + 1, cur_y - 1);
							break;
					case 3: iob = World.getObjectAt(cur_x + 1, cur_y);
							break;
					case 4: iob = World.getObjectAt(cur_x + 1, cur_y + 1);
							break;
					case 5: iob = World.getObjectAt(cur_x, cur_y + 1);
							break;
					case 6: iob = World.getObjectAt(cur_x - 1, cur_y +1);
							break;
					case 7: iob = World.getObjectAt(cur_x - 1, cur_y);
							break;
					case 8: iob = World.getObjectAt(cur_x - 1, cur_y - 1);
							break;
				}
		
		if (iob == null) {
			if (((cur_x + 1) >= 72) || ((cur_y + 1) >= 64)
				|| ((cur_x - 1) <= 0) || ((cur_y -1) <= 0)) {
				d = ((int)(Math.random()*8))+1;
				move(p, d);	
			}
			else {
			move(p, d); }
		}
		else {
			d = ((int)(Math.random()*8))+1;
			move(p, d);	
		}
	}
	
	//if(turnCounter < 10){		
	//	if(nextPawn >= ps.length-1) nextPawn = 0;
	//	IPeasant p = ps[nextPawn++];
	//	moveInitPawn(p);
//}else{
//	if(nextPawn >= ps.length-1) nextPawn = 0;
//		moveZigzagPawn(ps[nextPawn++]);
//		if(nextPawn >= ps.length-1) nextPawn = 0;
//		moveZigzagPawn(ps[nextPawn++]);
//		if(nextPawn >= ps.length-1) nextPawn = 0;
//		moveZigzagPawn(ps[nextPawn++]);
//	}	
}

void moveInitPawn(IPeasant p){
	int dir = 1;
	dir = (int)(Math.random() * 8) + 1;	
//System.err.println("init dir="+dir+" p="+p)	;	
} 

final void moveZigzagPawn(IPeasant p){
int dir = (int)(Math.random() * 8) + 1;
int d2 = (dir) == 1 ? 8 : dir-1; 
//System.err.println("zigzag dir="+dir+" p="+p);
move(p, dir);
//move(p, dir);
//move(p, dir);
//move(p, dir);
//move(p, dir);
//move(p, d2 );
//move(p, d2);
//move(p, d2);
//move(p, d2);
//move(p, d2);
/*move(p, dir);
move(p, dir);
move(p, dir);
move(p, dir);
move(p, dir);
move(p, dir);
move(p, d2);
move(p, d2);
move(p, d2);
move(p, d2);
move(p, d2);*/
} 



	public void orderSubjects(int lt) {
if(lt > 500) System.err.println("$$$ lt="+lt);

turnCounter++;		

  knights = getKnights();
  peasants = getPeasants();
  doKnights();
  if (turnCounter < 15) {
  movePawn();}
  else {
	for (int i = 0; i < peasants.length; i++) {
  		moveZigzagPawn(peasants[i]);
	}
  }
  	  

//movePawn();



//		dirc++;
//		IPeasant[] ps =  getPeasants();
//		for(int i=0; i < ps.length; i++){
//		    if(dirc >= 10){
//		  		dir[i] = ((int)(Math.random()*8))+1;
//		  	}
	
		  	  
//		  move( ps[i], dir[i]);
//		  move( ps[i], dir[i]);
		
		  //}			
			
		
		
		
	}
	
Point ptemp = new Point();	
IKnight[] knights;
IPeasant[] peasants;

	final void  doKnights() {
		
		//int x_g;
		//int y_g;
		int num_k = knights.length;
		int attack_num = num_k;//(int)(.3 * num_k);
		nearestCastle(ptemp);
		//int i = 0;
		for (int i = 0; i < attack_num; i++) {
			int xxx = moveAndAttack(knights[i], ptemp.x, ptemp.y);
			//if (i < peasants.length)
			//	move(peasants[i], xxx);
		}
	}
	
	final void  nearestCastle(Point p) {
		
		//int index = 0;
		ICastle[] castles = World.getOtherCastles();
		if (castles.length == 0) return;
		ICastle c = castles[0];
		p.x = c.getX();
		p.y  = c.getY();
		
		
		//int nearest = 100;
		
		//for (int i = 0; i < castles.length; i++) {
		//	int dist =
		//}
		
	}
	
	final int  moveAndAttack(IKnight knight, int x, int y) {
		
		int cur_x = knight.getX();
		int cur_y = knight.getY();
		
		int d_next;
		
		if (x > cur_x) {
			if (y > cur_y) {
				d_next = 4;}
			else if (y == cur_y) {
				d_next = 3;
			}
			else {
				d_next = 2;
			}
		}
		else if (x == cur_x) {
			if (y > cur_y) {
				d_next = 5;
			}
			else {
				d_next = 1;
			}
		}
		else {
			if (y > cur_y) {
				d_next = 6;
			}
			else if (y == cur_y) {
				d_next = 7;
			}
			else {
				d_next = 8;
			}
		}
		
		IObject iob = null;
		
		switch (d_next) {
			
			case 1: iob = World.getObjectAt(cur_x, cur_y - 1);
					break;
			case 2: iob = World.getObjectAt(cur_x + 1, cur_y - 1);
					break;
			case 3: iob = World.getObjectAt(cur_x + 1, cur_y);
					break;
			case 4: iob = World.getObjectAt(cur_x + 1, cur_y + 1);
					break;
			case 5: iob = World.getObjectAt(cur_x, cur_y + 1);
					break;
			case 6: iob = World.getObjectAt(cur_x - 1, cur_y +1);
					break;
			case 7: iob = World.getObjectAt(cur_x - 1, cur_y);
					break;
			case 8: iob = World.getObjectAt(cur_x - 1, cur_y - 1);
					break;
		}
		
		
		if (iob == null) { move(knight,d_next); }
		else if (!iob.getRuler().getSchoolName().equals(getSchoolName())) {
			capture(knight, d_next);
		}
		else {
			d_next = ((int)(Math.random()*8))+1;
			move(knight, d_next);	
		}
		return d_next;
	}
	
/*	
	Vector protect = new Vector(); 
	private final void protect(){
		for (int li=0; i < protect.size(); i++){
			Protection p = (Protection) protect.get(li);
			for(int i =0; i< p.parea.length; i++){
				for(int j=0; j<p.area[i].length; j++)
					if()
			}
		}
		
	}
		
*/
//inner class definition
/*	
static class landPlot {
	
	int x_coord;
	int y_coord;
	IPeasant assigned_p;
	boolean hasCastle;
	
	landPlot() {}
	
	landPlot(IPeasant p, boolean hc, int xxx, int yyy) {
		x_coord = xxx;
		y_coord = yyy;
		assigned_p = p;
		hasCastle = hc;
	}
	
	boolean isWithinPlot(int x, int y) { }
	}
	
} //landPlot
	
static	class Protection{
		private Point cpos;//castle position
		private int[][] parea;//protection area		 
		IKnight k1, k2;
}
	*/ 
	
static	class Point {
		public int x,y;
		Point(){}
		Point(int xxx, int yyy) {
			x = xxx;
			y = yyy;
		}
}

}

