import com.ibm.ruler.*;
//import com.sun.rsasign.i;

import java.util.*;
import java.awt.Point;

public class MyRuler extends Ruler {
	protected Random rand = new Random();
	public String getRulerName() {return "B33fy ";}
	public String getSchoolName() {	return "Team 18";}
	public void initialize() {

	}
	public void orderSubjects(int lastMoveTime) {
		//Production
		//
		//
		//
		
		ICastle[] castles = getCastles();
		int choice = getPeasants().length > getKnights().length? 2:1;
		for (int j = 0; j< castles.length; j++){
			if(choice ==2)
				createKnights(castles[j]);
			else
				createPeasants(castles[j]);	
		}
		//
		//
		//Knights
		//
		//
		
		IKnight[] knights = getKnights();
		ICastle[] o_castles = World.getOtherCastles();
		ICastle targetCastle;

		if (o_castles.length==0){
			outer2:for (int i = 0; i<knights.length; i++){
				IKnight ck = knights[i];
				for (int j = 1; j<=8; j++){
					Point p1 = World.getPositionAfterMove(ck.getX(), ck.getY(), j);
						if (p1!= null){
							IObject o1 = World.getObjectAt(p1.x, p1.y);
							if(o1 != null){
								if (o1.getRuler()!=this){
									capture(ck, j);
									continue outer2;
								}
							}
						}
					move(ck, rand.nextInt(8)+1);
				}
			}
		}else{
		
		int size = knights.length;
		Point center = new Point();
		for (int i = 0; i< size; i++){
			center.x += knights[i].getX();
			center.y += knights[i].getY();
		}
		center.x /= knights.length;
		center.y /= knights.length;
		
		int min_dist = 100000;
		int min_index = 0;
		for (int i = 0; i<o_castles.length; i++){
			if(o_castles[i].getDistanceTo(center.x, center.y)<min_dist){
				min_dist =o_castles[i].getDistanceTo(center.x, center.y);
				min_index = i;
			} 
		}
		
		int dir_to = o_castles[min_index].getDirectionTo(center.x, center.y);
		dir_to = opdir(dir_to);
		
		outer:for (int i = 0; i<knights.length; i++){
			IKnight ck = knights[i];
			dir_to = opdir(o_castles[min_index].getDirectionTo(ck.getX(), ck.getY()));
			
			for (int j = 1; j<=8; j++){
				Point p1 = World.getPositionAfterMove(ck.getX(), ck.getY(), j);
				if (p1!= null){
					IObject o1 = World.getObjectAt(p1.x, p1.y);
					if(o1 != null){
						if (o1.getRuler()!=this){
							capture(ck, j);
							continue outer;
						}
					}
				}
				else{
					move(ck,rand.nextInt(8)+1);
				}
			}			
			Point p1 = World.getPositionAfterMove(ck.getX(), ck.getY(), dir_to);
			if(p1!=null){

				IObject o1 = World.getObjectAt(p1.x, p1.y);
				if(o1 != null){
					if(o1.getRuler()!= this){
						//System.out.println("woohoo3");
						capture(ck, dir_to);
						continue;
					}
				}
				move(ck, dir_to);
			}
			else{
				move(ck, rand.nextInt(8) +1);
			}
		}//end for
		
		}
		//
		//
		//Peasants
		//
		//
		
		IPeasant[] peasants = getPeasants();

		 for (int i = 0; i < peasants.length; i++){
			IPeasant p1 = peasants[i];
			if (isInTrouble(p1)>0){
				move(p1, opdir(isInTrouble(p1)));
				continue;			
			}
			int b_safe_loc = -1;
			for (int j = 1; j <= 8; j++){
				Point p = World.getPositionAfterMove(p1.getX(), p1.getY(), j);
				if(p == null) continue;
				if(isSafeLocation(p)>0){
				
					IRuler lRuler = World.getLandOwner(p.x, p.y);
					if (lRuler != this){
						//System.out.println("woohoo2");
						move(p1, j);
						b_safe_loc =100;
						break;
					}
					else{
						//System.out.println("woohoo");
						b_safe_loc = j;
					}
				}
			}
			if(b_safe_loc==100){}
			else if(b_safe_loc>0){
				move(p1, b_safe_loc);
			}
			else{
				//move(p1, rand.nextInt(8)+1);
				move(p1, p1.getDirectionTo(36,32));
			}
		}
				/*
		for(int i = 0; i< peasants.length; i++){
			move(peasants[i], rand.nextInt(8)+1);
		}*/
	}
	
	public int isInTrouble(IPeasant ip){
		Point p1 =new Point(ip.getX(), ip.getY());
		for (int i = 1; i<=8; i++){
			Point Ptemp = World.getPositionAfterMove(p1.x, p1.y, i);
			if (Ptemp ==null) continue;
			IObject o1 = World.getObjectAt(Ptemp.x, Ptemp.y);
			if(o1 == null) continue;
			if (o1.getRuler() != this){
				return i;
			}			
		}
		return 0;
	}
	
	public int isSafeLocation(Point p1){
		for (int i = 1; i<=8; i++){
			if (p1.x<0 || p1.x>72 ||p1.y<0 || p1.y>64) continue;
			Point ptemp = World.getPositionAfterMove(p1.x, p1.y, i);
			if(ptemp ==null) continue;
			IObject o = World.getObjectAt(ptemp.x, ptemp.y);
			if (o == null) continue;
			boolean flag;
				try{
					IPeasant j = (IPeasant)o;
					flag = true;
				}
				catch(Exception e){
					flag = false;
				}
			if (flag) continue;
			if(o.getRuler() != this)
				return -i; 
		}
		return 10;
	}
	
	public int opdir(int i){
		i -=4;
		if (i<=0) i+=8;
		return i;
	}
}