import com.ibm.ruler.*;
import java.awt.*;
import java.util.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	 
	private static String SchoolName = "Team 41";
	private static String RulerName = "Tron";
	
	private int			PrevPCount;
	private int			PrevKCount;
	private int			PrevCCount;
	
	private IPeasant    OurP[];
	private IKnight 	OurK[];
	private ICastle		OurC[];
	
	private IPeasant	OurPrevP[];
	private IKnight		OurPrevK[];
	private ICastle		OurPrevC[];
	
	private IPeasant	OtherP[];
	private IKnight		OtherK[];
	private ICastle		OtherC[];
	
	private IPeasant	OtherPrevP[];
	private IKnight		OtherPrevK[];
	private ICastle		OtherPrevC[];	
	
	private int			PCount;
	private int			CCount;
	private int			KCount;
	
	private int 		numC;
	
	private IObject			Target;
	protected Random rand = new Random();
	
	
	public String getRulerName() {
		return "Tron";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 41";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() 
	{
		numC = World.getOtherCastles().length + 1;
	}
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) 
	{
		System.out.println ("Time: " + lastMoveTime);
		
		PrevPCount = PCount;
		PrevKCount = KCount;
		PrevCCount = CCount;
		
		OurP = getPeasants();
		OurK = getKnights();
		OurC = getCastles();
		
		CCount = OurC.length;
		PCount = OurP.length;
		KCount = OurK.length;
		
		//OtherPrevP = OtherP;
		//OtherPrevK = OtherK;
		//OtherPrevC = OtherC;
		
		OtherP = World.getOtherPeasants();
		OtherK = World.getOtherKnights();
		OtherC = World.getOtherCastles();
	
		Point afterMove;
		IObject objectAfterMove;
		int dir;
		
		if ((World.getCurrentTurn()%4) == 0)
		{
			int OurNeeds = detNeeds();
				
			if (CCount == 1)
			{
				if (OurNeeds >= 60)
				{
					createPeasants(OurC[0]);
				}
				else
				{
					createKnights (OurC[0]);
				}
			}
			else
			{
				for (int C = 0; C < CCount; C++)
				{
					if (C % 2 == 0)
					{
						createPeasants(OurC[C]);
					}
					else
					{
						createKnights (OurC[C]);
					}
				}
			}	
		}

		
		if(PCount != 0)	
		{
			IPeasant curP;
		
			for(int P = 0 ; P < PCount; P++)
			{
				curP = OurP[P];
				dir = rand.nextInt(8) + 1;		
				afterMove = World.getPositionAfterMove(curP.getX(), curP.getY(), dir);

				
				while(afterMove == null || !InBounds(afterMove))
				{
					dir = rand.nextInt(8) + 1;
					afterMove = World.getPositionAfterMove(curP.getX(), curP.getY(), dir);
				}
				
				move(curP, dir);
			}
		}
		
		
		
		if (KCount != 0)
		{
			if(Target == null || Target.getRuler() == this)
			{
				Target = getClosestC();
				if (Target == null)
				{
					Target = getClosestK();
				}
				if (Target == null)
				{
					Target = getClosestP();
				}
			}
			
			if(Target != null)
			{
				IKnight curK;

				for (int K = 0; K < KCount; K++)
				{
					curK = OurK[K];
					dir = getDirection(curK, Target);
			
					afterMove = World.getPositionAfterMove (curK.getX(), curK.getY(), dir);
					if (afterMove != null)
					{
						objectAfterMove = World.getObjectAt (afterMove.x, afterMove.y);		
					}
					else
					{
						objectAfterMove = null;
					}
					
					if (objectAfterMove == null)
					{
						move(curK, dir);
					}
					else
					{
						if (objectAfterMove.getRuler() != this)
						{
							capture (curK, dir);
						}
						else
						{
							move (curK, changeDirection (dir));
						}
						
					}
				}
			}
		}
		
		
		
		
		
		//kngihts move towards castles.
		// if knight close by
		//		if im alone 
		//			if low strength, canibalize
		//			else run like a mother
		//		else cannibalize
		// else keep going
		
		//peassants go for land, behind castles
	}
		


	
	//Determine needs and return a percent of P to produce
	private int detNeeds ()
	{
		int PChange = PrevPCount - PCount;
		int KChange = PrevKCount - KCount;
	
		//Possibly factor what will be produced this turn.
		//Another possible factor, loss of castles
		
		if(CCount >= numC - 1)
		{
			//All P
			return 90;
		}
		else if (CCount == 0)
		{
			//No P, 100% K
			return 0;
		}
		else 
		{
			//Percent bassed upon diff of P and K
			return (int)(100*((float)PChange/KChange));
		}
	}
	
	private ICastle getClosestC()
	{
		int tempD;
		int smallD = World.HEIGHT * World.WIDTH;
		ICastle closeC = null;
		for(int C = 0; C < OtherC.length; C++)
		{
			if((tempD = getDistance(OurK[0], OtherC[C])) < smallD)
			{
				closeC = OtherC[C];
				smallD = tempD;
			} 
		}
		
		return closeC;
	}
	
	private IKnight getClosestK()
	{
		int tempD;
		int smallD = World.HEIGHT * World.WIDTH;
		
		IKnight closeK = null;
		
		for (int K = 0; K < OtherK.length; K++)
		{
			if ((tempD = getDistance (OurK[0], OtherK[0])) < smallD)
			{
				closeK = OtherK[K];
				smallD = tempD;
			}
		}
		
		return closeK;
	}
	
	private IPeasant getClosestP()
		{
			int tempD;
			int smallD = World.HEIGHT * World.WIDTH;
		
			IPeasant closeP = null;
		
			for (int P = 0; P < OtherP.length; P++)
			{
				if ((tempD = getDistance (OurK[0], OtherP[0])) < smallD)
				{
					closeP = OtherP[P];
					smallD = tempD;
				}
			}
		
			return closeP;
		}
	
	private int getDirection(IObject From, IObject To)
	{
		return From.getDirectionTo(To.getX(), To.getY());
	}
	
	private int getDistance(IObject From, IObject To)
	{
		return From.getDistanceTo(To.getX(), To.getY());
	}
	
	private int changeDirection (int dir)
	{
		dir = (dir + 1)% 8;
		if(dir == 0) dir = 8;
		
		return dir;
	}
	
	private boolean InBounds (Point loc)
	{
		if (loc.x >= World.HEIGHT || loc.x < 0 || loc.y >= World.WIDTH || loc.y < 0)
		{
			return false;
		}
		return true;
	}
}