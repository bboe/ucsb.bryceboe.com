import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Beginner's Luck";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 7";
	}


    private static int p_dir[] = new int[1000];
    private static int k_dir[] = new int[1000];
    private static Random rand;

    HashMap pMap = new HashMap(500);
	
	HashMap kMap = new HashMap(500);
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
        rand = new Random();
		IPeasant[] peasants = getPeasants();
		for(int i=0;i<peasants.length;i++){
			pMap.put(new Integer(peasants[i].getId()),new peasantClass((i%8)+1));
		}
		IKnight[] knights = getKnights();
		
		for(int i=0;i<knights.length;i++){
			kMap.put(new Integer(knights[i].getId()),new knightClass());
		}
		
		
		//initial directions for knights (set each one on a castle)
		ICastle[] castles = World.getOtherCastles();
		int nCastles = castles.length;
		knightClass knight; 
		for(int i=0;i<knights.length;i++){
			knight = (knightClass)kMap.get(new Integer(knights[i].getId()));
			knight.setDestination(castles[i%nCastles]);
		}   
	} /// INITIALIZE END

    int tempx, tempy;
    Point tempPoint;
    class peasantClass {
    	public Point lastPoint;
    	public Point currPoint;
    	public int direction;
    	
    	public int getDirection() { 
			if(lastPoint==null) {return direction;}
			else
			if(lastPoint.equals(currPoint)) {
				direction = (direction+1)%8;
				if(direction==0)direction++; 
			}
			
			return direction;  	
    	}
    	
    	public peasantClass(int i) {
    		direction = i;
    	}
    		
    }
    
	class knightClass {
		public Point lastPoint;
		public Point currPoint;
		public int direction;
		public IObject destination;
		public Point dest;
		
		public void setDestination(IObject d){
			destination = d;
			dest = new Point(d.getX(), d.getY());
		}
    	
		public int getDirection() { 
			if(lastPoint==null) {return direction;}
			else
			if(lastPoint.equals(currPoint)) {
				direction = (direction+1)%8;
				if(direction==0)direction++; 
			}	
			return direction;  	
		}
    	
		public knightClass() {
			
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		ICastle [] icastle = getCastles();


		if(icastle[0] != null){
			if(World.getCurrentTurn()<300) {
					createPeasants(icastle[0]);
		    }else{
		    	
	    		createKnights(icastle[0]);
			}
	    	for(int i=1; i<icastle.length; i++) {
	    		createKnights(icastle[i]);
	    	}
		}



		
		doPeasants();
		doKnights();
	}

	
	peasantClass pclass;
	IPeasant[] peasants;
	int psize;
	int pdir;
	public void doPeasants() {
		
	    	
		peasants = getPeasants();
	    psize = peasants.length;
	 	
		for (int i=0;i<psize; i++) {
			pclass = ((peasantClass)pMap.get(new Integer(peasants[i].getId())));
			if(pclass==null) {
			  pclass = new peasantClass(rand.nextInt(8)+1);
			  pMap.put(new Integer(peasants[i].getId()), pclass);
			}  
			
			if(pclass.direction==0) pclass.direction = rand.nextInt(8)+1;
			pdir = pclass.getDirection();
	//		if(pclass.lastPoint!=null && pclass.currPoint!=null) {
	//			tempPoint = World.getPositionAfterMove(peasants[i].getX(),peasants[i].getY(), dir);
	//			if( World.getLandOwner((int) tempPoint.getX(), (int)tempPoint.getY())==this)
	//			  dir = rand.nextInt(8)+1;
	//		}
			
			move(peasants[i],pdir);
			pclass.lastPoint = pclass.currPoint;
	        pclass.currPoint = new Point(peasants[i].getX(), peasants[i].getY());
	        
			
	        
	             ////////////////////	 move(peasants[i], rand.nextInt(8)+1);	
		}
		
	} // DO PEASEANTS END
	

    IKnight[] knights;
	int dir;
	int ksize;
	Point pt;
	IObject iobj; 	
	int count=0;
	int castleIndex = 0;
	int nCastles;
	int peasantIndex = 0;
	int nPeasants;
	ICastle[] castles ;
	IKnight [] oknights;
	int nKnights;
	int knightIndex;
	
	public void doKnights() {
	  	knights = getKnights();
	  	ksize = knights.length;
	  	knightClass knight;
		castles = World.getOtherCastles();
		nCastles = castles.length;
		castleIndex = nCastles-1;
		peasants = World.getOtherPeasants();
		//oknights = World.getOtherKnights();
		
		nPeasants = peasants.length;
		peasantIndex = nPeasants-1;
		//nKnights = oknights.length;
		//knightIndex = nKnights-1;
		
		
		if(ksize > 20)
			ksize = 20;
	  	
	  	for(int i=0;i<ksize; i++){
	  		knight = (knightClass)kMap.get(new Integer(knights[i].getId()));

			if(knight==null) {
			  knight = new knightClass();
			  
			  if(castleIndex>=0){
			  	knight.setDestination(castles[castleIndex]);
			  	castleIndex--;
			  }
			  else if(peasantIndex>=0){  
			  	    knight.setDestination(peasants[peasantIndex]);
					peasantIndex--;
			  }
			  //else
			  //if(knightIndex>=0){  
			//		knight.setDestination(knights[knightIndex]);
			//		knightIndex--;
			//  }
			 
	
			  kMap.put(new Integer(knights[i].getId()), knight);
			}  


			if(!knight.destination.isAlive()){
				if(castleIndex>=0){
								knight.setDestination(castles[castleIndex]);
								castleIndex--;
							  }
							  else if(peasantIndex>=0){  
									knight.setDestination(peasants[peasantIndex]);
									peasantIndex--;
							  }
			//				  else
			//				  if(knightIndex>=0){  
			//						knight.setDestination(knights[knightIndex]);
			//						knightIndex--;
			//				  }
			 
			}

	  		dir=knights[i].getDirectionTo((int)knight.dest.getX(), (int)knight.dest.getY());
	  		pt=World.getPositionAfterMove(knights[i].getX(), knights[i].getY(), dir);
	  		iobj = World.getObjectAt((int)pt.getX(), (int)pt.getY());
	  		if(iobj==null) {
	  			count = 0;
				if(knight.lastPoint!=null) {
				  if(knight.lastPoint.equals(knight.currPoint)){
					knight.direction=rand.nextInt(8)+1;
				  }
				}				  
	  			move(knights[i], dir);
				knight.lastPoint = knight.currPoint;
				knight.currPoint = new Point(knights[i].getX(), knights[i].getY());
	  		}
	  		else {
	  			count++;
	  			if(count>5)
	  				capture(knights[i], dir);
	  			else{
					if(castleIndex>=0){
									knight.setDestination(castles[castleIndex]);
									castleIndex--;
								  }
								  else if(peasantIndex>=0){  
										knight.setDestination(peasants[peasantIndex]);
										peasantIndex--;
								  }
			//					  else
			//					  if(knightIndex>=0){  
			//							knight.setDestination(knights[knightIndex]);
			//							knightIndex--;
			//					  }
			 
	  			}
	  		}
	  	}
	} // DO KNIGHTS END
		
	
	
}