import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */



public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */

	protected Random rand = new Random();
	int[] peasDirect;
	int[] peasSteps;
	IKnight[][] assaultTeam;
	int numTeams=0;
	int alternation=0;
	int reserveKnights=0;
	boolean[] alreadyMoved;
	
	IKnight[] knights;
	IPeasant[] peasants;
	ICastle[] castles;
	ICastle[] enemyCastles;
	
	int lands;
	
	public String getRulerName() {
		return "Wing Zero";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 8";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		peasDirect = new int[200];
		peasSteps = new int[200];
		assaultTeam = new IKnight[100][20];
		alreadyMoved = new boolean[200];
		
		knights = getKnights();
		peasants = getPeasants();
		castles = getCastles();
		
		//assaultteam
		for(int i=0; i< 10; i++)
		{
			assaultTeam[0][i] = knights[i];
		}
		for(int i=0; i< 5; i++)
		{
			assaultTeam[1][i] = knights[i+5];
		}
		numTeams=2;
		
		for(int i=0; i< peasants.length; i++)
		{
			peasDirect[i] = rand.nextInt(8)+1;
		}
		
		enemyCastles = World.getOtherCastles();
		//sort enemy castles
		ICastle temp;
		for(int i=0; i< enemyCastles.length; i++)
		{
			int distA = castles[0].getDistanceTo(enemyCastles[i].getX(), enemyCastles[i].getY());				

			for(int x=0; x <enemyCastles.length; x++)
			{
				int distB = castles[0].getDistanceTo(enemyCastles[x].getX(), enemyCastles[x].getY());				
				if(distA < distB)
				{
					temp = enemyCastles[i];
					enemyCastles[i] = enemyCastles[x];
					enemyCastles[x] = temp;				
				}
			}
		}
		
		lands = getOwnedLandCount();
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */

	public boolean knightCapture(IKnight knight)
	{
		for(int i=1; i<9; i++)
		{
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			
			if(np!=null)
			{
				IObject object = World.getObjectAt(np.x, np.y);
				if(object!=null && !object.getRuler().equals(knight.getRuler()))
				{
					capture(knight,i);
					if(object instanceof ICastle)
					{
						castles = getCastles();

					}
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean peasantFlee(IPeasant knight)
		{
			for(int i=1; i<9; i++)
			{
				Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			
				if(np!=null)
				{
					IObject object = World.getObjectAt(np.x, np.y);
					if(object!=null)
					{
						if(i == 4)
							move(knight, 8);
						else
							move(knight, (i+4)%8);
						return true;
					}
				}
			}
			return false;
		}
		
	public void orderSubjects(int lastMoveTime) {
		//creation
		enemyCastles = World.getOtherCastles();
		castles = getCastles();		
		//sort enemy castles
		ICastle temp;
		for(int z=0; z< enemyCastles.length; z++)
		{
			int distA = castles[0].getDistanceTo(enemyCastles[z].getX(), enemyCastles[z].getY());				

			for(int x=0; x <enemyCastles.length; x++)
			{
				int distB = castles[0].getDistanceTo(enemyCastles[x].getX(), enemyCastles[x].getY());				
				if(distA < distB)
				{
					temp = enemyCastles[z];
					enemyCastles[z] = enemyCastles[x];
					enemyCastles[x] = temp;				
				}
			}
		}
		
		if(lands > 125 )
		{
			for(int i=0; i < castles.length; i++)
			{
				ICastle currCastle = castles[i];
				
				if((alternation%3 == 0))
				{
					createPeasants(currCastle);
				}
				else
				{
					createKnights(currCastle);
					reserveKnights++;
				}				

			}
		}
		alternation++;
		
		knights = getKnights();
		peasants = getPeasants();
		for(int x=0; x< peasants.length; x++)
		{
			if(peasDirect[x]==0)
				peasDirect[x] = rand.nextInt(8)+1;
		}

		//generate assaultteam
		if(World.getCurrentTurn() == 400)
			reserveKnights = 10;
		else if(World.getCurrentTurn() > 450)
			reserveKnights = 10;	
			
		if(reserveKnights > 3)
		{
			//reassign assault
			numTeams=0;
			for(int i=0; i< knights.length; i+=4)
			{
				assaultTeam[numTeams][0] = knights[i];
				if(i+1 < knights.length)
				assaultTeam[numTeams][1] = knights[i+1];
				if(i+2 < knights.length)
				assaultTeam[numTeams][2] = knights[i+2];
				if(i+3 < knights.length)
				assaultTeam[numTeams][3] = knights[i+3];
				if(i+4 < knights.length)
				assaultTeam[numTeams][4] = knights[i+4];
				numTeams++;
			}
			
			reserveKnights=0;
		}

		//check all knights to see if they can capture
		for(int i=0; i< knights.length; i++)
		{
			if(knightCapture(knights[i]))
				alreadyMoved[i]=true;
			else
				alreadyMoved[i]=false;
		}
		
		//onlymove assault team
		for(int i=0; i< numTeams; i++)
		{
			for(int x=0; x<20; x++)
			{
				if(assaultTeam[i][x]!=null)
				{
					int r;
					for(r=0; r<knights.length; r++)
						if(assaultTeam[i][x].equals(knights[r]))
							break;
					if(!alreadyMoved[r]) 
					{
					
					//movement of knights 
					int primeDirection = 1;
					if(enemyCastles.length >0)
						primeDirection = assaultTeam[i][x].getDirectionTo
								(enemyCastles[i%enemyCastles.length].getX(), enemyCastles[i%enemyCastles.length].getY());
					else
					{
						IPeasant[] enemyp = World.getOtherPeasants();
						//sort enemy castles
						IPeasant tempp;
						for(int z=0; z< enemyp.length; z++)
						{
							int distA = assaultTeam[i][x].getDistanceTo(enemyp[z].getX(), enemyp[z].getY());				

							for(int ss=0; ss <enemyCastles.length; ss++)
							{
								int distB = assaultTeam[i][ss].getDistanceTo(enemyp[x].getX(), enemyp[ss].getY());				
								if(distA < distB)
								{
									tempp = enemyp[z];
									enemyp[z] = enemyp[ss];
									enemyp[ss] = tempp;				
								}
							}
						}
						primeDirection = assaultTeam[i][x].getDirectionTo(enemyp[i%enemyp.length].getX(), enemyp[i%enemyp.length].getY());
					}
					
					Point np = World.getPositionAfterMove(assaultTeam[i][x].getX(), assaultTeam[i][x].getY(),
														primeDirection);
					
					IObject obj = World.getObjectAt(np.x, np.y);									
					if(np!=null)
					{
						if(obj==null)
							move(assaultTeam[i][x],primeDirection);
						else
							move(assaultTeam[i][x],rand.nextInt(8)+1);
					}
					else
						move(assaultTeam[i][x],rand.nextInt(8)+1);
					}
				}
			}
		}
			
			
		//movement of peasants 
		for(int i=0; i < peasants.length; i++)
		{
			if(!peasantFlee(peasants[i]))
			{
			
			int direction;
			if(peasSteps[i]<20)
				direction = peasDirect[i];
			else
				direction = rand.nextInt(8)+1;
		
			Point np = World.getPositionAfterMove(peasants[i].getX(), peasants[i].getY(),
												direction);
			if(np!=null)
					move(peasants[i],direction);				 
			else
			{
				peasSteps[i]=10;
				move(peasants[i],rand.nextInt(8)+1);
			}
				
			peasSteps[i]++;
			}
		}
			
	}
}