import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	protected Random rand = new Random();
	ICastle targetC;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "CASWILL";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "TEAM 6";
	}

	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		targetC = World.getOtherCastles()[0];
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public boolean kC(IKnight k){
		for (int i = 1 ; i<9; i++){
			Point np = World.getPositionAfterMove(k.getX(), k.getY(),i);
			if (np != null){
				IObject o = World.getObjectAt(np.x,np.y);
				if (o !=null && !o.getRuler().equals(k.getRuler())){
					capture(k,i);
					return true;
				}
			 
			}
		}
		return false;
	}
	public void mAndC(IKnight ks, IObject tar){
		 if (tar == null || !tar.isAlive()) return;
		 int dir = ks.getDirectionTo(tar.getX(),tar.getY());
		 Point np = World.getPositionAfterMove(ks.getX(),ks.getY(),dir);
		 if (np != null){
		 	if (tar.equals(World.getObjectAt(np.x,np.y)))
		 		capture(ks, dir);
		 	else
		 		move(ks, dir);
		 }
	}
	 
	public void esc(IPeasant p, int dir){
		 		 
		 Point np = World.getPositionAfterMove(p.getX(),p.getY(),dir);
		 if (np != null){
			dir -=1;
			np = World.getPositionAfterMove(p.getX(),p.getY(),dir);
			if (np != null){
				dir +=2;
				np = World.getPositionAfterMove(p.getX(),p.getY(),dir);
			}
		 }	
		 	move(p, dir);
	}
	 
	public void orderSubjects(int lastMoveTime) {
		ICastle[] tc = getCastles();
		int size = tc.length;
		for ( int i=0; i< size; i++){
		
			if (World.getCurrentTurn() < 250)
				createPeasants(tc[i]);
				else
		createKnights(tc[i]);
	}
		IPeasant[] tps = World.getOtherPeasants();
		IKnight[] tks = World.getOtherKnights();
		
		IKnight[] ks = getKnights();
		if (targetC.getRuler().equals(ks[0].getRuler())){
			targetC = World.getOtherCastles()[0];
		}
	    size =  ks.length;
		int tpsSize = tps.length;
		for (int i = 0 ; i < size; i++){
			if (kC(ks[i]) == false){
			
			mAndC(ks[i],targetC);
			for (int j = 0 ; j < tpsSize; j++){
				if (ks[i].getDistanceTo(tps[j].getX(),tps[j].getY()) < 6) {
					mAndC(ks[i],tps[j]);
					break;
				}				
			}
			}			
		}
		
		
		
		IPeasant[] ps= getPeasants();
		size = ps.length;
		int tksSize = tks.length;
next:		for (int i = 0; i < size; i++){
			
				int min = 50;
				int tmp ;
				int j;
				for (j = 0 ; j < tksSize; j++){
					tmp = ps[i].getDistanceTo(tks[j].getX(),tks[j].getY());
					if ( tmp < min) {
						min = tmp;
					}
				}
			if (min < 5){
				int dir = ps[i].getDirectionTo(tks[j].getX(),tks[j].getY());
				dir +=(dir > 4)?-4:4;
				esc(ps[i], dir); 
			}			
			else {
				boolean mov = false;
				for (int k = 1 ; k<9; k++){
					Point np = World.getPositionAfterMove(ps[i].getX(), ps[i].getY(),k);
					if (np != null){
						IObject o = World.getObjectAt(np.x,np.y);
						/*if (o ==null && !World.getLandOwner(np.x,np.y).equals(ps[i].getRuler())){
								move(ps[i],k);
								mov = true;
								//continue next;
						}*/
			 
					}
				}
				if (mov == false )
					if (ps[i].getX() + ps[i].getY() > 68)
						move(ps[i],rand.nextInt(8)+1);
					else
						move(ps[i],rand.nextInt(8)+1);	
				}
			}
		}
		
	
}