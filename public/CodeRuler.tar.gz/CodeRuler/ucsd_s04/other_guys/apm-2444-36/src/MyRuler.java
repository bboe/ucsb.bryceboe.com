import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	 public static Random rand = new Random();
	 //public IRuler[] otherRulers; 
	 //public ICastle[] otherCastles;
	 public IRuler weakRuler;
	public ICastle[] otherCastles;
	public int castleInd=0;
	 
	
	public String getRulerName() {
		return "KTMC";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 36";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		//otherRulers = World.getOtherRulers();
		//weakRuler = findWeakestRuler();
		//otherCastles = weakRuler.getCastles();
		otherCastles = World.getOtherCastles();
		
	}
	public IRuler findWeakestRuler(){
		IRuler[] otherRulers = World.getOtherRulers();
		int maxPoints = 0;
		IRuler retRuler = null;
		for(int i=0; i<otherRulers.length; i++){
			int points = otherRulers[i].getPoints();
			if(points > maxPoints){
				maxPoints = points;
				retRuler = otherRulers[i];
			}
		}
		return retRuler;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		//(lastMoveTime < 400){
		
		produce();
		System.err.println("lastMoveTime: "+lastMoveTime);
		movePeasant();
		moveKnight();
		//
		
		/*
		IKnight[] knights = getKnights();
		for(int i=0; i<knights.length; i++){
			move(knights[i], rand.nextInt(8)+1);
		}
		*/
		
		
		//move(getKnights()[0], MOVE_E);
	}
	public void produce(){
		int difference = 0;
		ICastle[] castleAry = getCastles();
		IPeasant[] peasants = getPeasants();
		IKnight[] knights = getKnights();
		if((peasants.length - difference) > knights.length){
		
		for(int i=0; i<castleAry.length; i++){
			
			createKnights(castleAry[i]);
		}
		}
		else{
			for(int i=0; i<castleAry.length; i++){
			
				createPeasants(castleAry[i]);
			}
		}
	}
	public void movePeasant(){
		IPeasant[] peasants = getPeasants();
		//int ran = rand.nextInt(2);
		/*
		System.err.println("testing");
		for(int j=0; j<peasants.length; j++){
			System.err.println(peasants[j]);
		}
		*/
		
		for(int i=0; i<peasants.length; i++){
			move(peasants[i], findBestSpot(peasants[i]));
		}
		
		//move(peasants[0], 2);
			
	}
	public int findBestSpot(IPeasant p){
		int pos = rand.nextInt(8) + 1;
		Point np = World.getPositionAfterMove(p.getX(), p.getY(), pos);
		if(np!=null && World.getObjectAt(np.x, np.y)==null){		
			return pos;
		}
		
		for(int i=0; i<5; i++){
			np = World.getPositionAfterMove(p.getX(), p.getY(), i);
			if(np != null){
				IObject object = World.getObjectAt(np.x, np.y);
				if(object == null)	
					return i;						
			}
		}
		return rand.nextInt(8) + 1;
	}
	public void moveKnightFast(){
		IKnight[] knights = getKnights();
	}
	public void moveKnight(){
		
		//weakRuler = findWeakestRuler();
		//ICastle[] otherCastles = World.getOtherCastles();
		IKnight[] knights = getKnights();
		if(otherCastles[castleInd].getRuler().equals(knights[0].getRuler())){
			//castleInd++;
			otherCastles = World.getOtherCastles();
		}
		int numKnights = knights.length;
		/*
		if(numKnights < 20){
			ICastle c = getCastles()[0];
			int x = c.getX();
			int y = c.getY();
			for(int i=0; i<=numKnights/2; i++){
				moveTo(knights[i], x, y+i-5);
			}
			for(int i=0; i<=numKnights/2; i++){
				moveTo(knights[i], x+i-5, y);
			}
			
			return;
		}
		*/
		if(otherCastles.length >= 2){
		
		
		for(int i=0; i<numKnights/2; i++){
			moveAndCapture(knights[i], otherCastles[castleInd]);
		}
		for(int i=numKnights/2; i<numKnights; i++){
					moveAndCapture(knights[i], otherCastles[castleInd+1]);
		}
		}
		else if(otherCastles.length >=1 ){
			for(int i=0; i<numKnights; i++){
						moveAndCapture(knights[i], otherCastles[0]);
			}
		}
		else{
			for(int i=0; i<numKnights; i++){
				moveAndCapture(knights[i], getCastles()[0]);
			}
		}
		
		/*
		for(int i=numKnights/2+1; i< numKnights; i++){
			moveAndCapture(knights[i], otherCastles[0]);
		}
		for(int i=0; i<knights.length; i++){
			move(knights[i], rand.nextInt(8)+1);
		}
		*/
	}
	public void moveTo(IKnight knight, int x, int y){
		if(knightCapture(knight)){
			
		}
		else{
		if(knight.getX()==x && knight.getY()==y){
				return;
		}
		int dir = knight.getDirectionTo(x, y);
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if(np!=null){
			IObject obj = World.getObjectAt(np.x, np.y);
			if(obj==null){
				move(knight, dir);
			}
			else{
				move(knight, dir+2);
			}
			}
		}
		
	}
	public void moveAndCapture(IKnight knight, ICastle castle){
		if(castle==null){
			return;
		}
		int dir = knight.getDirectionTo(castle.getX(), castle.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if(np!=null){
			IObject obj = World.getObjectAt(np.x, np.y);
			if(obj==null){
				move(knight, dir);
			}
			/*
			else if(obj.equals(castle)){
				capture(knight, dir);
			}
			*/
			else if(obj.getRuler().equals(knight.getRuler())){
				int ran = rand.nextInt(2);
				int index=2;
				if(ran==0){	
					/*				
					while(obj!=null){
					
					Point p = World.getPositionAfterMove(knight.getX(), knight.getY(), dir+index);
					if(p!=null){
						obj = World.getObjectAt(p.x, p.y);
						
					}
					index++;
					}
					
					move(knight, dir+index-1);
					*/
					move(knight, dir+index);
				}
				else{		
					/*			
					while(obj!=null){
					
					Point p = World.getPositionAfterMove(knight.getX(), knight.getY(), dir-index);
					if(p!=null){
						obj = World.getObjectAt(p.x, p.y);
						
					}
					index++;
					}
					move(knight, dir-index+1);
					*/
					move(knight, dir-index);
				}
			}
			else{
				capture(knight, dir);
			}
		}
	}
	public boolean knightCapture(IKnight knight){
		for(int i=0; i<9; i++){
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			
			if(np != null){
				IObject object = World.getObjectAt(np.x, np.y);
				if(object != null && !object.getRuler().equals(knight.getRuler())){
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}		
}