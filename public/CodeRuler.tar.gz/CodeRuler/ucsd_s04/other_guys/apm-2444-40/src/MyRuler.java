import com.ibm.ruler.*;
import java.awt.Point;
import java.util.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	private int createCount = 0;
		
	protected Random rand = new Random();
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "KungFu Barbie";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 40";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		//System.out.println("getCount   " + getOwnedLandCount());
		//System.out.println("getCastles   " + getCastles());
		//System.out.println("getKnights   " + getKnights());
		//System.out.println("getPeasants  " + getPeasants());
		
		ICastle[] myCastle = getCastles();
		for (int i = 0; i < myCastle.length; i++)
		{
			createKnights(myCastle[i]);
			createPeasants(myCastle[i]);
			createKnights(myCastle[i]);
						createPeasants(myCastle[i]);
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		IKnight[] knights = getKnights();
		int size = knights.length;
		for (int i = 0; i < size; i++) {
			 int direction = knightBestMove(knights[i], knights[i].getX(), knights[i].getY());
			    
			   
				if (!knightCapture(knights[i]))
				{
					move(knights[i], direction);
				}
			}
			
		
		IPeasant[] peasants = getPeasants();
		size = peasants.length;
		
		for (int i = 0; i < size; i++) {
			//if (i%2 == 0)
					//move(peasants[i], peasantBestMove(peasants[i], peasants[i].getX(), peasants[i].getY()));
	//		else
					move(peasants[i], rand.nextInt(8) + 1);
				
		}
	}
	
	public boolean knightCapture(IKnight knight) {
		for (int j = 1; j < 9; j++)
		{	   
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), j);
			    
		    if (np != null) {
					  IObject object = World.getObjectAt(np.x, np.y);
					  if (object != null && !object.getRuler().equals(knight.getRuler()))
					  {
						   capture(knight, j);
						   return true;
     				   }
		    }
		}
				return false;
		
	}
	
	public int moveAndCapture(IKnight knight, IPeasant peasant, int direction) {
		if (peasant == null || ! peasant.isAlive())
			return direction;
		
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			if (peasant.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
		return dir;
	}
	
	public int knightBestMove(IKnight knight, int x, int y)
	{
		int direction = 0;
		
		ICastle[] iruler = World.getOtherCastles();
		
		
		if (iruler == null)
		{
			IPeasant[] peasants = World.getOtherPeasants();
			IPeasant p = peasants[rand.nextInt(peasants.length + 1) ];
			int OpX = p.getX();
			int OpY = p.getY();
			direction = knight.getDirectionTo(OpX, OpY);
			return moveAndCapture(knight, p, direction);
		}
		else
		{
			ICastle thisRuler = iruler[0];
			int OpX = thisRuler.getX();
			int OpY = thisRuler.getY();
			return knight.getDirectionTo(OpX, OpY);
		}
				
	}
	
	private int peasantBestMove(IPeasant p, int x, int y)
	{
		int direction = 0;
		
		if (x > 0 && x < 36 && y > 0 && y < 32)
		{
			if (y > 0) 
				direction = 1;
			else
				direction = 3;
		}
		if (x >= 36 && x < 72 && y > 0 && y < 32)
		{
			if (x <= 72)
				direction = 3;
			else
			direction = 5;
		}
		if (x >=36 && x < 72 && y >=32 && y < 64)
		{
			if (y < 64)
			direction =5;
			else
			direction =7;
		}
	    else if(x > 0 && x < 36 && y >=32 && y < 64)
	    {
	    	if (x > 0)
			direction =7;
	    	else
			direction =1;
	    }
		else
		direction =rand.nextInt(8) + 1;
		
		for (int i = 1; i < 8; i++)
		{
			
			
			int tempDir = direction;
			
			IRuler ruler = World.getLandOwner(x, y);
			if (ruler.equals(getRulerName()))
			{    
				for (int j = 0; j < 6; j++)
				{
					tempDir = tempDir + 1;
					if (tempDir > 8)
						tempDir = 1;
					Point np = World.getPositionAfterMove(x, y, tempDir);
					if (np != null) {
						IRuler tempRuler = World.getLandOwner(np.x, np.y);
						if (!tempRuler.equals(getRulerName()))
							return tempDir;
						
					}
				}
				return direction;
			}
			else
				return direction;
				
				 	
		}
		
		
		return direction;
	}
}