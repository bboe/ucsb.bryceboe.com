import com.ibm.ruler.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
import java.util.*;
import java.awt.Point;

public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	protected Random rand = new Random();
	public String getRulerName() {
		return "myLifeIsAJoke";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 58";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	private ICastle castle;
	private ICastle firstCastle;
	private int originalPeasantSize;
	private int[] peasantDirection;
	private int[][] convertDir = {{1,2,3},{8,0,4},{7,6,5}};
	public void initialize() {
		firstCastle = getCastles()[0];
		castle = getNearestCastle();
		originalPeasantSize = getPeasants().length;
		peasantDirection = peasantInitialize();
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	private IKnight[] knights;
	public void orderSubjects(int lastMoveTime) {
		//create new knights and peasants
		create();
		
		//knights, move to nearest castle		
		knights = getKnights();
		int size = knights.length;
		for (int i = 0; i < size; i++) {
				if( knights[i].getStrength() > 30 ) {
					if( castle != null )				
						moveAndCaptureCastle( knights[i] );
					else 
						moveAndCapture( knights[i] );
				} else {
					if( kdodge( knights[i] ) ) {
					} else {
						moveAndCapture(knights[i]);
					}
				}
		}	
		
		//peasant
		IPeasant[] peasants = getPeasants();
		size = peasants.length;
		for (int i = 0; i < size; i++) {
			if( pdodge(peasants[i]) ) {
			} else {
			  evenSmarterPeasantMove(peasants[i], i);
			}
		}
	}
	public boolean isSelfKnight(Object o) {
		IKnight k = null;
		try {
			k = (IKnight)o;
		} catch (Exception e) {
			return false;
		}
		for (int i=0; i<knights.length; i++) {
			if (knights.equals(k)) {
				return true;
			}
		}
		return false; 
	}
	public boolean kdodge( IKnight k ) {
		IObject o;
		for( int i=-1; i<1; i++) {
			for( int j=-1; j<1; j++) {
				if (i==0 && j==0) {
				} else {
					o = World.getObjectAt(k.getX()+i, k.getY()+j);
					if( o!=null && (o instanceof IKnight && !isSelfKnight(o))) {
						move(k, convertDir[i+1][j+1]);
						return true;
					}
				}
			}
		}
		return false;
	}
	public boolean pdodge( IPeasant k) {
		IObject o;
		for( int i=-1; i<1; i++) {
			for( int j=-1; j<1; j++) {
			if (i==0 && j==0) {
			} else {
				o = World.getObjectAt(k.getX()+i, k.getY()+j);
				if( o!=null && (o instanceof IKnight && !isSelfKnight(o))) {
					move(k, convertDir[i+1][j+1]);
					return true;
				}
			}
		}
		return false;
	}
return false;
	}
	public void moveAndCaptureCastle(IKnight k) {
		int direction = k.getDirectionTo( castle.getX(), castle.getY());
		Point np = World.getPositionAfterMove(k.getX(), k.getY(), direction);
		if( np==null) {
			if( direction<=4)
				move( k, direction+4);
			else
				move( k, direction-4);
		} else if( castle.equals(World.getObjectAt(np.x, np.y))  ) {
			capture(k, direction);
			firstCastle = castle;
			castle = getNearestCastle();	
		} else if( World.getObjectAt(np.x, np.y) != null) {
			capture(k, direction);
		} else {
			move(k,direction);
		}
	}
	public void moveAndCapture(IKnight k) {
		IObject o;
		for( int i=-1; i<1; i++) {
			for( int j=-1; j<1; j++) {
				if (i==0 && j==0) {
				} else {
					o = World.getObjectAt(k.getX()+i, k.getY()+j);
					if( o!=null && (o instanceof IKnight && !isSelfKnight(o))) {
						capture(k, convertDir[i+1][j+1]);
						return;
					}
				}
			}
		}
		attackOthers(k);
	}

	public void attackOthers(IKnight k) {
		IObject target = getNearestOtherKnight(k);
		if (target == null) {
			move(k, rand.nextInt(8)+1);
		} else {
			move(k,k.getDirectionTo(target.getX(), target.getY()));
		}
	}
	public IObject getNearestOtherKnight(IKnight k) {
			IKnight others[] = World.getOtherKnights();
			IPeasant otherp[] = World.getOtherPeasants();
			IObject target = null;
			int min=100;
			int temp=100;
			int tempp=100;
			int x,y;
			for (int i=0; i<others.length && i<20 && i<otherp.length; i++) {
				temp = k.getDistanceTo(others[i].getX(), others[i].getY());
				tempp = k.getDistanceTo(otherp[i].getX(), otherp[i].getY());
				if (temp>tempp) {
					if (min > tempp) {
						min = tempp;
						target = otherp[i];
					}
				}
				if (min > temp) {
					min = temp;
					target = others[i];
				}				
			}
			return target;
	}
	public IObject getNearestOtherKnightV(IKnight k) {
				IKnight others[] = World.getOtherKnights();
				IObject target = null;
				int min=100;
				int temp=100;
				int x,y;
				for (int i=0; i<others.length && i<50; i++) {
					temp = k.getDistanceTo(others[i].getX(), others[i].getY());
					if (min > temp) {
						min = temp;
						target = others[i];
					}				
				}
				return target;
		}
		
	public void escape(IKnight k) {
	}

	public ICastle getNearestCastle() {
		ICastle c[] = World.getOtherCastles();
		ICastle target = null;
		int min=100;
		int temp;
		int x,y;
		for (int i=0; i<c.length; i++) {
			temp = firstCastle.getDistanceTo(c[i].getX(), c[i].getY());
			if (min > temp) {
				min = temp;
				target = c[i];
			}				
		}
		return target;
	}

	public int[] peasantInitialize() {
		int[] peasantDirection = new int[originalPeasantSize];
		for (int i=0; i<getPeasants().length; i++) {
			peasantDirection[i] = rand.nextInt(8)+1;
		}
		return peasantDirection;
	}
	public void peasantMove(IPeasant p, int i) {
		int dir = 1; 
		if (World.getCurrentTurn()%100 < 20) {
			dir = peasantDirection[i%originalPeasantSize];
		} else if (World.getCurrentTurn()%100 < 50) {
			dir = peasantDirection[i%originalPeasantSize] + 1;
		} else if (World.getCurrentTurn()%100 < 75){
			dir = peasantDirection[i%originalPeasantSize] + 2;
		} else {	
			dir = peasantDirection[i%originalPeasantSize] + 3;
		}
		//too much to the left
		if ( p.getX() < 1) {
			dir = 3;
		//too much to the up
		} else if (  p.getY() < 1) {
			dir = 6;
		//too much to the right
		} else if (  p.getX() > 70 ) {
			dir = 7;
		//too much to the down
		} else if (  p.getY() > 62) {
			dir = 3;
		}		
			move(p,dir);
		//move(p, rand.nextInt(8) + 1);

	}
	
	public void evenSmarterPeasantMove(IPeasant p, int j) {
		for( int i=1; i<9; i++) {
			Point np = World.getPositionAfterMove(p.getX(), p.getY(), i);
			if( np==null) {
				if( i<=4 ) {
					move( p, i+4);
					return;
				}
				else {
					move( p, i-4 );
					return;
				}
			}
			if( World.getLandOwner(np.x, np.y)!=this ) {
				move(p, i);
				return;
			}
		}
		smarterPeasantMove(p, j);
	}
	
	public void smarterPeasantMove(IPeasant p, int i) {
		int dir = 1; 
		if (World.getCurrentTurn()%100 < 50) {
			dir = (peasantDirection[i%originalPeasantSize])%9;
		} else if (World.getCurrentTurn()%100 < 100) {
			dir = (peasantDirection[i%originalPeasantSize] + 2)%9;
		} else if (World.getCurrentTurn()%100 < 150){
			dir = (peasantDirection[i%originalPeasantSize] + 4)%9;
		} else {	
			dir = (peasantDirection[i%originalPeasantSize] + 6)%9;
		}
		//too much to the left
		if ( p.getX() < 1) {
			dir = 3;
		//too much to the up
		} else if (  p.getY() < 1) {
			dir = 6;
		//too much to the right
		} else if (  p.getX() > 70 ) {
			dir = 7;
		//too much to the down
		} else if (  p.getY() > 62) {
			dir = 3;
		}		
		
		Point np = World.getPositionAfterMove(p.getX(), p.getY(), dir);
		if (np == null) {
			move(p, dir);
			return;
		}
		Object o = World.getLandOwner(np.x, np.y);
		if (o == null || o != this) {
			move(p, dir);
		} else {
			move(p, rand.nextInt(8)+1);				 
		}
	}
	
	static boolean switchCreate = false;
	public void create() {
		ICastle c[] = getCastles();
		for (int i=0; i<c.length; i++) {
			if (switchCreate || castle == null) {
				createPeasants(c[i]);
				switchCreate = false;
			} else {
				createKnights(c[i]);
				switchCreate = true;
			}
		}
	}
}