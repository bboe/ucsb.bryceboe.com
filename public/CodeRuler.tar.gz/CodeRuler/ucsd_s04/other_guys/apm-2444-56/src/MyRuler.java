import com.ibm.ruler.*;
import java.util.*;
// import java.awt.geom.Point2D;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	int startx, starty;
	Random rand = new Random();
	TreeSet positions = new TreeSet();
	IPeasant [] p;
	IKnight [] k;
	ICastle [] c;
	IPeasant [] op;
	IKnight [] ok;
	ICastle[] oc; 
	
	
	
	//Peasants tree map
	TreeMap tm = new TreeMap();
	
	
	public String getRulerName() {
		return "WrathOfGod";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team56";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		p = getPeasants();
		k = getKnights();
		c = getCastles();
		op = World.getOtherPeasants();
		ok = World.getOtherKnights();
		oc = World.getOtherCastles();
		
		int dir1, dir2, dir3;	
		
		startx = c[0].getX();
		starty = c[0].getY();
		
		for( int i = 0; i < p.length; i++ ) {
			int move = getMove( p[i] );
			tm.put( new Integer( p[i].getId() ), new Integer( move ) );
		}
			

		// if ((startx < 24)
		for( int i = 0; i < k.length; i++ ) {
			// positions.add( new Point2D( k[i].getX(), k[i].getY()) );
			//System.out.println( "Initialization" );
		}
		// put implementation here
	}
	
	private int getMove( IPeasant p ) {
		int move = rand.nextInt( 8 )  + 1;				
		return move;
	}
	
	
	private int checkMove( IPeasant p, int m ) {
		int move = m;
		
		
		java.awt.Point point = World.getPositionAfterMove( p.getX(), p.getY(), m );
		
		for( int i = 0; i < 20; i++ ) {
			if( point != null ) //) && !World.getLandOwner( (int)Math.round( point.getX() ), (int)Math.round(point.getY()) ).equals( this ) ) 
			  return m;
			move = getMove( p );
			point = World.getPositionAfterMove( p.getX(), p.getY(), m );
		}
		
	/*
		startx = c[0].getX();
		starty = c[0].getY();
		
		int x = p.getX();
		int y = p.getY();
			
		if( x < startx && y < starty )
			move = 8;
		else
		if( x < startx && y == starty )
			move = 7;
		else
		if( x < startx && y > starty )
			move = 6;
		else
		if( x > startx && y < starty )
			move = 2;
		else
		if( x > startx && y == starty )
			move = 3;
		else
		if( x > startx && y > starty )
			move = 4;
		else
		if( x == startx && y < starty )
			move = 1;
		else
		if( x == startx && y > starty )
			move = 5;	*/
				
		return move;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		IPeasant[] peasant = getPeasants();
	 	ICastle enemy = null;
	 	IPeasant ep = null;
	 	IObject d = null;
	 	c = getCastles();
	 	
		for (int i = 0; i < c.length; i++) {
			createPeasants (c[i]);		 	
		}
		
	 	// Peasants moves
	 	for( int i = 0; i < peasant.length; i++ ) {
	 		Integer temp = new Integer( peasant[i].getId() );
	 		int pmove;
	 		if( tm.containsKey( temp ) ) {
	 			pmove = ((Integer)tm.get( temp )).intValue();
	 		}
	 		else {
	 			Integer m = new Integer( getMove( peasant[i] ) );
	 			pmove = m.intValue();
	 			tm.put( new Integer( peasant[i].getId() ), m );
	 		}
	 		pmove = checkMove( peasant[i], pmove );
	 		tm.put( new Integer( peasant[i].getId() ), new Integer( pmove ));
	 		move( peasant[i], pmove );
	 		// System.out.println( "Move " + pmove );
	 	}
	 	
	 	
	 	
		// ICastle[] c = getCastles();
		for (int i = 0; i < oc.length; i++) {
			if (!oc[i].getRuler().equals(this)) 
				 enemy = oc[i];
		}
		
		for (int i = 0; i < op.length; i++) {
			if (!op[i].getRuler().equals(this)) 
				 ep = op[i];
		}	
	    
		for( int i = 0; i < k.length; i++ ) {
			if (!k[i].isAlive())
				continue;
				
										/* attacking castles */
			if ((i < 5)&& (enemy != null)){
				if (((d = findEnemy (k[i], k[i].getX(), k[i].getY())) != null)) {
					if (d instanceof ICastle) {
						System.out.println("capturing castle");
						capture(k[i], k[i].getDirectionTo(d.getX(), d.getY()));
						continue;
					}
					else if (enemy != null) {
					
					    move( k[i], k[i].getDirectionTo( enemy.getX(), enemy.getY()) );
						continue;
					}
				}

				else if (enemy != null) 
					move( k[i], k[i].getDirectionTo( enemy.getX(), enemy.getY()) );
			}
						/* defenders */
				/*		
			else if (i < 7) {
				if (((d = findEnemy (k[i], k[i].getX(), k[i].getY())) != null)) {
					if (d instanceof ICastle) {
	
						capture(k[i], k[i].getDirectionTo(d.getX(), d.getY()));
					}
					else if (enemy != null) 
						move( k[i], k[i].getDirectionTo( enemy.getX(), enemy.getY()) );
				
		
			}		
			*/
			else {
				if (((d = findEnemy (k[i], k[i].getX(), k[i].getY())) != null)) {
					if (d instanceof IPeasant) {
	
						capture(k[i], k[i].getDirectionTo(d.getX(), d.getY()));
					}
					else if (ep != null) 
						move( k[i], k[i].getDirectionTo( ep.getX(), ep.getY()) );
				
				}	
				else if (ep != null)
					move( k[i], k[i].getDirectionTo( ep.getX(), ep.getY()) );
				else 
					move(k[i], rand.nextInt(8) + 1);	
			}	
			
		}
	/*	
		for (int i = 0; i < p.length; i++) {
			if (!p[i].isAlive())
				continue;
				
			move (p[i], rand.nextInt(8) + 1);	
		}	
     */
	}
	
	public IObject findEnemy (IObject me, int x, int y) {
		
		IObject thing = null;
		
		for (int i = x - 1; i <= x + 1; i++) {
			for (int j = y - 1; j <= y + 1; j++) {
				if (i > 0 && j > 0 && i < 72 && j < 64) {
					thing = World.getObjectAt(i, j);
					if (thing != null) {
						if (!thing.getRuler().equals(me.getRuler()))
							return (thing);
					}		
				}
			}	
				
		}
		return null;
	} 
		 
} 
