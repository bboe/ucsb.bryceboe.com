import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	protected IKnight[] myKnights;
	protected IPeasant[] myPeas;
	protected Random rand = new Random();
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "TheWallpapers";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "TEAM 29";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		myKnights = getKnights();
		myPeas = getPeasants();
		createPeasants( this.getCastles()[0] );
		//createKnights( this.getCastles()[0]);
	}
	
	public void setPeasAndKnights()
	{
			myPeas = getPeasants();
			myKnights = getKnights();
			
	}
	
	public void peasantMove()
	{
		int i, x, y;
		boolean moved = false;
		for( i = 0 ; i < myPeas.length; i ++ )
		{
			x = myPeas[i].getX();
			y = myPeas[i].getY();
			moved = false;
			for( int j = 1 ; j < 9 ; j++ )
			{
				//move( myPeas[i], bestMove( myPeas[i] ))
				Point np = World.getPositionAfterMove( x, y, j);
				if( np != null )
				{
					// if land in jth direction is not yours
					if( World.getLandOwner( np.x, np.y ) != this )
					{
					   if( World.getObjectAt( np.x, np.y) == null )
					   {
					   		move( myPeas[i], j);
							moved = true;
					   }
					   else
					   {
					   		move( myPeas[i], (j + 2) %8 +1);	
					   }
					}
					
				}
			}
			if( !moved )
			{
				int pos = bestMove( myPeas[i] );
				Point np = World.getPositionAfterMove( x, y, pos); 
				if( np != null )
				{
					if( World.getObjectAt( np.x, np.y) != null )
				
					{
						move( myPeas[i], (pos +2) %8 +1);
					}
					else
					{	
						move( myPeas[i], pos );
					}
				}
				else
				{
					move( myPeas[i], pos );	
				}
			}		
			
			
								
						
						
					
		}
	}
	
	public int bestMove( IObject me )
	{
		int x = me.getX();
		int y = me.getY();
		if( x < 36 && y < 32 )
		{
			return 3;
		}
		else if( x > 36 && y < 32 )
		{
			return 5;
		}
		else if( x > 36 && y > 32 )
		{
			return 7;
		}
		return 1;
			
	}	
	
	public ICastle getClosestCastle( IObject me )
	{
		ICastle[] current = World.getOtherCastles();
		if( current == null)
		{
			return null;
		}
		if( current.length == 0 )
		{
				return null;
		}
		ICastle shortest = current[0];
		for( int i = 0 ; i < current.length ; i ++ )
		{
			if( me.getDistanceTo( current[i].getX(), current[i].getY()) < me.getDistanceTo( shortest.getX(), shortest.getY()) )
			{
				shortest = current[i];
			}
			
		}
		return shortest;
	}
	
	
	public void knightMove()
		{
			int i, x, y;
			ICastle c;
			//Loop through the knights
			for( i = 0 ; i < myKnights.length; i ++ )
			{
				x = myKnights[i].getX();
				y = myKnights[i].getY();
				
				
				//Loop through directions
				for( int j = 1 ; j < 9 ; j++ )
				{
					
					
					Point np = World.getPositionAfterMove( x, y, j );
					if( np != null )
					{
						IObject o = World.getObjectAt( np.x, np.y);
						if(  o != null )
						{
							if( !o.getRuler().equals( myKnights[i].getRuler() ) )
							{
								capture( myKnights[i], j);
								return;
							}
						
						}
					}
				}			
				c = this.getClosestCastle( myKnights[i]);
				if( c==null)
				{
					moveToObject( myKnights[i]);
					continue;
				}
				
				
				move( myKnights[i], myKnights[i].getDirectionTo( c.getX(), c.getY()));
							
			}
		}
		
		
	public void moveToObject( IKnight me )
	{
		int x = me.getX();
		int y = me.getY();
		int xThem, yThem;
		IObject[] them = World.getOtherKnights();
		boolean moved = false;
		//System.out.println( "going to object");
		if( them.length != 0 )
		{
			IObject current = them[0];
			for( int i = 0 ; i < them.length ; i++ )
			{
			 	xThem = them[i].getX();
			 	yThem = them[i].getY();
			 	if( me.getDistanceTo( xThem, yThem) < me.getDistanceTo( current.getX(), current.getY() ))
			 	{
			 		current = them[i];
			 	}
			}
			Point np = World.getPositionAfterMove( x, y, me.getDirectionTo(current.getX(), current.getY() ) );
			if( np != null )
			{
				IObject o = World.getObjectAt( np.x, np.y);
				if(  o != null )
				{
					if( !o.getRuler().equals( me.getRuler() ) )
					{
						capture( me, me.getDirectionTo( o.getX(), o.getY()));
						return;
					}
					else
					{
						move( me, (me.getDirectionTo( current.getX(), current.getY()) +2) % 8 + 1);
						moved = true;
					}	
				}
			}
			
			if( !moved )
				move( me, me.getDirectionTo( current.getX(), current.getY()));
		}	
		them = World.getOtherPeasants();
		moved = false;
		//System.out.println( "going to object");
		if( them.length != 0 )
		{
			IObject current = them[0];
			for( int i = 0 ; i < them.length ; i++ )
			{
				xThem = them[i].getX();
				yThem = them[i].getY();
				if( me.getDistanceTo( xThem, yThem) < me.getDistanceTo( current.getX(), current.getY() ))
				{
					current = them[i];
				}
			}
			Point np = World.getPositionAfterMove( x, y, me.getDirectionTo(current.getX(), current.getY() ) );
			if( np != null )
			{
				IObject o = World.getObjectAt( np.x, np.y);
				if(  o != null )
				{
					if( !o.getRuler().equals( me.getRuler() ) )
					{
						capture( me, me.getDirectionTo( o.getX(), o.getY()));
						return;
					}
					else
					{
						move( me, (me.getDirectionTo( current.getX(), current.getY()) +2) % 8 + 1);
						moved = true;
					}	
				}
			}
		
			if( !moved )
				move( me, me.getDirectionTo( current.getX(), current.getY()));
			}
	}
	
	public void defend()
	{
		int i;
		if( this.getCastles().length == 0 )
		{
			knightMove();
			return;
		}
		for( i = 0 ; i < myKnights.length ; i++)
		{
			int x = myKnights[i].getX();
			int y = myKnights[i].getY();
			IKnight me = myKnights[i];
			for( int j = 0 ; j < 9 ; j++)
			{
				Point np = World.getPositionAfterMove( x, y, j);
				if( np != null )
				{
					IObject o = World.getObjectAt( np.x, np.y ); 
					if( o != null && !o.getRuler().equals( me.getRuler()))
					{
						capture( me, j);
					}
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		
		myPeas = getPeasants();
		myKnights = getKnights();
		int i;
		if( this.getOwnedLandCount() < 500 && myPeas.length > 20)
		{
			ICastle[] c = getCastles();
			for( i = 0 ; i < c.length ; i++)
			{
			
				if( myKnights.length < 20 )
				{
					createKnights(c[i]);
				}
				else
				{
					createPeasants(c[i]);
				}  
			}
			peasantMove();
			defend();
			return;
		}	
		
		if( myKnights.length < 25 )
		{
			ICastle[] c = getCastles();
			for( i = 0 ; i < c.length ; i++ )
			{
				createKnights(c[i]);
			}
		}
		else
		{
			ICastle[] c = getCastles();
			for( i = 0 ; i < c.length ; i++)
			{
				createPeasants(c[i]);
			}
		}
		
		knightMove();
		peasantMove();
		
		
	}
}