import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	private int turn; 
	private int loc=0;
	private boolean goS=true;
	private boolean goN=true;
	private boolean goE=true;
	private boolean goW=true;
	IKnight[] otherK;
	IPeasant[] otherP;
	ICastle[] otherC;
	int sem = 1;
	public String getRulerName() {
		return "KILLJOY";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 38";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		turn = 0;
		int initX;
		int initY;
		initX=getCastles()[0].getX();
		initY=getCastles()[0].getY();
				
		if( initX>18 &&initX<46 && initY>0 && initY<20)
		{
			goE=true;
			loc=2;
		}
		else if( initX>0 &&initX<21 && initY>5 && initY<32)
		{loc = 1;goS=true; } 
		else if( initX>48 &&initX<72 && initY>13 && initY<28)
		{	loc = 3;goS=true; } 
		else if( initX>50 &&initX<72 && initY>32 && initY<48)
		{	loc=4;goN=true;} 
		else if( initX>30 &&initX<72 && initY>48 && initY<64)
			{goW=true; loc = 5;} 
		else
			{goW=true; loc = 6;} 
		
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		Random rand = new Random();
		turn++;
		if ( turn % 2 == 0)
			 sem = rand.nextInt(8) + 1;
		
		otherK = World.getOtherKnights();
		otherP = World.getOtherPeasants();
		otherC = World.getOtherCastles();
		ICastle[] castles = getCastles();
		IKnight[] knights = getKnights();		
		IPeasant[] peasants = getPeasants();			
		int numPeasants = peasants.length;
		int numKnights = knights.length;
		for( int u = 0; u < castles.length - 1; u++ ){
		
			createPeasants(castles[u]);
			createKnights(castles[u]);
		}
		for ( int k = 0; k < numPeasants - 1; k++ ){
			
			move(peasants[k], sem );
		}
		System.out.println("LOCATION"+ loc);
		if( loc == 1)
		{
			if( goS)
			goSouth(knights, peasants, numKnights, numPeasants);
			else if(goE)
			goEast(knights, peasants, numKnights, numPeasants);
			else if(goN)
			goNorth(knights, peasants, numKnights, numPeasants);
			else if(goW)
			goWest(knights, peasants, numKnights, numPeasants);
			else
			{
			
			//goRandom(knights, numKnights, rand);
			 goS=true;
			goN=true;
			goE=true;
			goW=true;
			}
		}
		else if(loc == 2)			
		{
			if( goE)
			goEast(knights, peasants, numKnights, numPeasants);
			else if(goS)
			goSouth(knights, peasants, numKnights, numPeasants);
			else if(goW)
			goWest(knights, peasants, numKnights, numPeasants);
			else if(goN)
			goNorth(knights, peasants, numKnights, numPeasants);
			else
			{
			
		//	goRandom(knights, numKnights, rand);
			 goS=true;
			goN=true;
			goE=true;
			goW=true;
			}
		}
		else if(loc == 3)			
		{
			if( goS)
			goSouth(knights, peasants, numKnights, numPeasants);
			else if(goW)
			goWest(knights, peasants, numKnights, numPeasants);
			else if(goN)
			goNorth(knights, peasants, numKnights, numPeasants);
			else if(goE)
			goEast(knights, peasants, numKnights, numPeasants);
			else
			{
			
		//	goRandom(knights, numKnights, rand);
			 goS=true;
			goN=true;
			goE=true;
			goW=true;
			}
		}
		else if(loc == 4)			
		{
			if( goN)
			goNorth(knights, peasants, numKnights, numPeasants);
			else if(goE)
			goEast(knights, peasants, numKnights, numPeasants);
			else if(goW)
			goWest(knights, peasants, numKnights, numPeasants);
			else if(goS)
			goSouth(knights, peasants, numKnights, numPeasants);
			else
			{
			
		//	goRandom(knights, numKnights, rand);
			 goS=true;
			goN=true;
			goE=true;
			goW=true;
			}
		}
		else if(loc == 5)			
		{
			if( goW)
			goWest(knights, peasants, numKnights, numPeasants);
			else if(goN)
			goNorth(knights, peasants, numKnights, numPeasants);
			else if(goE)
			goEast(knights, peasants, numKnights, numPeasants);
			else if(goS)
			goSouth(knights, peasants, numKnights, numPeasants);
			else
			{
			
			
			 goS=true;
			goN=true;
			goE=true;
			goW=true;
			}
		}
		else 			
		{
			if( goN)
			goNorth(knights, peasants, numKnights, numPeasants);
			else if(goE)
			goEast(knights, peasants, numKnights, numPeasants);
			else if(goS)
			goSouth(knights, peasants, numKnights, numPeasants);
			else if(goW)
			goWest(knights, peasants, numKnights, numPeasants);
			else
			{
			
		//	goRandom(knights, numKnights, rand);
			 goS=true;
			goN=true;
			goE=true;
			goW=true;
			}
		}	
			
			
	}
	
	void
	goSouth(IKnight []knights, IPeasant[]peasants, int numKnights, int numPeasants)
	{
		
		for(int i=0; i<(numKnights-1);i++)
		{
			if( knights[i].getY() < 56 )
			{
		      if(knightCapture(knights[i]) == false)
		      	move(knights[i], 5);	 
		     /* for( int pi = 0; pi < otherK.length - 1; pi++ )
		        moveAndCapture(knights[i], otherK[pi], 5);
			      	
			  for( int si = 0; si < otherP.length - 1; si++ )
				moveAndCapture(knights[i], otherP[si], 5);
			  for( int vi = 1; vi < otherC.length - 1; vi++ )
								moveAndCapture(knights[i], otherC[vi], 5);	
				  */
			}
		 	else
		 		goS=false;		
		}
		
		
		
	}
	
	void
	goNorth(IKnight []knights, IPeasant[]peasants, int numKnights, int numPeasants)
	{
		
		for(int i=0; i<(numKnights-1);i++)
		{
			if( knights[i].getY() > 10 )
			{
				if(knightCapture(knights[i]) == false)
								move(knights[i], 1);	 /*
				 for( int pi = 0; pi < otherK.length - 1; pi++ )
					moveAndCapture(knights[i], otherK[pi], 1);
			      	
				  for( int si = 0; si < otherP.length - 1; si++ )
						moveAndCapture(knights[i], otherP[si], 1);
				for( int vi = 1; vi < otherC.length - 1; vi++ )
												moveAndCapture(knights[i], otherC[vi], 1);			
				  */
			}			
			else
				goN=false;		
		}
		
			
	}
	
	void
	goWest(IKnight []knights, IPeasant[]peasants, int numKnights, int numPeasants)
	{
		
		for(int i=0; i<(numKnights-1);i++)
		{
			if( knights[i].getX() > 10 )
			{
				if(knightCapture(knights[i]) == false)
								move(knights[i], 7);	 /*
				for( int pi = 0; pi < otherK.length - 1; pi++ )
								   moveAndCapture(knights[i], otherK[pi], 7);
			      	
								 for( int si = 0; si < otherP.length - 1; si++ )
									   moveAndCapture(knights[i], otherP[si], 7);
				for( int vi = 1; vi < otherC.length - 1; vi++ )
												moveAndCapture(knights[i], otherC[vi], 7);	
			*/}
			
			else
				goW=false;		
		}
		
	}
	
	void
	goEast(IKnight []knights, IPeasant[]peasants, int numKnights, int numPeasants)
	{
		
		for(int i=0; i<(numKnights-1);i++)
		{
			if( knights[i].getX() < 65 )
			{
				if(knightCapture(knights[i]) == false)
								move(knights[i], 3);	
								/* 
				for( int pi = 0; pi < otherK.length - 1; pi++ )
								   moveAndCapture(knights[i], otherK[pi], 3);
			      	
								 for( int si = 0; si < otherP.length - 1; si++ )
									   moveAndCapture(knights[i], otherP[si], 3);
				for( int vi = 1; vi < otherC.length - 1; vi++ )
												moveAndCapture(knights[i], otherC[vi], 3);	*/
			}
		else
				goE=false;		
		}
						
	}
/*	void moveAndCapture(IKnight knight, IPeasant peasant, int d){
		if(peasant == null || !peasant.isAlive())
		  return;
		 int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		 Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		 if( np != null){
		 	if(peasant.equals(World.getObjectAt(np.x, np.y)))
		 		capture(knight,dir);
		 	else	
		 	    move(knight, d);
		 }	    
		 	 
	}
	void moveAndCapture(IKnight knight, IKnight k, int d){
			if(k == null || !k.isAlive())
			  return;
			 int dir = knight.getDirectionTo(k.getX(), k.getY());
			 Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
			 if( np != null){
				if(k.equals(World.getObjectAt(np.x, np.y)))
					capture(knight,dir);
				else	
					move(knight, d);
			 }		
		 	 
	}
	void moveAndCapture(IKnight knight, ICastle k, int d){
				if(k == null || !k.isAlive())
				  return;
				 int dir = knight.getDirectionTo(k.getX(), k.getY());
				 Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
				 if( np != null){
					if(k.equals(World.getObjectAt(np.x, np.y)))
						capture(knight,dir);
					else	
						move(knight, d);
		 	 
				 }	
	}*/
	boolean knightCapture( IKnight knight){
		for( int i = 0; i < 9; i++){
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(),i);
			if( np != null){
				IObject object = World.getObjectAt(np.x, np.y);
				if( object != null && !object.getRuler().equals(knight.getRuler())){
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}
	void goRandom( IKnight[] knights, int numKnights, Random rand){
		for( int i = 0; i < (numKnights - 1); i++)
			move(knights[i], sem );
	}
	
}