import com.ibm.ruler.*;
import java.util.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "HAPKOMAH";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 11";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) 
	{
		Random rand = new Random();
		int direction=0;
		int counter=0;
		
		ICastle myCastle[]=getCastles();
		IPeasant myPeasant[]=getPeasants();
		IKnight myKnight[];
		
		int X = myCastle[0].getX();

		myKnight=getKnights();
		for (int i=0; i<myKnight.length; i++)
		{
			direction=rand.nextInt(8)+1;
			move(myKnight[i],direction);
		}
		
		for (int i=0; i<myPeasant.length; i++)
		{
			//direction=rand.nextInt(8)+1;
			//World.getPositionAfterMove(myPeasant[i].getX(),myPeasant[i].getY(),direction);
			while(World.getObjectAt(myPeasant[i].getX(),myPeasant[i].getY())!=null)
				{
					direction=rand.nextInt(8)+1;
					World.getPositionAfterMove(myPeasant[i].getX(),myPeasant[i].getY(),direction);
					counter++;
					if (counter>8)
						break;
				}
				if (counter!=0)
					move(myPeasant[i],direction);
				
		
		}	
	}
	
	private void moveKnights()
		{
			
		}

	
}