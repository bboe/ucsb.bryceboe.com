import com.ibm.ruler.*;
import java.util.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "HAPKOMAH"; 
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 11";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) 
	{
		Random rand = new Random();
		int direction=0;
		int counter=1;
		int pMoveX=0;
		int pMoveY=0;
		
		ICastle myCastle[]=getCastles();
		IPeasant myPeasant[]=getPeasants();
		IKnight myKnight[];
		
		
		createPeasants(myCastle[0]);
		
		
		int X = myCastle[0].getX();

		myKnight=getKnights();
		for (int i=0; i<myKnight.length; i++)
		{
			moveKnight(myKnight[i],i);
		}
		
		for (int j=0; j<myPeasant.length; j++)
		{
			//direction=rand.nextInt(8)+1;
			//World.getPositionAfterMove(myPeasant[i].getX(),myPeasant[i].getY(),direction);
			direction=rand.nextInt((8))+1;
			pMoveX=World.getPositionAfterMove(myPeasant[j].getX(),myPeasant[j].getY(),direction).x;
			pMoveY=World.getPositionAfterMove(myPeasant[j].getX(),myPeasant[j].getY(),direction).y;
			while(World.getObjectAt(pMoveX,pMoveY)!=null)
				{
					pMoveX=World.getPositionAfterMove(myPeasant[j].getX(),myPeasant[j].getY(),direction).x;
					pMoveY=World.getPositionAfterMove(myPeasant[j].getX(),myPeasant[j].getY(),direction).y;
					
					direction=rand.nextInt((8))+1;
					//World.getPositionAfterMove(myPeasant[j].getX(),myPeasant[j].getY(),direction);
					counter++;
					if (counter>8)
						break;
				}
				move(myPeasant[j],direction);
				
		
		}	
	}
	
	private void moveKnight(IKnight myKnight,int kindex)
	{
		IKnight oKnights[];
		oKnights=World.getOtherKnights();
		ICastle oCastles[]=World.getOtherCastles();
		
		if(kindex<3)
		{
			move(myKnight,myKnight.getDirectionTo(oCastles[0].getX(),oCastles[0].getY()));
			myCapture(myKnight);
			return;
		}
		
		if (attackKnights(myKnight)==0)
		{
			/*move(myKnight,(kindex%8)+1);
			move(myKnight,(kindex%8)+1);
			move(myKnight,(kindex%8)+1);
			move(myKnight,(kindex%8)+1);
			*/
		}
		//for (int i=0;i<oKnights.length;i++)
		//{
			
		//}
	}
		
		
	private int attackKnights(IKnight myKnight)
		{
			IKnight oKnights[];
			oKnights=World.getOtherKnights();
			
			int oX=0;
			int oY=0;
			int distance=0;

			if (myCapture(myKnight)==0)
			{			
				for (int i=0;i<oKnights.length;i++)
				{
					oX=oKnights[i].getX();
					oY=oKnights[i].getY();	
					move(myKnight,myKnight.getDirectionTo(oX,oY));
				}		
				
					//else returns 1
			}
			return 0; //Diddn't do anything
		}
	
	private int myCapture(IKnight myKnight)
	{
		for (int k =0; k<9;k++)
		{
			int pMoveX=0;
			int pMoveY=0;
			
			pMoveX=World.getPositionAfterMove(myKnight.getX(),myKnight.getY(),k).x;
			pMoveY=World.getPositionAfterMove(myKnight.getX(),myKnight.getY(),k).y;
			if(World.getObjectAt(pMoveX,pMoveY)!=null)
			{
				capture(myKnight,k);
				return 1;
			}
		}
		return 0;
	}
	
}