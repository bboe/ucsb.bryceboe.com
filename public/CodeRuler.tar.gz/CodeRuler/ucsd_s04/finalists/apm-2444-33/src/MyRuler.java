import com.ibm.ruler.*;
import java.lang.Math;
import java.util.Random;
import java.util.Hashtable;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	 
	IObject[] mypeasants;
	IObject[] myknights;
	IObject[] mycastles;
	IObject[] otherpeasants;
	IObject[] otherknights;
	IObject[] othercastles;
	IRuler[] otherrulers;
	int[][] owners;
	int[] num_owned;
	
	Random rand;
	
	Hashtable peasDest;
	Hashtable knDest;
	
	
	//int epoch = 0;
	
	public String getRulerName() {
		return "the BURNINATOR";
	}
	

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 33";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		owners= new int[World.WIDTH][World.HEIGHT];
		rand = new Random();
		peasDest = new Hashtable();
		knDest = new Hashtable();
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		//System.out.println("Epoch: " + epoch++ + "  Last Move: " 
			//				+lastMoveTime);
		
		
		mypeasants = getPeasants();
		myknights = getKnights();
		mycastles = getCastles();

		othercastles = World.getOtherCastles();
		otherknights = World.getOtherKnights();
		otherrulers = World.getOtherRulers();
		otherpeasants = World.getOtherPeasants();

		fillOwners();
		int best = getBestRuler();
		
		for (int i =0; i < mycastles.length; i++) {
			
			if (mypeasants.length < 10 || myknights.length > 150 || i > 2)
				createPeasants((ICastle)mycastles[i]);
			else
				createKnights((ICastle)mycastles[i]);
		}
		
		for (int i = 0; i < myknights.length; i++) {

			int closestP = closestPeasant(myknights[i]);
			int closestK = closestKnight(myknights[i]);
			
			
			//System.out.println("===========================");
			
			if (othercastles.length > 0)
			{
				IObject castletarget = othercastles[getClosestCastle(myknights[i])];
				if (tryCapture(myknights[i])) {}
				else{
					IObject pe = myknights[i];
			
					Point p = null;
				
					if (knDest.containsKey(pe)) {
						p = (Point)knDest.get(pe);
						if ((p.x == pe.getX() && p.y == pe.getY())
						    || (World.getObjectAt(p.x, p.y).getRuler() == this)){
							knDest.remove(pe);
							p = new Point(
									castletarget.getX(), castletarget.getY());
							knDest.put(pe,p);
						}
					}
					else {
						p = new Point(
							castletarget.getX(), castletarget.getY());
						knDest.put(pe,p);
					}
			
					move((IKnight)pe, moveToward(pe,p.x,p.y));
				}
			
			}
			else{
				Point p = getClosest(myknights[i]);
				if (p != null)
				{
					if (tryCapture(myknights[i]))
					{}
					else {
						move((IKnight)myknights[i], 
						     moveToward(myknights[i], p.x, p.y));
					}
				}
			}
		}	
		
		for (int i = 0; i < mypeasants.length; i++) {
			IObject pe = mypeasants[i];
			
			Point p = null;
			if (tryEvade(pe)) {}
			else {	
				if (peasDest.containsKey(pe)) {
					p = (Point)peasDest.get(pe);
					if (p.x == pe.getX() && p.y == pe.getY()){
						peasDest.remove(pe);
						p = landTarget(pe,best);
						peasDest.put(pe,p);
					}
				}
				else {
					p = landTarget(pe,best);
					peasDest.put(pe,p);
				}
			
				move((IPeasant)pe, moveToward(pe,p.x,p.y));	
			} 
		}
		
		for (int i = 0; i < mycastles.length; i++) {
			makeCamp(mycastles[i],myknights.length/10);
			
		}
		for (int i = 0; i < myknights.length; i++){
			tryCapture(myknights[i]);
		}
		
	}
	
	public void fillOwners()
	{
		num_owned = new int[otherrulers.length];
		for (int i = 0; i < World.HEIGHT; i++) {
			for (int j = 0; j < World.WIDTH; j++){
				int o = getRuler(World.getLandOwner(j,i));
				owners[j][i] = o;
				if (o > -1) num_owned[o]++;
			}
		}
	}
	
	public int getBestRuler() {
		int max = 0;
		int best = 0;
		for (int i = 0; i < num_owned.length; i++) {
			if (max < num_owned[i]) {
				max = num_owned[i];
				best = i; 
			}
		}
		return best;
	}
	
	public int dirToLandTarget(IObject p, int best) {
		int x = 0, y = 0;
		for (int i = 0; i < 100; i++) {
			x = Math.abs(rand.nextInt()) % World.WIDTH;
			y = Math.abs(rand.nextInt()) % World.HEIGHT;
			if (getRuler(World.getLandOwner(x,y)) == best)
				return p.getDirectionTo(x,y);
		}
		return p.getDirectionTo(x,y);
		
	}
	
	public Point landTarget(IObject p, int best) {
			int x = 0, y = 0;
			for (int i = 0; i < 600; i++) {
				x = Math.abs(rand.nextInt()) % World.WIDTH;
				y = Math.abs(rand.nextInt()) % World.HEIGHT;
				if (getRuler(World.getLandOwner(x,y)) == best)
					return new Point(x,y);
			}
			return new Point(x,y);
		
	}
			
	int getRuler(IRuler R)
	{
		if (R == null)
		    return -2;
		for (int i = 0; i < otherrulers.length; i++)
		{
			if (otherrulers[i] == R)
			   return i;
		}
		
		return -1;
	}
	
	
	public int closestPeasant(IObject current)
	{
		int closest = 999999;
		int retval = 0;
		for (int i=0; i < otherpeasants.length; i++) {
			
			if (maxSquaresTo(current, otherpeasants[i])
			    < closest)
			    closest = maxSquaresTo(current, otherpeasants[i]);
				retval = i;
		}
		
		return retval;
			
	}
	
	public int getClosestCastle(IObject current)
	{
		int closest = 999999;
		int retval = 0;
		for (int i=0; i < othercastles.length; i++) {
			if (maxSquaresTo(current, othercastles[i])
				< closest)
				closest = maxSquaresTo(current, othercastles[i]);
				retval = i;
		}
		return retval;
	}
	
	public void makeCamp(IObject castle, int num) {
		for (int i = -15; i <= 15; i++) {
			for (int j = -15; j < 15; j++) {
				IObject sq = World.getObjectAt(
						castle.getX() + i,
						castle.getY() + j);
				if (sq != null && sq instanceof IKnight
						&& sq.getRuler() == this
						&& num-- > 0) {
					move((IKnight)sq,0);							
				}
			}
		}
	}
	
	public int closestKnight(IObject current)
	{
		int closest = 999999;
		int retval = 0;
		for (int i=0; i < otherknights.length; i++) {
			
			if (maxSquaresTo(current, otherknights[i])
				< closest)
				closest = maxSquaresTo(current, otherknights[i]);
				retval = i;
		}
		return retval;	
	}	
	
	public Point getClosest(IObject current)
	{
		Point close=null;
		int closest = 99999;
		
		for (int i =0; i<otherknights.length; i++) 
		{
			if (maxSquaresTo(current, otherknights[i])
					< closest){
					closest = maxSquaresTo(current, otherknights[i]);
					close = new Point(otherknights[i].getX(), otherknights[i].getY());
			}
		}
		
		for (int i =0; i < otherpeasants.length; i++) 
		{
			if (maxSquaresTo(current, otherpeasants[i])
				< closest)
			{
				closest = maxSquaresTo(current, otherpeasants[i]);
				close = new Point(otherpeasants[i].getX(), otherpeasants[i].getY());
			}
		}
		return close;
	}
	
	public boolean tryCapture (IObject knight ) {
		int x1 = knight.getX();
		int y1 = knight.getY();
		for (int x = -1; x < 2; x++) {
			for (int y = -1; y < 2; y++) {
				IObject o = World.getObjectAt(x1+x,y1+y);
				if ( o != null && o.getRuler() != this) {
					capture((IKnight)knight,
						moveToward(knight,x1+x, y1+y));
						return true;
				}
			}
		}
		return false;
	}
	
	public boolean tryEvade (IObject peasant ) {
		int x1 = peasant.getX();
		int y1 = peasant.getY();
		for (int x = -2; x < 3; x++) {
			for (int y = -2; y < 3; y++) {
				IObject o = World.getObjectAt(x1+x,y1+y);
				if ( o != null && o.getRuler() != this && o instanceof IKnight) {
					move((IPeasant)peasant,
						moveToward(peasant,x1-x, y1-y));
						return true;
				}
			}
		}
		return false;
	}
	
	
	
	public int maxSquaresTo(IObject current, IObject target) {
		return Math.max(Math.abs(current.getX()-target.getX()),
						Math.abs(current.getY()-target.getY()));
	}

	public int maxSquaresTo(IObject current, int x, int y) {
		return Math.max(Math.abs(current.getX()-x),
						Math.abs(current.getY()-y));
	}	
	
	public int moveToward(IObject current, IObject target) {
		
		int x = target.getX() - current.getX();
		int y = target.getY() - current.getY();
		
		if (x == 0  && y < 0) return 1;
		if (x <0 && y < 0) return 8;
		if (x > 0 && y < 0 ) return 2;
		if (x > 0 && y == 0) return 3;
		if (x > 0 && y > 0) return 4;
		if (x == 0 && y > 0) return 5;
		if (x < 0 && y > 0) return 6;
		if (x <0 && y == 0) return 7;
		return 1;
			
//		return current.getDirectionTo(target.getX(), target.getY());
	}
	
	public int moveToward(IObject current, int x, int y) {
		
		x = x - current.getX();
		y = y - current.getY();
	
		if (x == 0  && y < 0) return 1;
		if (x <0 && y < 0) return 8;
		if (x > 0 && y < 0 ) return 2;
		if (x > 0 && y == 0) return 3;
		if (x > 0 && y > 0) return 4;
		if (x == 0 && y > 0) return 5;	
		if (x < 0 && y > 0) return 6;
		if (x <0 && y == 0) return 7;
		return 1;
	}
	
}