
import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */

public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	 public static IKnight[] knights;
	 public static IPeasant[] peasants;
	 public static ICastle[] castle;
	 public static IKnight[] otherKnights;
	 public static IPeasant[] otherPeasants;
	 public static ICastle[] otherCastles;
	protected Random rand = new Random();
	public static int current =0;

	public String getRulerName() {
		return "Whatever v.2";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 1";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		 
		knights = getKnights();
		peasants = getPeasants();
		castle = getCastles();
		otherKnights = World.getOtherKnights();
		otherPeasants = World.getOtherPeasants();
		otherCastles = World.getOtherCastles();
			}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		current++;
		knights = getKnights();
		otherCastles = World.getOtherCastles();
		int closest = 0;
		/*for(int j = 0; j<knights.length; j++){
			if(knightCapture(knights[j]) == false){
				IObject close = closestObject(knights[j]);
				if(close != null){
				
				  if(knights[j].getDistanceTo(close.getX(),close.getY())< 15)
				    move(knights[j], knights[j].getDirectionTo(close.getX(), close.getY()));
				  else
				    knightMove(knights[j]);
			    }
			    else
				  move(knights[j], rand.nextInt(8) + 1); 
			}
			
			      
		}*/
		/*ICastle close=null ;
		for(int i =knights.length-1; i>=0;i--){
			if((closestCastle(knights[i]) != null))
			   close = closestCastle(knights[i]); 
		}
		for(int j = 0; j<knights.length; j++ ){
					if(knightCapture(knights[j]) == false){
						  move(knights[j], knights[j].getDirectionTo(close.getX(), close.getY()));
					}			
				}*/
		   
		for(int j = 0; j<knights.length; j++ ){
			if(knightCapture(knights[j]) == false){
				ICastle close = closestCastle(knights[j]);
				if(close != null)
				  move(knights[j], knights[j].getDirectionTo(close.getX(), close.getY()));
				else
				  knightMove(knights[j]);
				  //move(knights[j], rand.nextInt(8) + 1); 
			}			
		}
		
		/*for(int j = 0; j<knights.length; j++){
		    closest = 100000;
		   for(int i = 0; i<otherCastles.length; i++){
	
			  int maybe = knights[j].getDistanceTo(otherCastles[i].getX(),otherCastles[i].getY());
			  if(maybe < closest){
			 	closest = maybe;
				closestIndex[j] = i;
				otherObjectX[j] = otherCastles[i].getX();
				otherObjectY[j] = otherCastles[i].getY();
			}
		  }
		}
		*/  
		castle = getCastles();

		
		int directions; 
		/*for(int i =0;i<knights.length; i++){

			if(knightCapture(knights[i]) == false){
				move(knights[i], knights[i].getDirectionTo(otherObjectX[i], otherObjectY[i]));
			}
			
		}
		*/
		//createPeasants(castle[0]);
	   for(int i =0;i<castle.length; i++){
	   	 if(current < 25)
	   	    createKnights(castle[i]);
	   	    	   	 else if(current < 50)
	   	 {
	   		createPeasants(castle[i]);
	
	   	 }
	   	 else if(current<150)
	   	    createKnights(castle[i]);
	   	 else if(current< 250)
	   	    createPeasants(castle[i]);
	   	 else if(current<350)
	   	    createKnights(castle[i]);
	   	 else
	   	    createPeasants(castle[i]);         
	  }  
	    peasants = getPeasants();
	   for(int i=0; i<peasants.length; i++){
	   	move(peasants[i], rand.nextInt(8) + 1);
	   }

	   
	   
	}
	public void peasantMove(IPeasant p){
		
			if(this != World.getLandOwner(p.getX()-1, p.getY()-1)){
			   move(p, MOVE_NW);  //northwest
			   return;
			}
		   if(this != World.getLandOwner(p.getX()-1, p.getY())){
		     move(p, MOVE_W);  //northwest
		     return;
		}
		if(this != World.getLandOwner(p.getX()-1, p.getY()+1)){
		  move(p, MOVE_SW);  //northwest
		  return;
	 }
	 if(this != World.getLandOwner(p.getX(), p.getY()+1)){
	   move(p, MOVE_S);  //northwest
	   return;
  }
   if(this != World.getLandOwner(p.getX(), p.getY()-1)){
	 move(p, MOVE_N);  //northwest
	 return;
}
   if(this != World.getLandOwner(p.getX()+1, p.getY()-1)){
	 move(p, MOVE_SE);  //northwest
	 return;
}
   if(this != World.getLandOwner(p.getX()+1, p.getY())){
	 move(p, MOVE_E);  //northwest
	 return;
}
   if(this != World.getLandOwner(p.getX()+1, p.getY()-1)){
	 move(p, MOVE_NE);  //northwest
	 return;
}
   move(p, rand.nextInt(8) +1);
	}
	public void knightMove(IKnight knight){
		int random = rand.nextInt(8) + 1;
		IObject ocastle = closestObject(knight);
					move(knight, knight.getDirectionTo(ocastle.getX(), ocastle.getY()));
		
}
	public boolean knightCapture(IKnight knight){
		for(int i = 1; i<9; i++){
			Point np = World.getPositionAfterMove(knight.getX(),knight.getY(),i);
			
			if(np != null){
				IObject object = World.getObjectAt(np.x, np.y);
				if(object != null && !object.getRuler().equals(knight.getRuler())){
					capture(knight, i);
					return true;
				}
				
			}
		}
		return false;
	}
	public ICastle closestCastle(IKnight knight){
		int closest = 100000;
		ICastle returnVal = null;
		if(otherCastles.length == 0)
		   return null;
		for(int i = 0; i<otherCastles.length; i++){
	
			   int maybe = knight.getDistanceTo(otherCastles[i].getX(),otherCastles[i].getY());
			   if(maybe < closest){
				 closest = maybe;
				 returnVal = otherCastles[i];
				 }
		  }
		return returnVal;
	}
public ICastle ourClosestCastle(IKnight knight){
	int closest = 100000;
	ICastle returnVal = null;
	for(int i = 0; i<castle.length; i++){
	
		   int maybe = knight.getDistanceTo(castle[i].getX(),castle[i].getY());
		   if(maybe < closest){
			 closest = maybe;
			 returnVal = castle[i];
			 }
	  }
	return returnVal;
}
	public IObject closestObject(IKnight knight){
		otherPeasants = World.getOtherPeasants();
		otherKnights = World.getOtherKnights();
		otherCastles = World.getOtherCastles();
		int closest = 100000;
		IObject returnVal = null;
		
	   for(int i = 0; i<otherCastles.length; i++){
	
			  int maybe = knight.getDistanceTo(otherCastles[i].getX(),otherCastles[i].getY());
			  if(maybe < closest){
				closest = maybe;
			    returnVal = otherCastles[i];
				}
	 	 }
	 	 for(int i = 0; i<otherKnights.length; i++){
	
			 int maybe = knight.getDistanceTo(otherKnights[i].getX(),otherKnights[i].getY());
			 if(maybe < closest){
			   closest = maybe;
			   returnVal = otherKnights[i];
			   }
		 }
		 for(int i = 0; i<otherPeasants.length; i++){
	
			int maybe = knight.getDistanceTo(otherPeasants[i].getX(),otherPeasants[i].getY());
			if(maybe < closest){
			  closest = maybe;
			  returnVal = otherPeasants[i];
			  }
		 }
	 return returnVal;
	}
}