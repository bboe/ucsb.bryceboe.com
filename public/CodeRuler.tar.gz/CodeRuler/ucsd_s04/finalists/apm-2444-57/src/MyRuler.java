import com.ibm.ruler.*;
import java.util.*;
import java.awt.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	protected Random rand = new Random();
	private IPeasant[] peasants;
	private IKnight[] knights;
	private ICastle[] castles;
	private ICastle[] myCastles;
	private boolean makeKnights = false;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Lucky~!";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 57";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		castles = World.getOtherCastles();
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		int x;
		int y;
		int firstK = 0;
		int lastK = 0;
		int dir = 1;
		Point np = null;
		int randDir = rand.nextInt(8)+1;
		
		//System.out.println(lastMoveTime);
		
		knights = getKnights();
		peasants = getPeasants();
		myCastles = getCastles();
		
		// ------------ Castles ---------------------
		
		for(int i=0; i<myCastles.length; i++)
		{
			if(knights.length < 7)
			{
				if(!makeKnights)
					createKnights(myCastles[i]);
			}
			else if(knights.length > 35)
			{
				if(makeKnights)
					createPeasants(myCastles[i]);
			}
			else if(makeKnights)
			{
				createKnights(myCastles[i]);
				makeKnights = false;
			}
			else
			{
				createPeasants(myCastles[i]);
				makeKnights = true;
			}
		}
		
		// ------------ Peasants --------------------
		
				
		for(int i=0; i<peasants.length; i++)
		{ 
			int j = 1;
			
			for(j=1; j<9; j++)
			{
				np = World.getPositionAfterMove(peasants[i].getX(), peasants[i].getY(), j);
				if(np != null && World.getLandOwner(np.x, np.y) != this && World.getObjectAt(np.x, np.y) == null)
				{
					move(peasants[i], j);
					break;
				}
			}
			
			if(j == 9)
				move(peasants[i], randDir);
		}
		
		//------------ Knights ----------------------
		
		
		if(castles.length > 0)
		{	
			x = castles[0].getX();
			y = castles[0].getY();

			for(int i=0, j=0; i<knights.length && j<5; i++)
			{
				if(knights[i].isAlive() && !knightCapture(knights[i]))
				{
					dir = knights[i].getDirectionTo(x, y);
					np = World.getPositionAfterMove(knights[i].getX(), knights[i].getY(), dir);
					
					if(World.getObjectAt(np.x, np.y) == null)
						move(knights[i], dir);
					else
						move(knights[i], randDir);
						
					j++;
				}	
				
				firstK = i+1;
			}
		}

		if(castles.length > 1)
		{		
			x = castles[1].getX();
			y = castles[1].getY();

			for(int i=knights.length-1, j=0; i>=0 && j<5; i--)
			{
				if(knights[i].isAlive() && !knightCapture(knights[i]))
				{
					dir = knights[i].getDirectionTo(x, y);
					np = World.getPositionAfterMove(knights[i].getX(), knights[i].getY(), dir);
					
					if(World.getObjectAt(np.x, np.y) == null)
						move(knights[i], dir);
					else
						move(knights[i], randDir);
						
					j++;
				}
				
				lastK = i-1;
			}
		}
		
		IKnight otherK = null;
		IKnight[] k = World.getOtherKnights();
		for(int i=0; i<k.length; i++)
		{
			if(k[i].isAlive())
				otherK = k[i];
		}				
		for(int i=firstK; i<lastK; i++)
		{
			if(knights[i].isAlive() && !knightCapture(knights[i]))
			{
				if(castles.length > 2 && knights.length < 35)
				{
					x = castles[2].getX();
					y = castles[2].getY();
			
					move(knights[i], knights[i].getDirectionTo(x, y));
				}
				else if(otherK == null)
					move(knights[i], randDir);
				else
					move(knights[i], knights[i].getDirectionTo(otherK.getX(), otherK.getY()));
			}
				 
		}
	}
	
	public boolean knightCapture(IKnight knight)
	{
		for(int i=1; i<9; i++)
		{
			//find the position
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			
			//make sure the position is valid move
			if(np!=null)
			{
				IObject object = World.getObjectAt(np.x, np.y);
				if(object!=null && !object.getRuler().equals(knight.getRuler()))
				{
					capture(knight,i);
					return true;
				}
			}
		}
		return false;
	}
}