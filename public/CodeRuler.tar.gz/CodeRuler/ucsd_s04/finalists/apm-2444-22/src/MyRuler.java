import com.ibm.ruler.*;
import java.util.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Nicely inconspicuous Ford";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 22";
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */

	public void initialize() {
		ICastle[] castles = getCastles();
		for(int i = 0; i < castles.length; ++i)
			cmap.put(new java.awt.Point(castles[i].getX(), castles[i].getY()),new Integer(0));
			
		castles = World.getOtherCastles();
		for(int i = 0; i < castles.length; ++i)
			cmap.put(new java.awt.Point(castles[i].getX(), castles[i].getY()),new Integer(-100));
	}


	public ICastle findBestCastle(java.awt.Point exclude)
	{
		ICastle[] castles = World.getOtherCastles();
		if(castles.length == 0)
			return null;
			
		int best = 0;
		double bestScore = -100000;
		for(int i = 0; i < castles.length; ++i)
			{
				if(exclude.x == castles[i].getX() && exclude.y == castles[i].getY())
					continue;
				if(worldTime - getLastHeldTime(castles[i]) < 15)
					continue;
					
				double score = 0;
				IKnight oKnights[] = World.getOtherKnights();
				
				
				for(int j = 0; j  < oKnights.length; ++j)
					if(oKnights[j].getRuler() == castles[i].getRuler())
						if(castles[i].getDistanceTo(oKnights[j].getX(), oKnights[j].getY()) < 10)
							score -= 10;	
			
				IKnight knights[] = getKnights();
				for(int j = 0; j  < knights.length; ++j)
					score += 500 / castles[i].getDistanceTo(knights[j].getX(), knights[j].getY());
				if(score > bestScore)
				{
					bestScore = score;
					best = i;  	
				}
			}
			
		return castles[best];
	}
	
	boolean canMove(IObject obj, int dir, boolean capture)
	{
		java.awt.Point pt = 
			World.getPositionAfterMove(obj.getX(), obj.getY(), dir);
		if(pt == null)
			return false;
		IObject obj1 = World.getObjectAt(pt.x, pt.y);
		if(obj1 != null)
			if(capture && obj1.getRuler() != this)
				return true;
			else return false;
		return !capture; 
	}

	int adjustDir(int dir, int delta)
	{
		return ((dir+7)+delta)%8+1;
	}
	
	int getLastHeldTime(IObject castle)
	{
		Object i = cmap.get(new java.awt.Point(castle.getX(),castle.getY()));
		if(i == null)
			return -1000;
		return ((Integer)i).intValue();
	}
	
	java.awt.Point findCastleCorner(IObject castle)
	{
		int x = castle.getX(), y = castle.getY();
	
		if(y > World.HEIGHT/2) ++y;
		else --y;
		
		if(x < World.WIDTH/3) --x;
		else if(x > World.WIDTH/3*2) ++x;
		
		return new java.awt.Point(x,y);
	}
	
	void hunt(Set usedKnights)
	{
		IKnight knights[] = getKnights();
		for(int i = 0; i < knights.length; ++i)
		{
			if(usedKnights.contains(knights[i]))
				continue;
			IObject target = null;
			int targetDist = 100;
			int x1 = knights[i].getX();
			int y1 = knights[i].getY();
			for(int x = -2; x <= 2; ++x)			
				for(int y = -2; y <= 3; ++y)
				{
					IObject obj =World.getObjectAt(x1+x,y1+y);
					if(obj != null && obj.getRuler() != this && knights[i].getDistanceTo(x1+x,y1+y) < targetDist)
					{
						target = obj;
						targetDist = knights[i].getDistanceTo(x1+x,y1+y); 						
					}				 
				}
				if(target != null)
					move(knights[i], knights[i].getDirectionTo(target.getX(), target.getY()));
				else
					move(knights[i], ((int)(Math.random()*8))+1);					 
		}
		
	}
	
	void posse(IKnight[] knights, Set usedKnights, ICastle target, int half)
	{
		int start = 0, stop = knights.length;
		if(half == 1)
			stop = stop/2;
		if(half == 2)
			start = stop/2;
		for(int i = start; i < stop; ++i)
			{
				if(timeout)
					return;
				if(usedKnights.contains(knights[i]))
					continue;

				int dir1 = knights[i].getDirectionTo(target.getX(),target.getY());
				int deltas[] = {0, -1, 1, -2, 2};
		
				for(int j = 0; j < deltas.length; ++j)
				{
					int dir = adjustDir(dir1, deltas[j]);
					if(canMove(knights[i], dir, false))
					{
						move(knights[i], dir);
						break;
					}
					else if(canMove(knights[i], dir, true))
					{
						capture(knights[i], dir);
						break;
					}
				}
			}				
	}
	
	

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		System.err.println("The last move took " + lastMoveTime);
		++worldTime;
		TimerTask task = new TimerTask()
		{
			int localTime = worldTime;
			
			public void run() {
				if(localTime == worldTime)
				{ 
					timeout = true; 
					System.err.println("Preempting by timer");
				}
			}			
		};

		timer.schedule(task, 350);
		timeout = false;
		
		
		ICastle[] castles = getCastles();
		IPeasant[] peasants = getPeasants();
		IKnight[] knights = getKnights();

		for(int i = 0; i < castles.length; ++i)
			cmap.put(new java.awt.Point(castles[i].getX(), castles[i].getY()),new Integer(worldTime));

		
		TreeSet moveTargets = new TreeSet();
		HashSet usedKnights = new HashSet();
		
		for(int i = 0; i < castles.length; ++i)
			{
				java.awt.Point pt = findCastleCorner(castles[i]);
				double best = 10000;
				IKnight bK = null;
				for(int j = 0; j < knights.length; ++j)
					if(!usedKnights.contains(knights[j]))
						if(knights[j].getDistanceTo(pt.x,pt.y) < best)
						{
							best = knights[j].getDistanceTo(pt.x,pt.y);
							bK = knights[j];
						}
				if(bK != null)
				{
					usedKnights.add(bK);
					if(bK.getX() != pt.x || bK.getY() != pt.y)
					{
						int dir1 = bK.getDirectionTo(pt.x,pt.y);
						int deltas[] = {0, -1, 1, -2, 2};

						for(int k = 0; k < deltas.length; ++k)
						{
							int dir = adjustDir(dir1, deltas[k]);
							if(canMove(bK, dir, false))
							{
								move(bK, dir);
								break;
							}
						}			
					}
					
				}
			}
		
		
		for(int i = 0; i < castles.length; ++i)
			{
				if(peasants.length / (knights.length + 0.1)  < 0.5)
					createPeasants(castles[i]);
				else
					createKnights(castles[i]);
				
			}		
		
		for(int i = 0; i < peasants.length; ++i)
		{
			if(timeout)
				return;
			IPeasant p = peasants[i];
			int bestDir = 0;
			int bestPts = -1000;
			
			for(int j = 1; j <= 8; ++j)
			{
				int pts = 0;
				java.awt.Point pt = World.getPositionAfterMove(p.getX(), p.getY(), j);
				if(pt == null)
					continue;
				if(moveTargets.contains(pt))
					continue;
				if(World.getObjectAt(pt.x, pt.y) != null)
					continue;
				if(World.getLandOwner(pt.x, pt.y) != this)
					pts += 15;
				for(int x = -2; x <= 2; ++x)
					for(int y = -2; y <= 2; ++y)
					{
						if(pt.x+x < 0 || pt.x + x > World.WIDTH)
							continue;
						if(pt.y+y < 0 || pt.y + y > World.HEIGHT)
							continue;
						if(World.getLandOwner(pt.x+x, pt.y+y) != this)
							pts += 2;
						IObject obj = World.getObjectAt(pt.x+x, pt.y+y);
						if((obj != null) &&
						    (obj instanceof IKnight) && 
						    (((IKnight)obj).getRuler() != this))
							pts -= 30;
					}
				if(pts > bestPts)
				{
					bestPts = pts;
					bestDir =j; 
				}
			}
			move(p,bestDir);
		}
		ICastle target = findBestCastle(new java.awt.Point(-1,-1));
		if(target != null)
		{
			posse(knights, usedKnights, target, 1);
			ICastle target1 = findBestCastle(new java.awt.Point(target.getX(), target.getY()));
			if(target1 != null && knights.length > World.getOtherKnights().length*2.3)
				posse(knights, usedKnights, target1, 2);
			else
				posse(knights, usedKnights, target, 2);				
		}
		else 
			hunt(usedKnights);
		
		
			
		for(int i = 0; i < knights.length; ++i)
			{
				if(timeout)
					return;
				for(int j = 1; j < 9; ++j)
				{
					java.awt.Point pt = World.getPositionAfterMove(knights[i].getX(), knights[i].getY(), j);
					if(pt == null)
						continue;
					IObject obj = World.getObjectAt(pt.x,pt.y);
					if(obj != null && obj.getRuler() != this)
						capture(knights[i], j);
				}
			}
		task.cancel();	
	}
	
	boolean timeout = false;
	Timer timer = new Timer();
	int worldTime = 0;
	
	 Map cmap = new HashMap();

}