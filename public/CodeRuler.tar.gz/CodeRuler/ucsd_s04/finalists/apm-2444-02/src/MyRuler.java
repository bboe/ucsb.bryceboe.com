import com.ibm.ruler.*;
import java.util.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler 
{
   /* (non-Javadoc)
    * @see com.ibm.ruler.Ruler#getRulerName()
	*/
	int points;
	int moveCount;
	ICastle[] castles;
	int otherCastles;
	Random myRandom = new Random();
	
	
	
    public String getRulerName() 
	{
	   return ("Team Oracle");
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() 
	{
	   return ("Team 2");
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */    
	public void initialize() 
	{
	 /* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	 castles = getCastles ();
	 otherCastles = World.getOtherCastles().length;
		
	}     
	
	public void orderSubjects(int lastMoveTime) 
	{
		
		IKnight[] knights = getKnights ();
		
		int size = knights.length;
		for (int i = 0; i < size ; i++)
			moveKnight (knights[i], i);
				
		IPeasant [] peasants = getPeasants ();
		size = peasants.length;
		for (int i = 0 ; i < size; i++)
			movePeasant (peasants[i], i);
			
		if (getPeasants().length < 10)
		{
			for (int i = 0; i < getCastles().length; i++)
			 { 
			 	 if (castles[i] == null)
			 	    continue;
			 	 createPeasants (castles[i]); 
			 }  
	    }
	
		else
		{
		   for (int i = 0; i < getCastles().length; i++)
		   {
		   	if (castles[i] == null)
		       continue;   
		    createKnights (castles[i]);  
		   }
	    } 			
	} 
	

    public void movePeasant (IPeasant peasant, int index)
    {
		otherCastles = World.getOtherCastles().length;
          final int TIMES = 9;
          
          int targetX = peasant.getX();
          int targetY = peasant.getY();
          int moveDir;
          
          for (int i = 0; i < TIMES; i++)
          {
			if (i == 8)
			{
			   ICastle targetCastle = World.getOtherCastles()[index % otherCastles];   
			   move (peasant, (peasant.getDirectionTo (targetCastle.getX(), targetCastle.getY())));
			   
			}
			moveDir = getRandomMove();
			targetX = peasant.getX();
			targetY = peasant.getY();
                    
             switch (moveDir)
             {
             	case MOVE_N:
             	   targetY--;
             	   break;
             	   
				case MOVE_NE:
				   targetX++;
				   targetY--;
				   break;
				   
				case MOVE_E:
				   targetX++;
				   break;
				
				case MOVE_SE:
				   targetX++;
				   targetY++;
				   break;
				   
				case MOVE_S:
				   targetY++;
				   break;
				   
				case MOVE_SW:
				   targetX++;
				   targetY--;
				   break;
				   
				case MOVE_W:
				   targetX--;
				   break;
				   
				case MOVE_NW:
				   targetX--;
				   targetY--;
				   break;
             }
             
           
             if (World.getLandOwner(targetX, targetY) == null || World.getLandOwner(targetX,targetY).getSchoolName().compareTo("Team 2") != 0)        	   
             {	    
             	move (peasant, moveDir); 
				return;  
             }   	   
		   }
    }

    
    public void moveKnight (IKnight knight, int index)
    {  
		otherCastles = World.getOtherCastles().length;
 	    ICastle targetCastles[] = World.getOtherCastles();
 	    ICastle targetCastle = World.getOtherCastles()[0];
 	    int min = 1000;
 	    int length;
 	    
 	    for (int i = 0; i < targetCastles.length; i++)
 	    {
 	        length = castles[0].getDistanceTo (targetCastles[i].getX(), targetCastles[i].getY());
 	    	if (length < min)
 	    	{ 
 	    	   min = length;
 	    	   targetCastle = targetCastles[i];
 	    	} 
 	    }
 		if (World.getOtherCastles()[0] == null)
 		   return;
 		
 		IKnight[] otherKnights = World.getOtherKnights();
 		IPeasant[] otherPeasants = World.getOtherPeasants();
		otherCastles = World.getOtherCastles().length;
		int targetX = knight.getX();
		int targetY = knight.getY();
		   
		if (knight.getDistanceTo (targetCastle.getX(), targetCastle.getY()) == 1)
		{
			   capture (knight, (knight.getDirectionTo (targetCastle.getX(), targetCastle.getY()))); 
			   return;
		}
				   
		for (int i = 0; i < otherKnights.length; i++)
		{
			if (knight.getDistanceTo (otherKnights[i].getX(), otherKnights[i].getY()) == 1)
			{
				   capture (knight, (knight.getDirectionTo (otherKnights[i].getX(), otherKnights[i].getY())));  
					return;
		    }
		}
		
		int moveDir = knight.getDirectionTo (targetCastle.getX(), targetCastle.getY());
		switch (moveDir)
					{
					   case MOVE_N:
						  targetY--;
						  break;
             	   
					   case MOVE_NE:
						  targetX++;
						  targetY--;
						  break;
				   
					   case MOVE_E:
						  targetX++;
						  break;
				
					   case MOVE_SE:
						  targetX++;
						  targetY++;
						  break;
				   
					   case MOVE_S:
						  targetY++;
						  break;
				   
					   case MOVE_SW:
						  targetX++;
						  targetY--;
						  break;
				   
					   case MOVE_W:
						  targetX--;
						  break;
				   
					   case MOVE_NW:
						  targetX--;
						  targetY--;
						  break;
					}
	   if (index <= 2)
	      return;
	   if (World.getObjectAt(targetX, targetY) == null)
	      move (knight, (knight.getDirectionTo (targetCastle.getX(), targetCastle.getY())));
       else
	      move (knight, getRandomMove());
       return;
    }
    
    public boolean isAvailable (int x, int y)
    { 
              
       if (x > 64 || y > 72)
          return false;
       return true;   
    }
    
    public int getRandomMove()
    {
        return (myRandom.nextInt(8))+1;
    }
}
    
    
       
     
    
    
    
    
    
    
    
    