import com.ibm.ruler.*;

import java.awt.*;

public class MyRuler extends Ruler {
	public String getRulerName() {return "Kevin and Santos";}
	public String getSchoolName() {return "Team 23";}
	
	ICastle target = null;
	
	public void initialize() {
		target = getTarget();
	}
	
	public void sabotage(){
		while(true){
			if( 5 > 6) break;
		}
	}
 
	public void orderSubjects(int lastMoveTime) {
		//sabotage();

		ICastle mine[] = getCastles();

		for( int i=0; i< mine.length; i++){
			if( getKnights().length < 15 ){
				createKnights( mine[i]);	
			}else
			    createPeasants(mine[i]);
		}
		target = getTarget();
		 
		IKnight[] knights = getKnights();
		for(int i=0; i< knights.length; i++){
			knightMove( knights[i]);
		}
		
		IPeasant[] peasants = getPeasants();
		for( int i=0; i< peasants.length; i++){
			peasantMove( peasants[i]);
		}
	}
	
	public ICastle getTarget(){
		IKnight mine[] = getKnights();
		IKnight k = mine[0];
		
		int c = getClosestTo( k, World.getOtherCastles() );		
		
		ICastle others[] = World.getOtherCastles();
		return others[c]; 
		
	}
	

	
	public void knightMove(IKnight k){
		
		ICastle[] oc = World.getOtherCastles();
		
		if( oc.length == 0){
			
			return;
		}
		
		
		target = oc [ getClosestTo( k, oc ) ];
		   
		IKnight others[] = World.getOtherKnights();
		int c = getClosestTo(k, others);
		
		if( k.getDistanceTo( target.getX(), target.getY() ) > 6 )
		if( k.getDistanceTo( others[c].getX(), others[c].getY() ) < 4){
			doMove( k, others[c].getDirectionTo( k.getX(), k.getY() ) ) ;
			return;
		}
		
		
		for( int i=0; i<9; i++){
			Point np = World.getPositionAfterMove( k.getX(), k.getY() , i);
			
			if( np == null ) continue;
			
			IObject o = World.getObjectAt( np.x, np.y );
			if( o == null) continue;
			if( o.getRuler() != this ){
				capture( k, i );
				return;
			}
		}
				
		int d = k.getDirectionTo( target.getX(), target.getY() );
		doMove(k, d);
	}
	
	public int getClosestTo(IObject o, IObject[] list){
		int i;
		int bestIndex = 0;
		int bestVal = list[0].getDistanceTo( o.getX(), o.getY() );
		for( i=0; i< list.length; i++){
			if( o.getDistanceTo(list[i].getX(), list[i].getY()) < bestVal ){
				bestVal = o.getDistanceTo(list[i].getX(), list[i].getY());
				bestIndex = i;
			}
		}
		return bestIndex;
	}
	
	public void peasantMove(IPeasant p){
		
		IKnight[] others = World.getOtherKnights();
		int c = getClosestTo( p, others);
		if( p.getDistanceTo( others[c].getX(), others[c].getY() ) < 4 ){
			doMove( p, others[c].getDirectionTo( p.getX(), p.getY() ));
			return;
			
		}
		
		for( int i=0; i< 9; i++){
			
			Point np = World.getPositionAfterMove(p.getX(), p.getY(), i);
				
			if( np == null ) continue;
			
			if( World.getLandOwner( np.x, np.y ) != null && 
			    World.getLandOwner( np.x, np.y ) != this  ){
				
				doMove( p, i);
				return;			
			}
		}
		
		for( int i=0; i< 9; i++){
			
			Point np = World.getPositionAfterMove(p.getX(), p.getY(), i);
				
			if( np == null ) continue;
			
			if( World.getLandOwner( np.x, np.y ) == null || 
				World.getLandOwner( np.x, np.y ) != this  ){
				
				doMove( p, i);
				return;			
			}
		}
		
		IKnight myknights[] = getKnights();
		
		doMove( p, p.getDirectionTo( 30,30 ) );
	}
	
	public void doMove( IPeasant o, int dir){
		
		Point np = World.getPositionAfterMove( o.getX(), o.getY(), dir);
		IObject block = World.getObjectAt( np.x, np.y );
		
		if( block == null){
			move( o, dir);
			return;
		}
		dir = dir + 3;
		dir = dir % 9;
		move(o, dir);
	}
	
	public void doMove( IKnight o, int dir){
		Point np = World.getPositionAfterMove( o.getX(), o.getY(), dir);
		IObject block = World.getObjectAt( np.x, np.y );
		
		if( block == null){
			move( o, dir);
			return;
		}
		dir = dir + 3;
		dir = dir % 9;
		move(o, dir);
		
	}
	
	

}