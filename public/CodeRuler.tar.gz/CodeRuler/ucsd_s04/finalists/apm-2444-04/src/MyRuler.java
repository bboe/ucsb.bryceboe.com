import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Bow Down";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 4";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	
	public void initialize() {
		// put implementation here
		
		MyRuler ruler = new MyRuler();
		System.out.println(" initializing " );
	
	//	orderSubjects(-1);
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	
	protected Random rand=new Random();
	int count=0;
	ICastle[] otherCastles;
		ICastle[] ourCastles;
		IKnight[] ourKnights;
	IKnight[] otherKnights;
	IPeasant[] otherPeasants,ourPeasants;
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		count ++;
		ourCastles=getCastles();
		ourPeasants=getPeasants();
		ourKnights=getKnights();
		otherKnights=World.getOtherKnights();
		otherPeasants= World.getOtherPeasants();
		otherCastles=World.getOtherCastles();
		for(int i=0;i<ourCastles.length;i++){
				if((count%2)!=0){
					createPeasants(ourCastles[i]);
				}else{
					createKnights(ourCastles[i]);
				}
				count++;
		}
		int[] neighbors=new int [9];	
		
		for (int i=0;i<ourPeasants.length;i++){
			if(!ExpandLand(ourPeasants[i])){
						
					move(ourPeasants[i],rand.nextInt(8)+1);
					
			}
		}
		int j=0;int k=0;
		for(int l=0;l<ourKnights.length/3;l++){
			if((neighbors=KnightCapture(ourKnights[l]))[0]==0){
			j=j%(ourCastles.length);
			MoveTo(ourKnights[l] ,neighbors,CastleDir(ourCastles[j],ourKnights[l]));
			j++;
			
			}
		}
		for (int i=ourKnights.length/3;i<ourKnights.length;i++){
			if((neighbors=KnightCapture(ourKnights[i]))[0]==0){
				if(otherCastles.length>0){
				for(j=0;j<otherCastles.length;j++){
					if(MoveTo(ourKnights[i] ,neighbors,CastleDir(otherCastles[j],ourKnights[i]))){
						break;
					}
				}
				}else{
					if(otherKnights.length>0){
					//for(int k =0;k<otherKnights.length;k++){
						k=k%(ourCastles.length);					
						if(MoveTo(ourKnights[i] ,neighbors,KnightDir(otherKnights[k],ourKnights[i])))
								k++;
						
										
						
				//	}
					}else{
						for(int p =0;p<otherPeasants.length;p++){
							if(MoveTo(ourKnights[i] ,neighbors,PeasantDir(otherPeasants[p],ourKnights[i]))){
								//	p++;
									break;
							}
						}
					}
				}
			}
		}
		
		return;
	}
	public boolean MoveTo(IKnight knight,int[] neighbors, int Dir){
		if(neighbors[Dir]==0){
			move(knight,Dir);
			
		}else if (neighbors[(Dir+1)%8]==0){
			move(knight,(Dir+1)%8);
			
		}else if (neighbors[(Dir==1)?8:(Dir-1)]==0){
			move(knight,(Dir==1)?8:(Dir-1));
			
		}else{
			return false;
		}	
		return true;	
	}
	public int CastleDir(ICastle castle,IKnight knight){
		return knight.getDirectionTo(castle.getX(),castle.getY());
	}
	public int KnightDir(IKnight otherKnight,IKnight knight){
			return knight.getDirectionTo(otherKnight.getX(),otherKnight.getY());
		}
	public int PeasantDir(IPeasant peasant,IKnight knight){
				return knight.getDirectionTo(peasant.getX(),peasant.getY());
			}
	// call this function only when it is safe
	public boolean ExpandLand(IPeasant peasant){
		int index= (rand.nextInt(8)+1);
		for(int i = 1 ;i<9 ; i++){
			Point np=World.getPositionAfterMove(peasant.getX(),peasant.getY(),(index+1)%8+1);
			if(np != null){
				IObject object = World.getObjectAt(np.x,np.y);
				if(object == null && (World.getLandOwner(np.x,np.y)==null ||
 				!World.getLandOwner(np.x,np.y).equals(peasant.getRuler()))){
					move(peasant,(index+1)%8+1);
					return true;
				}
				//may be we can check the enemy knights
			}
		}
		
		
		return false;
	}
	public int [] KnightCapture(IKnight knight){
			int[] neighbors=new int[9];
			for(int i = 1 ;i<9 ; i++){
				Point np=World.getPositionAfterMove(knight.getX(),knight.getY(),i);
				if(np != null){
					IObject object = World.getObjectAt(np.x,np.y);
					if(object != null && !object.getRuler().equals(knight.getRuler())){
						capture(knight,i);
						neighbors[0]=1;
						return neighbors;
					}else if ( object != null){
						neighbors[i]=1;
					}
					//may be we can check the enemy knights
				}
			}
			return neighbors;
		}
		public int MinDist(){
			int min = -1;
			int index=0;
			int dist;
			for(int i=0; i<otherCastles.length;i++){
				dist = ourCastles[ourCastles.length-1].getDistanceTo(otherCastles[i].getX(), otherCastles[i].getY());
				if (min == -1 || min > dist ) {
				
				    min = dist;
				    index = i;
				}
			}
			return index;
		}
	/*public boolean CaptureOrMove(IKnight knight,int dir){
				
					Point np=World.getPositionAfterMove(knight.getX(),knight.getY(),dir);
					if(np != null){
						IObject object = World.getObjectAt(np.x,np.y);
						if(object != null && object.getRuler().equals(knight.getRuler())){
							capture(knight,dir);
							return true;
						}
						//may be we can check the enemy knights
					}
				
				return false;
			}*/
	/*public boolean CastleCapture(IKnight knight, ICastle castle){
		int dir =knight.getDirectionTo(castle.getX(), castle.getY());
		Point np=World.getPositionAfterMove(knight.getX(),knight.getY(),dir);
		if(np != null){ //don't need this 
				IObject object = World.getObjectAt(np.x,np.y);
				if(object != null && object.getRuler().equals(knight.getRuler())){
						capture(knight,dir);
						
				}else if(object != null){
					move(knight,dir+1);						
						//may be we can check the enemy knights
				}else{
						move(knight , dir);
						
				}
				
				return true;
			}
			return false;
	}*/
	/*public boolean CastleMove(IPeasant peasant, ICastle castle){
			int dir =peasant.getDirectionTo(castle.getX(), castle.getY());
			Point np=World.getPositionAfterMove(peasant.getX(),peasant.getY(),dir);
			if(np != null){ //don't need this 
					IObject object = World.getObjectAt(np.x,np.y);
					if(object == null){
									move(peasant , dir);
					return true;
					}
				}
				return false;
		}*/
	/*	public boolean MoveOrCapturePeasant(IKnight knight, IPeasant peasant){
			if(peasant == null || !peasant.isAlive()){
				return false;
			}
			int dir =knight.getDirectionTo(peasant.getX(), peasant.getY());
			Point np= World.getPositionAfterMove(knight.getX(), knight.getY(),dir);
			if(np != null){
				if(peasant.equals(World.getObjectAt(np.x,np.y))){
					capture(knight,dir);
				}else{		
					move(knight,dir);	
				}
				return true;
			}	
			return false;	
		}*/
		
		
}