import com.ibm.ruler.*;
import java.util.Random;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	int cCastle = 0;
	int cx = 0;	//our castle's x
	int cy = 0;	//our y
	int where_to_y = 0;
	int where_to_x = 0;
	int dir_y[];
	int dir_x[];
	int calls = 0;
	int toggle = 0;
	Random rnd;
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Evil Monkeys";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 68";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		rnd = new Random();
		dir_y = new int[3];
		dir_x = new int[3];
		ICastle ours[] = getCastles();
		ICastle others[] = World.getOtherCastles();
		cx = ours[0].getX();
		cy = ours[0].getY();
		where_to_x = (cx<World.WIDTH/2) ? 1 : 0;
		where_to_y = (cy<World.HEIGHT/2) ? 1 : 0;
		if(where_to_x == 1){
				dir_x[0] = Ruler.MOVE_E;
				dir_x[1] = Ruler.MOVE_NE;
				dir_x[2] = Ruler.MOVE_SE;
		}
		else{
				dir_x[0] = Ruler.MOVE_W;
				dir_x[1] = Ruler.MOVE_SW;
				dir_x[2] = Ruler.MOVE_NW;
		}
		if(where_to_y == 1){
				dir_y[0] = Ruler.MOVE_S;
				dir_y[1] = Ruler.MOVE_SE;
				dir_y[2] = Ruler.MOVE_SW;
		}
		else{
				dir_y[0] = Ruler.MOVE_N;
				dir_y[1] = Ruler.MOVE_NW;
				dir_y[2] = Ruler.MOVE_NE;
		}
		createPeasants(ours[0]);
		orderSubjects(-1);
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		int dir = 0;
		int dirk = 0;
		int dir_act = 0;
		int kx = 0, ky = 0, px = 0, py = 0;
		int temp_x1, temp_x2, temp_x3; 
		calls++;
		if((calls%30) == 0 && calls != 0 && (calls%60) !=0){
			temp_x1 = dir_y[0];
			temp_x2 = dir_y[1];
			temp_x3 = dir_y[2];
			dir_y[0] = dir_x[0];
			dir_y[1] = dir_x[1];
			dir_y[2] = dir_x[2];
			dir_x[0] = temp_x1;
			dir_x[1] = temp_x2;
			dir_x[2] = temp_x3;
			}
		if(calls%60 == 0 && calls != 0){
			temp_x1 = (dir_y[0]+4)%8;
			temp_x2 = (dir_y[1]+4)%8;
			temp_x3 = (dir_y[2]+4)%8;
			dir_y[0] = (dir_x[0]+4)%8;
			dir_y[1] = (dir_x[1]+4)%8;
			dir_y[2] = (dir_x[2]+4)%8;
			dir_x[0] = temp_x1;
			dir_x[1] = temp_x2;
			dir_x[2] = temp_x3;
		}
		
		ICastle ours[] = getCastles();
		for(int j = 0; j<ours.length; j++){
			if(toggle == 0){
				toggle = 1;
				createPeasants(ours[j]);
			}
			else{
				toggle = 0;
				createKnights(ours[j]); 
			}
		}
		
		IPeasant ourp[] = getPeasants();
		for(int i = 0; i < ourp.length; i++){
			dir = rnd.nextInt(3);
			px = ourp[i].getX();
			py = ourp[i].getY();
			Point q = World.getPositionAfterMove(px, py, dirk);
			if(i<ourp.length/2)	move(ourp[i], dir_x[dir]);
			else move(ourp[i], dir_y[dir]);
			/*if(q != null && World.getObjectAt(q.x, q.y) == null){
				if(i<= ourp.length/2) move(ourp[i], dir_x[dir]);
				else move(ourp[i], dir_y[dir]);
			}
			else move(ourp[i], (dir + 4)%8);	*/
		}
		
		IKnight ourk[] = getKnights();
		ICastle ourCs[] = getCastles();
		for(int i = 0; i < ourk.length; i++){
			kx = ourk[i].getX();
			ky = ourk[i].getY();
			ICastle[] others = World.getOtherCastles();
			int temp = 0;
			if(others.length != 0){
				int min = ourk[i].getDistanceTo(others[0].getX(), others[0].getY());
				cCastle = 0;
				for(int k = 1; k<others.length; k++){
					temp = ourk[i].getDistanceTo(others[k].getX(), others[k].getY());					
					if(temp < min){
						min = temp;
						cCastle = k;	
					}		
				}	
				dirk = ourk[i].getDirectionTo(others[cCastle].getX(), others[cCastle].getY());
				Point p = World.getPositionAfterMove(kx, ky, dirk);
				if(p != null){
					if(World.getObjectAt(p.x, p.y) != null){ 
						capture(ourk[i], dirk);
					}						
					else move(ourk[i], dirk);
				}
			}
			else{
				if(i<ourk.length/2)	move(ourk[i], dir_x[dir]);
				else move(ourk[i], dir_y[dir]);
			}
		}
	}
}