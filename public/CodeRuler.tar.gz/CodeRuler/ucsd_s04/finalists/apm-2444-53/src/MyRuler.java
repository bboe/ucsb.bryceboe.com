import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	IRuler[] rulers;
	ICastle[] castles;
	IPeasant[] myPeasants;
	int[] myPDirections;
	int[] myKDirections;
	IKnight[] myKnights;
	ArrayList knights;
	ArrayList marchers, chasers;
	ArrayList chasing;
	ArrayList otherPeasants;
		
	public String getRulerName() {
		return "You Got No Game";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 53";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
		rulers = World.getOtherRulers();

	/*
		castles = World.getOtherCastles();

		myPeasants = getPeasants();
		myKnights = getKnights();

		for(int i=0;i<myPeasants.length;i++)
		{
			myPDirections[i] = (((int)(Math.random()*Integer.MAX_VALUE)) % 8) + 1;
		}
		for(int i=0;i<myKnights.length;i++)
		{
			myKDirections[i] = (((int)(Math.random()*Integer.MAX_VALUE)) % 8) + 1;
		}
*/
/*

		
		int numPeasants = myPeasants.length;

		
		marchers = new ArrayList();
		chasers = new ArrayList();
		chasing = new ArrayList();

		otherPeasants = getOtherPeasants();
		
		for(int i = 0; i < numPeasants; i++)
			{
			chasers.add(myPeasants[i]);
			//assign a peasant
			chasing.add(getPeasantToChase());
			}
		for(int i = 0; i < knights.length; i++)
			{		 
			chasers.add(knights[i]);			
			chasing.add(getPeasantToChase());
			}
*/
	//Assign each chaser a peasant to chase
	

	}

/* 
 	public IPeasant getPeasantToChase()
		{
		return (IPeasant) otherPeasants.remove
			((int) ((Math.random() * Integer.MAX_VALUE)) % otherPeasants.size());
		}
*/


	public void diaspora(){
		for(int i=0; i< myPeasants.length;i++)
		{ move(myPeasants[i], myPDirections[i]); }
		
		for(int i=0; i< myKnights.length;i++)
		{ move(myKnights[i], myKDirections[i]); }
	}
	
	public void shift(){
		for(int i=0; i< myPeasants.length;i++)
		{ move(myPeasants[i], 5); }
		
		for(int i=0; i< myKnights.length;i++)
		{ move(myKnights[i], 7); }
		
	}

	public void regroup(){

	}

	public void attack(){
	}

	public void something(){
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	int myInstCtr=0;
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		//Move chaser towars chasee

// /* **



   IKnight[] myKnights = getKnights();
   IKnight[] eK = World.getOtherKnights();
   ICastle[] eC = World.getOtherCastles();
   IPeasant[] eP = World.getOtherPeasants();

   IObject[] enemies = new IObject[eK.length + eC.length + eP.length];
   int ei = 0; 
	
   for(int i =0;i < eK.length; i++)
	   enemies[ei++] = eK[i];
   for(int i =0; i < eC.length; i++)
	   enemies[ei++] = eC[i];
   for(int i =0; i < eP.length; i++)
	   enemies[ei++] = eP[i];









		IPeasant[] peasants = getPeasants();
		ICastle[] castles = World.getOtherCastles();
		ICastle[] mine = getCastles();

		for(int i=0;i<mine.length;i++)
		{
			if(myInstCtr%5==0)
				createPeasants(mine[i]);
			else
				createKnights(mine[i]);
		}	
				
		
		myInstCtr++;

		for(int i = 0; i < peasants.length; i++)
			{
			IPeasant p = peasants[i];
			int x = p.getX();
			int y = p.getY();
			
			boolean moved = false;
			int di = ((int) (Math.random() * 8)) % 8 + 1;
			
			for(int d = di; d < di + 8; d++)
				{
				int dr = d % 8 + 1;
				Point pnt= World.getPositionAfterMove(x, y, dr);
				if(pnt == null) continue;
				
				if(World.getLandOwner(pnt.x, pnt.y) != this && World.getObjectAt(pnt.x, pnt.y) == null )
					{
					move(p, dr );
					moved = true;
					break;
					}
				}	
			if(moved == false)
				{
				//No empty land
				//move towards another castle
				ICastle towards;
				int tx,ty;
				if(castles.length > 0)
				{
					towards = castles[i % castles.length];
					tx = towards.getX();
					ty = towards.getY();
				}
				else if(eP.length > 0)
				{
					IObject t = eP[i %eP.length];
					tx = t.getX();
					ty = t.getY();	
				}
				else if(eK.length > 0)
				{
					IObject t = eK[i %eK.length];
					tx = t.getX();
					ty = t.getY();	
				}
				else
				{
					tx = World.WIDTH/2;
					ty = World.HEIGHT/2;	
				}
				
				di = p.getDirectionTo(tx, ty);
				int d = di; 
				Point moveTo = World.getPositionAfterMove(x, y, d);
				while(!(null == World.getObjectAt(moveTo.x, moveTo.y)))
					{
					d = (d%8) + 1; 
					if(d == di) break;
					moveTo = World.getPositionAfterMove(x, y, d);
					}
				move(p, d);
				}

			}
	// Move knigts

	for(int k = 0; k < myKnights.length; k++)
		{
		//Check if we can attack
		
		IKnight knight = myKnights[k];
		int mx = knight.getX();
		int my = knight.getY();
		boolean noCompute = false;

		for(int dl = 1; dl <= 8; dl++)
		{
			// ...
			Point p = World.getPositionAfterMove(mx,my,dl);
			IObject o = World.getObjectAt(p.x,p.y);
			if(o == null) { continue; }
			if( !(o instanceof ICastle) && getCastles().length == 0)
				{continue;}
			if(o instanceof IKnight && ((IKnight)o).getStrength() > knight.getStrength())
			{ continue; }
			if(o.getRuler() == this)
			{ continue; }

			capture(knight, dl);
			noCompute = true;
			break;
		}

		if(noCompute) { continue; }
		//Find place to move
		
		//If we have no castles
		if(getCastles().length == 0)
			enemies = eC;

		//find nearest enemy 
		//Follow closest people
		int nearestDist = Integer.MAX_VALUE;
		int nearestX = 0;
		int nearestY = 0;


		for(int e = 0; e < enemies.length;e++)
			{
			IObject enemy = enemies[e];
			if(enemy instanceof IKnight && ((IKnight)enemy).getStrength() > knight.getStrength())
			{ continue; }

			int ex = enemy.getX();
			int ey = enemy.getY();
			int dist= knight.getDistanceTo(ex, ey);
			if(dist < nearestDist)
				{
				nearestDist = dist;
				nearestY = ey;
				nearestX = ex;
				}
			}




		move(knight, knight.getDirectionTo(nearestX, nearestY));
		}
	}
}



/*		if(myInstCtr < 20) {
			diaspora(); 
		}
		else if(myInstCtr < 25)
		{	shift();} 
		else if(myInstCtr < 48)
		{regroup();} 
		else{
			attack();
			something();
		}
	}
}
*/
/*
		Iterator ChaserIter = chasers.iterator();
		Iterator ChasingIter = chasing.iterator();

		for(int i = 0; i < chasers.size(); i++)
			{
			IObject chaser = (IObject) chasers.get(i);
			IObject chasee = (IObject) chasing.get(i);
			//Check that chaser is valid
			if(!chaser.isAlive())
				{
				otherPeasants.add(chasing.remove(i));
				chasers.remove(i);
				i--;
				limit--;
				continue;
				}
			//check that chasee is valid
			if(!chasee.isAlive())
				{
				//get a new peasant
				chasing.set(i, getPeasantToChase());
				}
			if(chaser instanceof IKnight)
				move(((IKnight) chaser), chaser.getDirectionTo(chasee.getX(), chasee.getY()));
			else
				move(((IPeasant) chaser), chaser.getDirectionTo(chasee.getX(), chasee.getY()));
			*/
	
	/*
	public ArrayList getOtherPeasants()
		{
		ArrayList Peasants = new ArrayList();
		for(int i = 0; i < rulers.length; i++)
			{
			IPeasant[] p = rulers[i].getPeasants();
			for(int j = 0; j < p.length; j++)
				Peasants.add(p[j]);
			}
		return Peasants;
		}

*/



