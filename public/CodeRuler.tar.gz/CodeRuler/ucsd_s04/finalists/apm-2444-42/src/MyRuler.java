import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	protected Random rand;
	
	private int MAX_CASTLES = 6;
	private int MAX_PEASANTS = 1000;
	private int MAX_KNIGHTS = 1000;
	

	// array of castles, counts turns until next production cycle
	protected CastleInfo[] castleStats;
	private class CastleInfo
	{
		public int turnsUntilProduce = 0;
		public int lastProduced = 0;
	}
	
	protected IKnight[] currentKnights = null;
	
	protected KnightInfo[] knightStats;
	private class KnightInfo
	{
		public IObject target = null;
		public int attempts = 0;
		
		public boolean isValidMission()
		{
			if (target == null)
				return false;
				
			if (!target.isAlive())
				return false;
				
			if (attempts > 60)
				return false;	
				
			return true;
		}
	}
	
	protected IPeasant[] currentPeasants = null;
	private PeasantInfo[] peasantStats;
	private class PeasantInfo
	{
		public boolean onMission = false;
		public Point destination = null;
		public void newMission()
		{
			onMission = true;
			destination = new Point(
				rand.nextInt(World.WIDTH)+1,
				rand.nextInt(World.HEIGHT)+1
			);
			System.out.println("New Mission Assigned");
		}
	}
			
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "thebends";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 42";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		rand = new Random();

		castleStats = new CastleInfo[MAX_CASTLES];
		for (int i=0; i < MAX_CASTLES; i++)
		{
			castleStats[i] = new CastleInfo();
		}
		
		peasantStats = new PeasantInfo[MAX_PEASANTS];
		for (int i=0; i < MAX_PEASANTS; i++)
		{
			peasantStats[i] = new PeasantInfo();
		}

		knightStats = new KnightInfo[MAX_KNIGHTS];
		for (int i=0; i < MAX_KNIGHTS; i++)
		{
			knightStats[i] = new KnightInfo();
		}

	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		HandlePeasantLogic();
		HandleKnightLogic();
		HandleCastleLogic();
	}

	private void MassDestory(IObject target)
	{
		IKnight[] knights = getKnights();
		int size = knights.length;

		for (int i=0; i < size ; i++)
		{
			IKnight thisKnight = knights[i];
			if (thisKnight != null)
			{
				moveAndCapture(thisKnight, target);
				knights[i] = null;
			}			
		}
	}
	
//	private void MassDestory(IObject target, int howMany)
//	{
//		IKnight[] knights = getKnights();
//		int size = knights.length;
//
//		for (int i=0; (i < size) && howMany > 0; i++)
//		{
//			IKnight thisKnight = knights[i];
//			if (thisKnight != null)
//			{
//				moveAndCapture(thisKnight, target);
//				howMany--;
//				knights[i] = null;
//			}			
//		}
//	}

	private void HandleKnightLogic()
	{
		currentKnights = getKnights();
		int size = currentKnights.length;
		
		// no knights, we're screwed
		if (size < 1)
			return;
//			
//		// get the castle closest to knight #1
//		IKnight leadKnight = currentKnights[0];
//		Point leadKnightPos = new Point(leadKnight.getX(), leadKnight.getY());
//
//		for (int i=0; i< size; i++)
//		{
//			IKnight current = currentKnights[i];
//			if (!current.isAlive())
//				continue;
//				
//			KnightInfo info = knightStats[i];
//			
//			if (info.isValidMission())
//			{
//				System.out.println("Knight #" + i + " is cont");
//				DoMission(i);
//			} else {
//				System.out.println("Knight #" + i + " gets new mission");
//				AssignMission(i);
//			}
//		}

		IKnight leadKnight = currentKnights[0];
		Point leadKnightPos = new Point(leadKnight.getX(), leadKnight.getY());


// works pretty good
		ICastle[] enemyCastles = World.getOtherCastles();
		IObject target = findClosest(leadKnightPos, enemyCastles);
		if (target != null)
		{
			MassDestory(target);
			return;
		}
		
		IObject[] enemyKnights = World.getOtherKnights();		 
		target = findClosest(leadKnightPos, enemyKnights);
		if (target != null)
		{
			MassDestory(target);
			return;
		} 
		
		IObject[] enemyPeasants = World.getOtherPeasants();
		target = findClosest(leadKnightPos, enemyPeasants);
		if (target != null)
		{
			MassDestory(target);
			return;
		} 
	}
	
	private void DoMission(int index)
	{
		IKnight current = currentKnights[index];
		if (current == null)
		{
			System.out.println("DoMission: NULL knight");
			return;
		}
		
		moveAndCapture(current, knightStats[index].target);
		knightStats[index].attempts++;
	}
	
	private int lastMission = 0;
	private void AssignMission(int index)
	{
		IKnight current = currentKnights[index];
		if (current == null)
		{
			System.out.println("DoMission: NULL knight");
			return;
		}
		Point knightPos = new Point(current.getX(), current.getY());
		if (lastMission >= 0 && lastMission <= 6)
		{
			ICastle[] enemyCastles = World.getOtherCastles();
			IObject target = findClosest(knightPos, enemyCastles);
			if (target == null)
			{
				lastMission = 7;
			} else {
				System.out.println("Assigning Castle to #" + index);
				knightStats[index].attempts = 0;
				knightStats[index].target = target;
				lastMission++;
				return;
			}
		}
		if (lastMission >= 7 && lastMission <= 8) {
			IKnight[] enemyKnights = World.getOtherKnights();
			IObject target = findClosest(knightPos, enemyKnights);
			if (target == null)
			{
				lastMission = 9;
			} else {
				System.out.println("Assigning Knight to #" + index);
				knightStats[index].attempts = 0;
				knightStats[index].target = target;
				lastMission++;
				return;
			}
		}
		if (lastMission >= 9 && lastMission <= 10) {
			IPeasant[] enemyPeasants = World.getOtherPeasants();
			IObject target = findClosest(knightPos, enemyPeasants);
			if (target == null)
			{
				lastMission = -1;
			} else {
				System.out.println("Assigning Peasant to #" + index);
				knightStats[index].attempts = 0;
				knightStats[index].target = target;
				lastMission++;
				return;
			}
		}
		lastMission++;
	}


	private IObject findClosest(Point startLocation, IObject[] list)
	{
		int size = list.length;

		int lowIndex = -1;
		int lowDistance = Integer.MAX_VALUE;

		IObject target;
		for (int i=0; i < size; i++)
		{
			target = list[i];
			if (target == null)
				continue;
				
			// skip us
			if (target.equals(this))
				continue;
			
			int dist = target.getDistanceTo(startLocation.x, startLocation.y);
			if (dist < lowDistance)
			{
				lowDistance = dist;
				lowIndex = i;
			}
		}
		
		if (lowIndex == -1)
			return null;
		else
			return list[lowIndex];
	}
	
	private void moveAndCapture(IKnight knight, IObject object)
	{
		//System.out.println("Moving and Capturing!");

		if (object == null || !object.isAlive())
			return;

		// always attack neighbors before attacking object			
		if (knightCapture(knight))
			return;

		int dir = knight.getDirectionTo(object.getX(), object.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			
			IObject tempObject = World.getObjectAt(np.x, np.y);
			if (tempObject == null)
			{
				move(knight, dir);
			}
			else
			{
				if (object.getRuler().equals(this))
				{
					
					
				}
				if (object.equals(World.getObjectAt(np.x, np.y)))
					capture(knight, dir);
			else
				move(knight, dir);
			}
		}
	}
	
	/* returns true if a neighbor was attacked, false otherwise */
	private boolean knightCapture(IKnight knight)
	{
		for (int dir = 1; dir < 9; dir++)
		{
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(),
						dir);

			if (np == null)
				continue;
			
			IObject object = World.getObjectAt(np.x, np.y);
			if (object == null)
				continue;
				
			if (!object.getRuler().equals(knight.getRuler()))
			{
				capture(knight, dir);
				return true;
			}
		}	
		
		return false;
	}
	
	private void HandlePeasantLogic()
	{
		currentPeasants = getPeasants();
		int size = currentPeasants.length;
		PeasantInfo peasantInfo;
		IPeasant peasant;
		for (int i=0; i < size ; i++) {
			peasant = currentPeasants[i];
			peasantInfo = peasantStats[i];
			if (!peasantInfo.onMission)
			{
				if (HandlePeasantRandom(peasant))
					continue;

				// set them off in a random direction
				peasantInfo.newMission();
			}
			HandlePeasantMission(i);
		}		
	}
	
	private void HandlePeasantMission(int index)
	{
		IPeasant peasant = currentPeasants[index];
		if (peasant == null || !peasant.isAlive())
			return;
	
		
		Point dest = peasantStats[index].destination;
		int dir = peasant.getDirectionTo(dest.x, dest.y);
		Point np = World.getPositionAfterMove(peasant.getX(), peasant.getY(), dir);
		if (np != null) {
			int dist = peasant.getDistanceTo(dest.x, dest.y);
			if (dist > 3)
			{
				move(peasant, dir);
			}
			else
			{
				//System.out.println("Peasant Mission complete!"); 
				peasantStats[index].onMission = false;
			}
		}
	}
	
	/* true if was handled, false if nowhere to go */
	private boolean HandlePeasantRandom(IPeasant peasant)
	{
		for (int dir = 8; dir > 0; dir--)
		{
			Point np = World.getPositionAfterMove(peasant.getX(), peasant.getY(),
						dir);
			if (np == null)
				continue;
				
			IRuler ruler = null;
			try {						
				 ruler = World.getLandOwner(np.x, np.y);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			if (ruler == null)
			{
				move(peasant, dir);
				return true;
			}
			if (!ruler.equals(peasant.getRuler()))
			{
				move(peasant, dir);
				return true;
			}
		}
		
		//System.out.println("PEASANT STUCK");
		/* surrounded by our own land */
		return false;
	}
	
	/* true if was handled, false if nowhere to go */
	private boolean HandleKnightRandom(IKnight knight, IObject target)
	{
		Point randomPt = new Point(
				target.getX() + (rand.nextInt(20)-10),
				target.getY() + (rand.nextInt(20)-10));
		
		try {
			int dir = knight.getDirectionTo(randomPt.x, randomPt.y);
			move(knight, dir);
		} catch (Exception ex) {
			System.out.println("------");
			ex.printStackTrace();
			System.out.println("------");
		}
		return true;
	}
	
	private void HandleCastleLogic()
	{
		int produceTime = getProductionTurns();
		//System.out.println("Production Time: " + produceTime);
		
		// iterate through each castle
		ICastle[] castles = getCastles();
		CastleInfo castleInfo;
		int size = castles.length;
		for (int i=0; i < size; i++) {
			castleInfo = castleStats[i];			
			if (castleInfo.turnsUntilProduce < 0)
			{
				//System.out.println("Producing!");
				int lastType = castleInfo.lastProduced;
				if (lastType >= 0 && lastType <= 1)
				{
					createKnights(castles[i]);
					castleInfo.lastProduced++;
				} else {
					createPeasants(castles[i]);
					castleInfo.lastProduced = 0;
				}
				castleInfo.turnsUntilProduce = produceTime + 1;
			} else {
				//System.out.println("Turns Left: " + castleInfo.turnsUntilProduce);
			}
			castleInfo.turnsUntilProduce--;
			castleStats[i] = castleInfo;
		}
	}
		
	private int getProductionTurns()
	{
		// wait four turns
		int requiredTurns = 4;
		int landCount = this.getOwnedLandCount();
		if (landCount >= 500)
		{
			if (landCount >= 2000)
			{
				if (landCount >= 4000)
					requiredTurns = 4;	// 4000
				else
					requiredTurns = 6;	// 2000
			} else {
				if (landCount >= 1000)
					requiredTurns = 8;	// 1000
				else
					requiredTurns = 10;	// 500
			}
		} else {
			if (landCount >= 125)
			{
				if (landCount >= 250)
					requiredTurns = 12; // 250
				else
					requiredTurns = 14;	//125
			}
		}
		return requiredTurns;
	}
	
	
}