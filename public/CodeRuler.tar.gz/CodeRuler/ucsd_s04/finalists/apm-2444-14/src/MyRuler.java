import com.ibm.ruler.*;
import com.sun.rsasign.t;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	
	

	private Random rand;
	//int [][]map = new int[74][62];
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "G1S_a";	
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 14";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		rand = new Random();
		// put implementation here
	}


int create = 0;
int createk = 0;
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		IKnight [] nites;
		IPeasant [] peas;
		ICastle [] cas;
		ICastle [] ocas = World.getOtherCastles();
		int cas_size, size;
		
	
		//	creating units
		cas = this.getCastles();
		cas_size = cas.length;
		for (int i = 0; i < cas_size; i++) {
			create++;
			createk++;
			if (create > 2) create = 0;
			if ((create == 0 && createk > 25)|| ocas.length == 0)
				this.createPeasants(cas[i]);
			else
				this.createKnights(cas[i]);
				
		}
		
		
		int hangers = 10;
		// moving knights
		nites = this.getKnights();
		size = nites.length;
		for (int i = 0;i < size; i++) {
			if (attackPeeps(nites[i])) continue;
			if (i >= cas_size*hangers) {
				//send to available castle
				attackKnight(nites[i]);
			}
			else {
				moveKnight(nites[i], cas[i/hangers]);
			}
		}
		
		
		// moving peasants
		peas = this.getPeasants();
		size = peas.length;
		for (int i = 0; i < size; i++) {
			int movement = getBestMovement(peas[i]);
			this.move(peas[i],movement);
		}
		
		
		
		
		
		// put implementation here
	}
	
	
	private boolean attackPeeps (IKnight k) {
		Point p;
		int x = k.getX();
		int y = k.getY();
		
		for (int i = 1; i <= 8; i++) {
			p = World.getPositionAfterMove(x,y,i);
			IObject o = World.getObjectAt(p.x,p.y);
			if (o == null) continue;
			else if (o.getRuler() != this) {
				this.capture(k,i);
				return true;
			}
		}
		
		return false;
	}
	
	
	
	private int getBestMovement(IPeasant pea) {
		
		int [] arr = new int[10];
		int start = 1;
		int sum;
		
		int x = pea.getX();
		int y = pea.getY();

		doSum(arr,start++,getLandOwner(x-1,y));
		doSum(arr,start++,getLandOwner(x+1,y-1));
		doSum(arr,start++,getLandOwner(x+1,y));
		doSum(arr,start++,getLandOwner(x+1,y+1));
		doSum(arr,start++,getLandOwner(x,y+1));
		doSum(arr,start++,getLandOwner(x-1,y+1));
		doSum(arr,start++,getLandOwner(x-1,y));
		doSum(arr,start++,getLandOwner(x-1,y-1));
		
		int choice = 1;
		int max = -130;
		for (int i = 1; i <= 8; i++) {
			if (arr[i] > max) {
				max = arr[i];
				choice = i;
			} else if (arr[i] == max && rand.nextInt() %2 == 0) {
				choice = i;
			}
		}
		if (max < 30) {
			ICastle []c = World.getOtherCastles();
			if (c != null && c.length > 0) {
				choice = pea.getDirectionTo(30,30);
			}
		}
		

		return choice;
	}
	private void attackKnight(IKnight k) {
		if (rand.nextInt() % 8 == 0)
			this.move(k,rand.nextInt()%8+1);
		else {
			ICastle []c = World.getOtherCastles();
			if (c.length <= 0) {
				this.move(k, rand.nextInt()%8 +1);
			} else {
				int count = 0;
				int which_count = 100;
				int which = 0;
				Point p;
				for (int i = 0; i < c.length; i++) {
					int cx = c[i].getX();
					int cy = c[i].getY();
					count = 0;
					for (int x = 1; x <=8; x++) {
						p=World.getPositionAfterMove(cx,cy,x);
						IObject o =World.getObjectAt(p.x,p.y);
						if (o != null && o.getRuler() != this && o instanceof IKnight) {
							count++;
						}
					}
					if (count < which_count) {
						which = i;
						which_count = count;
					} else if (count == which_count) {
						float g = k.getDistanceTo(cx,cy);
						float h = k.getDistanceTo(c[which].getX(),c[which].getY());
						if (g < h)
							which = i;
					}
				}
				moveKnight(k,c[which], 1);
			}
		}
	}
	private void moveKnight(IKnight k, ICastle c) {
		if (rand.nextInt() % 6 == 0 || c == null)
			move(k,rand.nextInt()%8+1);
		else
			moveKnight(k,c,1);
	}
	
	private void moveKnight(IKnight k, ICastle c, int r) {
		//if (c == null) return;
		int casx = c.getX();
		int casy = c.getY();
		int knix = k.getX();
		int kniy = k.getY();
		int dx =  casx - knix;
		int dy =  casy - kniy;
		int nr = -r;
		
		if(Math.abs(dx) <= r && Math.abs(dy) <= r) {
				int dir = k.getDirectionTo(casx,casy);
				this.capture(k,dir);
		} else {
			int dir = k.getDirectionTo(casx,casy);
			Point p = World.getPositionAfterMove(knix,kniy,dir);
			if (World.getObjectAt(p.x,p.y) != null)
				this.capture(k,dir);
			else
				this.move(k,k.getDirectionTo(casx,casy));
		}
	}
	
	private void doSum(int [] arr, int start, int sum) {
		arr[start] += sum;
		sum /= 4;
	//	arr[start-1] += sum;
	//	arr[start+1] += sum;
	}
	
	private int getLandOwner(int x, int y) {
		int sum = 0;
		if (x < 0) return 0;
		if (y < 0) return 0;
		if (x >= 72) return 0;
		if (y >= 64) return 0;
		
	//	if (rand.nextInt() % 6 == 0)
	//		return rand.nextInt() % 8 +1;
			
		IObject ob = World.getObjectAt(x,y);
		if (ob == null) {
			if (World.getLandOwner(x,y) != this)
				sum += 40;
			else 
				sum -= 10;
		}
		else if (ob instanceof IKnight) {
			if (ob.getRuler() != this)
				sum -= 40;
		} else if (ob instanceof IPeasant) {
			if (ob.getRuler() == this)
				sum -= 10;
			else
				sum += 20;
		}
		
		return sum;
		
	}
}