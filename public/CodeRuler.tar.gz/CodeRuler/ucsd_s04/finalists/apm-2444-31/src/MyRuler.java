import com.ibm.ruler.*;
import java.util.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	protected Random rand = new Random();
	protected int peasantDir;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Sir Sia Bot";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 31";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		
		peasantDir = rand.nextInt(8) + 1;		
		for(int j = 0; j < getCastles().length; ++j){
			if(getKnights().length > 20)
				createPeasants(getCastles()[j]);
			else
			    createKnights(getCastles()[j]);
		}
			
			
		IPeasant[] peasants = getPeasants();
		
		int size = peasants.length;
		for(int i = 0; i < size ; i++)
		{
			movePeasant(peasants[i]);
				
		}
		
		/* send to protect castle */
		if(getCastles().length > 0)
			protectCastle();
		else
			captureCastle(World.getOtherCastles()[0], 0);
		/* send to capture other castles */
		
		if(getKnights().length > 4 && World.getOtherCastles().length > 0)
			captureCastle(World.getOtherCastles()[0], 3);
			
		/* try to kill others */
		for(int k = 0; k < getKnights().length; ++k)
			killPeople(getKnights()[k]);
		
				
	}
	
	private void killPeople(IKnight knight)
	{
		int x = knight.getX();
		int y = knight.getY();
		IObject o = null;
		for(int place = 1; place < 9; ++place)
				{
					if(place == 1)
					{
						o = World.getObjectAt(x, y-1);
					}
					else if(place == 2)
					{
						o = World.getObjectAt(x+1, y-1);
					}
					else if(place == 3)
					{
						o = World.getObjectAt(x+1, y);
					}
					else if(place == 4)
					{
						o = World.getObjectAt(x+1, y+1);
					}
					else if(place == 5)
					{
						o = World.getObjectAt(x, y+1);
					}
					else if(place == 6)
					{
						o = World.getObjectAt(x-1, y+1);
					}
					else if(place == 7)
					{
						o = World.getObjectAt(x-1, y);
					}
					else if(place == 8)
					{
						o = World.getObjectAt(x-1, y-1);
					}
			
					/*if(o != null && (o.getRuler() != this))
					{
						try{
							IKnight k = (IKnight)o;
							if(knight.getStrength() < 30)
							{
								place = (place+4)%8;
								move(knight, place);
							}
							else
							{
								capture(knight, place);
								return;
							}
								
							
						}
						catch(ClassCastException e)
						{
							capture(knight, place);
							return;
						}
						
						
					}*/
				if(o != null&& (o.getRuler() != this))
				{
					capture(knight, place);
				}
			}
						
	}
	
	private void protectCastle()
	{
		IKnight[] knights = getKnights();
		ICastle[] castles = getCastles();
		
		int cX = castles[0].getX();
		int cY = castles[0].getY();
		
		for(int i = 0; i < knights.length; ++i)
		{
			if(i == 4)
				return;
			move(knights[i], knights[i].getDirectionTo(cX+(rand.nextInt(3))-1, cY+(rand.nextInt(3))-1));
		}
	}
	
	private void captureCastle(ICastle c, int index)
		{
			IKnight[] knights = getKnights();
		
			int cX = c.getX();
			int cY = c.getY();
		
			for(int i = index; i < knights.length; ++i){
				java.awt.Point p = World.getPositionAfterMove(knights[i].getX(), knights[i].getY(), 
				   knights[i].getDirectionTo(cX, cY));
				   
				if(World.getObjectAt(p.x, p.y) == null)
					move(knights[i], knights[i].getDirectionTo(cX, cY));
					
				else
					move(knights[i], rand.nextInt(8)+1);
			}
				
			
		}
	
	private boolean isSafe(int x, int y)
	{
		IObject o = null;
		IKnight k = null;
		/* for every place around x,y check if there is a knight
		 * if there is, then return false because it isnt safe
		 */
		for(int place = 1; place < 9; ++place)
		{
			if(place == 1)
			{
				o = World.getObjectAt(x, y-1);
			}
			else if(place == 2)
			{
				o = World.getObjectAt(x+1, y-1);
			}
			else if(place == 3)
			{
				o = World.getObjectAt(x+1, y);
			}
			else if(place == 4)
			{
				o = World.getObjectAt(x+1, y+1);
			}
			else if(place == 5)
			{
				o = World.getObjectAt(x, y+1);
			}
			else if(place == 6)
			{
				o = World.getObjectAt(x-1, y+1);
			}
			else if(place == 7)
			{
				o = World.getObjectAt(x-1, y);
			}
			else if(place == 8)
			{
				o = World.getObjectAt(x-1, y-1);
			}
			
			if(o != null)
			{
				try{
					k = (IKnight)o;
					if(k.getRuler() != this)
					 return false;
				}
				catch(ClassCastException e)
				{
					// do nothing if its not a knight
				}
			}
			
		}
		
		return true;
	}
	
	private void movePeasant(IPeasant p){
		int place = rand.nextInt(8) + 1;
		int myX, myY, newX = 0, newY = 0;
		boolean INBOUND, EMPTY, URS;
		
		myX = p.getX();
		myY = p.getY();
		
		for(int i = 0; i < 8; ++i)
		{
			/* loop through to look if place is empty */
			if(place == 1)
			{
				newX = myX;
				newY = myY - 1;
			}
			else if (place == 2)
			{
				newX = myX + 1;
				newY = myY - 1;
			}
			else if (place == 3)
			{
				newX = myX + 1;
				newY = myY;
			}
			else if (place == 4)
			{
				newX = myX + 1;
				newY = myY + 1;
			}
			else if (place == 5)
			{
				newX = myX;
				newY = myY + 1;
			}
			else if (place == 6)
			{
				newX = myX - 1;
				newY = myY + 1;
			}
			else if (place == 7)
			{
				newX = myX - 1;
				newY = myY;
			}
			else
			{
				newX = myX - 1;
				newY = myY - 1;
			}
						
			/* check if emppty */
			if(World.getObjectAt(newX, newY) == null)
				EMPTY = true;
			else
				EMPTY = false;
			
			/* check in bound */
			if(newX < 0  || newY < 0 || newX > 71 || newY > 63)
				INBOUND = false;
			else
				INBOUND = true;
				
			/* check if not yours */
			if(this == World.getLandOwner(newX, newY) )
			{
				URS = true;
			}
			else
				URS = false;
			
			
			/* move */
			if(EMPTY && INBOUND && !URS && isSafe(newX, newY))
			{
				move(p, place);
				return;
			}
			
			//if(!INBOUND)
			// peasantDir = rand.nextInt(8) + 1;
			
			place = (place+1)%8;
		}
		
		/* SECOND RUN!!!@! */
		if(World.getOtherCastles().length > 0)
			place = p.getDirectionTo(World.getOtherCastles()[0].getX(), 
					World.getOtherCastles()[0].getY());
		
		for(int j = 0; j < 8; ++j)
		{
			/* loop through to look if place is empty */
			if(place == 1)
			{
				newX = myX;
				newY = myY - 1;
			}
			else if (place == 2)
			{
				newX = myX + 1;
				newY = myY - 1;
			}
			else if (place == 3)
			{
				newX = myX + 1;
				newY = myY;
			}
			else if (place == 4)
			{
				newX = myX + 1;
				newY = myY + 1;
			}
			else if (place == 5)
			{
				newX = myX;
				newY = myY + 1;
			}
			else if (place == 6)
			{
				newX = myX - 1;
				newY = myY + 1;
			}
			else if (place == 7)
			{
				newX = myX - 1;
				newY = myY;
			}
			else
			{
				newX = myX - 1;
				newY = myY - 1;
			}
						
			/* check if emppty */
			EMPTY = (World.getObjectAt(newX, newY) == null);
			
			/* check in bound */
			if(newX < 0  || newY < 0 || newX > 71 || newY > 63)
				INBOUND = false;
			else
				INBOUND = true;
				
			
			
			/* move */
			if(EMPTY && INBOUND )
			{
				move(p, place);
				return;
			}
			
			//if(!INBOUND)
			// peasantDir = rand.nextInt(8) + 1;
			
			place = (place+1)%8;
		}
	}
}