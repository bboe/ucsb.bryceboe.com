import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	class PeasantStats
	{
		int isInit;
		int initDirection;
		int initCount;
		public PeasantStats()
		{
			isInit = 0;
			initDirection = 0;
			initCount = 0;
		}
	}
	
	class KnightStats
	{
		int isInit;
		int initDirection;
		IKnight knight;
		IObject target;
		public KnightStats(IKnight newknight)
		{
			isInit = 0;
			initDirection = 0;
			knight = newknight;
			target = null;
		}
	}
	
	protected Random rand = new Random();
	private Vector allPeasantStats = new Vector();
	private Vector allKnightStats = new Vector();
	private ICastle targetCastle;

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "PWN";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 30";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		IPeasant[] peas = getPeasants();
		for(int i = 0; i < peas.length; i++)
		{
			allPeasantStats.addElement(new PeasantStats());
		}

		IKnight[] knights = getKnights();
		for(int i = 0; i < knights.length; i++)
		{
			allKnightStats.addElement(new KnightStats(knights[i]));
		}
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		// put implementation here
		// put implementation here
		ICastle[] castles = getCastles();
		int size = castles.length;
		for (int i = 0; i < size; i++) {
			if (getCastles().length < 2) {
				createKnights(castles[i]);
			}
			else if (getCastles().length < 4) {
				int random = rand.nextInt(8);
				if (random >= 0 && random <= 6) {
					createKnights(castles[i]);
				}
				else {
					createPeasants(castles[i]);
				}
			}
			else if (World.getOtherCastles().length != 0) {
				int random = rand.nextInt(8);
				if (random >= 0 && random <= 6) {
					createKnights(castles[i]);
				}
				else {
					createPeasants(castles[i]);
				}
			}
			else if (World.getOtherPeasants().length != 0 || World.getOtherKnights().length != 0) {
				int random = rand.nextInt(8);
				if (random >= 0 && random <= 1) {
					createKnights(castles[i]);
				}
				else {
					createPeasants(castles[i]);
				}
			}
			else {
				createPeasants(castles[i]);
			}
		}
	
		IKnight[] knights = getKnights();
		IPeasant[] victims = World.getOtherPeasants();
		IKnight[] enemies = World.getOtherKnights();
		size = knights.length;
		//size = allKnightStats.size();
		for (int i = 0; i < size; i++) {
			//KnightStats knightStat = (KnightStats)allKnightStats.elementAt(i);
			if (!knightFight(knights[i]) && !knightCapture(knights[i])) {
				if((targetCastle = getTarget(knights[i])) != null) {
					moveAndCapture(knights[i],targetCastle);
				}
				else {
					//if (knightStat.target == null || !knightStat.target.isAlive()) {
					IObject target = null;
					int closest = 10000;
					for (int j = 0; j < enemies.length; j++) {
						int dist = getDistance(knights[i], enemies[j].getX(), enemies[j].getY());
						if (dist < closest) {
							closest = dist;
							target = enemies[j];
						}							
					}
					if (target != null) {
						moveAndCapture(knights[i],target);
						continue;
					}

					closest = 10000;
					for (int j = 0; j < victims.length; j++) {
						int dist = getDistance(knights[i], victims[j].getX(), victims[j].getY());
						if (dist < closest) {
							closest = dist;
							target = victims[j];
						}							
					}
					if (target != null) {
						moveAndCapture(knights[i],target);
						continue;
					}
					else {
						move(knights[i], rand.nextInt(8) + 1);
					}
				}
			}
		}

		IPeasant[] peasants = getPeasants();
		size = peasants.length;
		while(allPeasantStats.size() < size)
		{
			allPeasantStats.addElement(new PeasantStats());
		}
		for (int i = 0; i < size; i++) {
			
			move(peasants[i], peasantDirection(peasants[i], i));
		}
	}
	
	public ICastle getTarget(IKnight knight) {
		ICastle[] castles = World.getOtherCastles();
		if (castles != null) {
			int dist;
			ICastle target = null;
			int mindist = 10000;
			for (int i = 0; i < castles.length; i++) {
				dist = getDistance(knight, castles[i].getX(),castles[i].getY());
				if (dist < mindist) {
					mindist = dist;
					target = castles[i];
				}
			}
			
			castles = getCastles();
			if (castles != null) {
				for (int i = 0; i < castles.length; i++) {
					for (int j = 1; j < 9; j++) {
						Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
						if (np == null) {
							continue;
						}
						IObject object = World.getObjectAt(np.x, np.y);
						if (object != null && object.getRuler() != knight.getRuler() && object instanceof IKnight) {
							dist = getDistance(knight, castles[i].getX(),castles[i].getY());
							if (dist < mindist) {
								mindist = dist;
								target = castles[i];
							}
						}
					}
				}
			}
			return target;
		}
		else {
			return null;
		}
	}
	
	public boolean knightCapture(IKnight knight)
	{
		for(int i = 1; i < 9; i++)
		{
			// find the position
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			 
			 // make sure the position is a valid
			 if (np != null) {
			 	IObject object = World.getObjectAt(np.x, np.y);
			 	if (object != null && object.getRuler() != knight.getRuler())
			 	{
			 		capture(knight,i);
			 		return true;
			 	}
			 }
		}
		return false;
	}
	
	public boolean knightFight(IKnight knight)
	{
		for(int i = 1; i < 9; i++)
		{
			// find the position
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			 
			 // make sure the position is a valid
			 if (np != null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if (object != null && object instanceof IKnight && object.getRuler() != knight.getRuler())
				{
					capture(knight,i);
					return true;
				}
			 }
		}
		return false;
	}

	public void moveAndCapture(IKnight knight, IObject target) {
		int dir = rand.nextInt(8) + 1;
		dir = knight.getDirectionTo(target.getX(), target.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			if (target.equals(World.getObjectAt(np.x,np.y))) {
				capture(knight,dir);
				return;
			}
			else if (World.getObjectAt(np.x, np.y) == null || World.getObjectAt(np.x, np.y) instanceof ICastle ) {
				move(knight,dir);
				return;
			}
		}

		for(int i = 1; i <= 4; i++) {
			int dir1 = (dir + i) % 8 + 1;
			np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir1);
			if (np != null && World.getObjectAt(np.x, np.y) != null) {
				move(knight,dir1);
				return;
			}
			
			int dir2 = (dir - i - 1) % 8 + 1;
			np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir2);
			if (np != null && World.getObjectAt(np.x, np.y) != null) {
				move(knight,dir2);
				return;
			}
		}
	}
	
	public int getDistance(IObject object, int x, int y) {
		int xdist = Math.abs(object.getX() - x);
		int ydist = Math.abs(object.getY() - y);
		
		if (xdist > ydist) {
			return xdist;
		}
		else {
			return ydist;
		}
	}
	
	public int peasantDirection(IPeasant p, int index)
	{
		PeasantStats pStats = (PeasantStats)allPeasantStats.elementAt(index);
		if(pStats.isInit == 0)
		{
			pStats.initDirection = rand.nextInt(8) + 1;
			pStats.isInit = 1;
			return pStats.initDirection;
		}
		else if(pStats.initCount < 10)
		{
			pStats.initCount ++;
			Point target = World.getPositionAfterMove(p.getX(), p.getY(), pStats.initDirection);
			if(target == null)
				pStats.initCount = 10;
			else if(World.getLandOwner(target.x, target.y) == p.getRuler())
				pStats.initDirection = rand.nextInt(8) + 1;
			return pStats.initDirection;
		}
		else
		{
			int minDistance = Integer.MAX_VALUE;
			int moveDir = rand.nextInt(8) + 1;
			for(int i = 1; i < 9; i++)
			{
				int x = p.getX();
				int y = p.getY();
			
				for(int j = 0;j < 10; j++)
				{
					Point target = World.getPositionAfterMove(x, y, i);
					if(target == null)
						break;
					else
					{
						IObject object = World.getObjectAt(target.x, target.y);
						if(object == null && World.getLandOwner(target.x, target.y) != p.getRuler())
						{
							if(j < minDistance)
							{
								minDistance = j;
								moveDir = i;
							}
							else if(j == minDistance)
							{
								int choose = rand.nextInt(2);
								if(choose == 0)
									moveDir = i;
							}
						}
						else if(object != null)
						{
							break;
						}
						else
						{
							Point newpos = World.getPositionAfterMove(x, y, i);
							if (newpos != null) {
								x = newpos.x;
								y = newpos.y;
							}
						}
					}
				}
			}
			return moveDir;
		}
	}
}