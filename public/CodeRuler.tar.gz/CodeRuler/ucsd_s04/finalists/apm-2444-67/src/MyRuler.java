import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	 
	private Point[] dest = {new Point(0,0),
		                    new Point(72,0),
							new Point (72,64),
		                    new Point(0,64)};
	
	private int numTurns, count;                    
    private int currentDestIndex;
    private Random rand = new Random();
	Vector oppKnights;
	private boolean haveAllCastles;
	
	public String getRulerName() {
		return "Manborghini";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 67";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		ICastle firstC = getCastles()[0];
		
		createPeasants(firstC);
		
		int minDist = Integer.MAX_VALUE;
		int temp;
		for( int i=0; i < dest.length; i++ ){
			if( (temp=firstC.getDistanceTo((int)(dest[i].getX()),(int)(dest[i].getY()))) < minDist ){
				minDist = temp;
				currentDestIndex = i;
				numTurns = minDist + 5; 
			}
		}
		count = 0;
		
		haveAllCastles = false;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		
		IPeasant[] p = getPeasants();
		IKnight[] k = getKnights();

		if( count ==  numTurns )
		{
			count = 0;
			currentDestIndex = (currentDestIndex+1)%dest.length;
			ICastle[] c = getCastles();
			for( int i=0; i < c.length; i++ ){
				createPeasants( c[i] );
			}
		}else if( count == (int)(numTurns/3) ){
			ICastle[] c = getCastles();
			for( int i=0; i < c.length; i++ ){
				createKnights( c[i] );
			}
		}
		
		int direction;
		for( int i=0; i < p.length; i++ )
		{
			direction = p[i].getDirectionTo( (int)(dest[currentDestIndex].getX()), (int)(dest[currentDestIndex].getY()) );
			
			Point np = World.getPositionAfterMove(p[i].getX(),p[i].getY(),direction);
			
			int tempDir;
			if( np == null ){
				while( (tempDir=rand.nextInt(8)+1) == direction );
				direction = tempDir;  
			}
			move( p[i], direction );
		}
		count++;

		ICastle[] allCastles = World.getOtherCastles();
		int minDist;
		

		ICastle[] myCas = getCastles();
		int numMyC = myCas.length;
		int kCounts[] = new int[numMyC];
		oppKnights = new Vector();
		
		if( allCastles.length == 0 ){
			haveAllCastles = true;
			int tmpX,tmpY;
			for( int c = 0; c < numMyC; c++ ){
				tmpX = myCas[c].getX();
				tmpY = myCas[c].getY();
		
				for(int m = -3; m < 4; m++){
					if( (tmpX+m)<0 || (tmpX+m)>=World.WIDTH ) continue;
					for( int j = -3; j < 4; j++ ){
						if( (tmpY+j)<0 || (tmpY+j)>=World.HEIGHT ) continue;
				
						if(isKnight(new Point(tmpX+m, tmpY+j))){
							kCounts[c] += 2;
						}			
					}
				}
			}
		}else{
			haveAllCastles = false;
		}
		
		int iter = 0;
		for( int i=0; i < k.length; i++ )
		{
			if( knightCapture(k[i]) > 0 ) continue;

			minDist = Integer.MAX_VALUE;
			int temp;
			direction = MOVE_NONE;
			for(int j=0; j < allCastles.length; j++){
				if( minDist > (temp=k[i].getDistanceTo(allCastles[j].getX(),allCastles[j].getY())) ){
					minDist = temp;
					direction = k[i].getDirectionTo(allCastles[j].getX(),allCastles[j].getY());
				}
			}
			
			if( allCastles.length == 0 ){
				if( i/2 >= oppKnights.size() ){
					/* get peasants */

					/*IPeasant[] oppP = World.getOtherPeasants();
					if( oppP.length == 0 ){
						IKnight[] oppK = World.getOtherKnights();
						if( oppK.length == 0 ) direction = MOVE_NONE;
						else{
							moveAndCaptureK( k[i], oppK[0] );
							continue;
						}
					}else{
						moveAndCaptureP( k[i], oppP[0] );
						continue;
					}*/
					
					IKnight[] oppK = World.getOtherKnights();
					if( oppK.length == 0 ){
						IPeasant[] oppP = World.getOtherPeasants();
						if( oppP.length == 0 ) direction = MOVE_NONE;
						else{
							moveAndCaptureP( k[i], oppP[((i++)%oppP.length)] );
							continue;
						}
					}else{
						moveAndCaptureK( k[i], oppK[((i++)%oppK.length)] );
						continue;
					}
				}else{
					/* Go get opp knights */
					//direction = k[i].getDirectionTo(((IKnight)(oppKnights.get(i/2))).getX(), ((IKnight)(oppKnights.get(i/2))).getY() );
					moveAndCaptureK( k[i], ((IKnight)(oppKnights.get(i/2))));
					continue;
				}
			}
			
			Point np = World.getPositionAfterMove(k[i].getX(),k[i].getY(),direction);
		
			int tempDir;
			if( np == null ){
				while( (tempDir=rand.nextInt(8)+1) == direction );
				direction = tempDir;  
			}
			move(k[i],direction);
		}
	}
	
	public boolean isKnight( Point p ){
		if( p == null ) return false;
			
		IObject object = World.getObjectAt(p.x,p.y);
		if( object == null ) return false;
		if( object instanceof IKnight ){
			oppKnights.add( object );
			return true;
		}
		else return false;
	}
	
	public int knightCapture( IKnight knight ){
		for( int i=1; i < 9; i++ ){
			Point np = World.getPositionAfterMove(knight.getX(),knight.getY(),i);
			
			if( np != null ){
				IObject object = World.getObjectAt(np.x,np.y);
				if( object != null && !object.getRuler().equals(knight.getRuler())){
				  if(!(object instanceof IKnight) || haveAllCastles || ((object instanceof IKnight) && ((IKnight)object).getStrength()<85)){
					capture(knight,i);
					return i;
				  }
				}
			}
		}
		return -1;
	}
	
	public void moveAndCaptureP(IKnight knight,IPeasant peasant){
		
		if (peasant == null || !peasant.isAlive()) return;
		
		int dir = knight.getDirectionTo(peasant.getX(),peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(),knight.getY(),dir);
		if( np != null ){
			if( peasant.equals(World.getObjectAt(np.x,np.y)))
				capture(knight,dir);
			else
				move(knight,dir);
		}
	}
	
	public void moveAndCaptureK(IKnight knight,IKnight target){
		
		if (target == null || !target.isAlive()) return;
		
		int dir = knight.getDirectionTo(target.getX(),target.getY());
		Point np = World.getPositionAfterMove(knight.getX(),knight.getY(),dir);
		if( np != null ){
			if( target.equals(World.getObjectAt(np.x,np.y)))
				capture(knight,dir);
			else
				move(knight,dir);
		}
	}
}