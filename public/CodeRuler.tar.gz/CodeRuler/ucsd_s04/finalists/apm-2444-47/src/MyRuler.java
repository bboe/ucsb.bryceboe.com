import com.ibm.ruler.*;
import java.awt.Point;
import java.util.*;



/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	
	protected Random rand = new Random();
	protected ICastle castles[];
	protected Point castleLoc[];			// location of nearest castles
	protected Point castleDefendPoint[];
	
	protected int target = 1;
	
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Code Ninja";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 47";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		//Set up the circular order of castles...
		int i, j, x, y;
		ICastle c[] = World.getOtherCastles();
		ICastle cme[] = getCastles();
		ICastle n;//n[] = new ICastle[c.length + 1];
		castles = new ICastle[c.length + 1];
		//castles2 = new int[]
		castleLoc = new Point[c.length + 1];
		castleDefendPoint = new Point[c.length + 1];
		int numCastles = c.length + 1;
		
		for (i = 0; i < numCastles; i++) {
			castleLoc[i] = new Point();
			castleDefendPoint[i] = new Point();
		}
		
		//castles[0] = getCastles()[0];
		System.err.println(cme);
		castleLoc[0].x = cme[0].getX();
		castleLoc[0].y = cme[0].getY();
		castles[0] = cme[0];
		for( i = 1; i < numCastles; i++) {
			castles[i] = c[i-1];
			//castleLoc[i].x = c[i-1].getX();
			//castleLoc[i].y = c[i-1].getY();
		}
		
		for(i = 0; i < numCastles - 1; i++ ) {
			int mindist = 10000;
			int mincastle = 0;
			for( j = i+1; j < numCastles; j++ ) {
				int dist = castles[i].getDistanceTo( castles[j].getX(), castles[j].getY() );
				if( dist < mindist ) {
					mindist = dist;
					mincastle = j;
				}
			}
			//castleLoc[i].x = castles[i].getX();
			//castleLoc[i].y = castles[i].getY();
			n = castles[mincastle];
			castles[mincastle] = castles[i+1];
			castles[i + 1] = n;
		}
		
		for( i = 0; i < numCastles; i++ ) {
			System.out.println(i);
			castleLoc[i].x = castles[i].getX();
			castleLoc[i].y = castles[i].getY();
		}
		
		
		
		
		// set up defend points for castles
		//castleDefendPoint = new Point[numCastles];
		for ( i = 0; i < numCastles; i++ ) {
			x = castleLoc[i].x;
			y = castleLoc[i].y;
			if (x < 24)
				castleDefendPoint[i].x = x - 1;
			else if (x < 48)
				castleDefendPoint[i].x = x;
			else
				castleDefendPoint[i].x = x + 1;
			
			if (y < 21)
				castleDefendPoint[i].y = y - 1;
			else if (y < 43 && (x < 24 || x > 48))
				castleDefendPoint[i].y = y;
			else if (y < 43)
				castleDefendPoint[i].y = y - 1;
			else
				castleDefendPoint[i].y = y + 1;
		}
		
		System.out.println(numCastles + "\n");
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		int i, x, y;
		int dir;
		IPeasant[] ourPeasants = getPeasants();
		IKnight[] ourKnights = getKnights();
		ICastle[] ourCastles = getCastles();
		IPeasant[] otherPeasants = World.getOtherPeasants();
		IKnight[] otherKnights = World.getOtherKnights();
		ICastle[] otherCastles = World.getOtherCastles();
		
		int numPeasants, numKnights, numCastles;
		int numOtherPeasants, numOtherKnights, numOtherCastles;
		numPeasants = (ourPeasants != null) ? ourPeasants.length : 0;
		numKnights = (ourKnights != null) ? ourKnights.length : 0;
		numCastles = (ourCastles != null) ? ourCastles.length : 0;
		numOtherPeasants = (otherPeasants != null) ? otherPeasants.length : 0;
		numOtherKnights = (otherKnights != null) ? otherKnights.length : 0;
		numOtherCastles = (otherCastles != null) ? otherCastles.length : 0;
		
		if( World.getObjectAt(castleLoc[target].x, castleLoc[target].y).getRuler().equals(ourKnights[0].getRuler()) ) {
			target = (target + 1) % castleLoc.length;
		}

		if( otherCastles != null && ourKnights != null ) {
			
			/*if (numKnights < 5) {
				for (i = 0; i < numKnights; i++ ) {
					if (rapeAndPillage(ourKnights[i]) == false)
						defendCastle(ourKnights[i], ourCastles[0]);
				}
			}
			else {*/
				for (i = 0; i < numCastles; i++) {
					if (rapeAndPillage(ourKnights[i]) == false)
						defendDefendPoint(ourKnights[i], i);
				}
				
				/*for (i = numCastles; i < numKnights * 75 / 100; i++ ) {
					if (rapeAndPillage(ourKnights[i]) == false)
						captureCastle(ourKnights[i], otherCastles[0]);
				}*/
				for( i = numCastles; i < numKnights; i++ ) {
					if (rapeAndPillage(ourKnights[i]) == false)
						captureCastle(ourKnights[i], (ICastle)World.getObjectAt(castleLoc[target].x, castleLoc[target].y) );
				}
				/*
				for (i = numKnights * 75 / 100 + 1; i < numKnights; i++ ) {
					if (rapeAndPillage(ourKnights[i]) == false)
						defendCastle(ourKnights[i], ourCastles[0]);
				}
			}*/
		}
		
		if ( ourPeasants != null ) {
			for (i = 0; i < numPeasants; i++) {
				movePeasant(ourPeasants[i]);
				//move( ourPeasants[i], (i + lastMoveTime) % 8 + 1);
			}
		}
		
		if ( ourCastles != null ) {
			for (i = 0; i < numCastles; i++) {
				if (numKnights < 25 || numPeasants > 30)
					createKnights(ourCastles[i]);
				else
					createPeasants(ourCastles[i]);
			}
		}
	}
	
	
	public boolean rapeAndPillage(IKnight knight) {
		int i, x, y;
		Point np;
		IObject whatsThere;
		int best = 0;
		IRuler me;
		
		me = knight.getRuler();
		
		for (i = 1; i < 9; i++) {
			np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);
			if (np != null) {
				whatsThere = World.getObjectAt(np.x, np.y);
				if (whatsThere != null && !whatsThere.getRuler().equals(me)) {
					//capture(knight, i);
					if (!(whatsThere instanceof IKnight)) {
						capture(knight, i);
						return true;
					}
					else {
						best = i;
					}
				}
			}
		}
		if (best != 0) {
			capture(knight, best);
			return true;
		}
		
		return false;
	}
	
	
	public void captureCastle(IKnight knight, ICastle castle) {
		int x, y, dir;
		Point np;
		
		x = castle.getX();
		y = castle.getY();
		
		dir = knight.getDirectionTo(x, y);
		if (knight.getDistanceTo(x, y) > 1) {
			np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
			if (np != null) {
				if (World.getObjectAt(np.x, np.y) != null) {
					//dir = (dir + 1) % 8 + 1;
					dir = rand.nextInt(8) + 1; 
				}
			}
			move(knight, dir);
		}
		else
			capture(knight, dir);
	}
	
	
	public void defendCastle(IKnight knight, ICastle castle) {
		int x, y, dir, dist;
		
		x = castle.getX();
		y = castle.getY();
				
		if (knight.getDistanceTo(x, y) > 2) {
			dir = knight.getDirectionTo(x, y);
			move(knight, dir);
		}
		else {
			// attack pattern delta
			move(knight, rand.nextInt(8) + 1);
		}
	}
	
	
	public void movePeasant(IPeasant p) {
		int i, j, dir;
		Point np;
		IRuler owner;
		IRuler me;
		
		me = p.getRuler();
		for (i = target; i < target + 8; i++) {
			j = i % 8 + 1;
			np = World.getPositionAfterMove(p.getX(), p.getY(), j);
			if (np != null) {
				owner = World.getLandOwner(np.x, np.y);
				if (owner == null || !owner.equals(me)) {
					if (World.getObjectAt(np.x, np.y) == null) {
						//dir = (dir + 1) % 8 + 1;
						//dir = rand.nextInt(8) + 1;
						move(p, j);
						return; 
					}
				}
			}
		}
		move( p, rand.nextInt(8) + 1);
	}
	
	
	public void defendDefendPoint(IKnight knight, int whichCastle) {
		int x, y, dir;
		Point np;
		
		x = castleDefendPoint[whichCastle].x;
		y = castleDefendPoint[whichCastle].y;
		
		if (knight.getDistanceTo(x, y) < 1) {
			return;
		}
		else {
			// move to defend point
			dir = knight.getDirectionTo(x, y);
			np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
			if (np != null) {
				if (World.getObjectAt(np.x, np.y) != null) {
					//dir = (dir + 1) % 8 + 1;
					dir = rand.nextInt(8) + 1; 
				}
			}
			move(knight, dir);
		}
	}
}