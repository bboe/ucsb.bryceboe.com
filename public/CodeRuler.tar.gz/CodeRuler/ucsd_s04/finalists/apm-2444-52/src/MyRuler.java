import com.ibm.ruler.*;
import java.util.*;
import java.awt.Point;



/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	 
	protected Random rand = new Random();
	private IPeasant otherPeasants[], peasants[] ;
	private IKnight otherKnights[], knights[] ;
	private ICastle otherCastles[], castles[] ;
	 
	public String getRulerName() {
		return "My Ruler 52";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 52";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		// put implementation here
	
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {
		

	   	
		knights = getKnights();
		peasants = getPeasants() ;
		castles = getCastles() 	;
		otherPeasants = World.getOtherPeasants() ;
		otherKnights = World.getOtherKnights() ;
		otherCastles = World.getOtherCastles() ;
		
		int i =0;
		int numCasLeng = 0;
		int numCas = castles.length;
		numCasLeng = numCas * 3;
				
		if (knights.length < numCasLeng ){
			numCasLeng = knights.length;
		
		}
		for (i=0; i< numCasLeng ; i++ ) {
			knightCapture(knights[i]) ;
		}
		
		int dir ;
		// knight 4 --> capture castle
				    	    
				//ICastle c = findNearestCastle(knights[i]) ;
				if ( otherCastles.length != 0 ) {
					
					dir = captureCastle( knights[i], otherCastles[ otherCastles.length - 1] ) ;
					if ( dir != 0 ) {
						for ( i = numCasLeng ; i < knights.length;  i++) {
							move( knights[i], dir );
						}
					}
				}
			
		for (i = 0 ; i < peasants.length ; i ++ ) {
			move( peasants[i], findUnoccupied( peasants[i] ) ) ;
		}
	    int h1=0; 
	    if (castles.length != 0){
	    	while (h1 < castles.length)
	    	{
	    		if ( (h1 % 2) == 0){
					createPeasants( castles[h1]) ;
	    		}
	    		else{
					createKnights(castles[h1]);
	    		}
	    		h1++;
	    	}
    	 }
	    
		if (knights.length > 14){
			for (int k = knights.length-1; k > knights.length-6 ; k-- ){
				IPeasant p = findNearestPeasant(knights[k],otherPeasants);
				protectPeasants(knights[k]);
			}
		}
	 
	}
	
	public int findUnoccupied(IPeasant p) {
		int nearestDistance = 1000 ;
		int x, y ;
		x = p.getX() ;
		y = p.getY() ;

		for ( int i = 1 ; i < 72; i++) {
			for ( int j = 1; j < 63; j++) {
				if (y == 63 )
					return rand.nextInt(8) + 1;
				
				if (x == 71)
					return rand.nextInt(8) + 1;
				if (  x-i >= 0 && y -j >= 0 && ( World.getLandOwner(x-i, y-j) == null 
				|| !World.getLandOwner(x-i, y-j).equals(p.getRuler()) ) 
				&&  World.getObjectAt(x-1, y-1) == null ) {
					return 8 ;
				}
				if ( x-i>=0 && ( World.getLandOwner(x-i, y)== null 
				|| !World.getLandOwner(x-i, y).equals(p.getRuler()) )
				&& World.getObjectAt(x-1,y) == null ) {
					return 7 ;
				}
				if ( y-j>=0 && ( World.getLandOwner(x, y-j) == null 
				|| !World.getLandOwner(x, y-j).equals(p.getRuler()) )  
				&& World.getObjectAt(x,y-1) == null ){
					return 1 ;
				}
				if ( x-i>=0 && y+j<=64 && ( World.getLandOwner(x-i, y+j) == null 
				|| !World.getLandOwner(x-i, y+j).equals(p.getRuler()) )
				&& World.getObjectAt(x-1,y+1) == null) {
					return 6 ;
				}
				if ( x+i<=72 && y-j >=0 && ( World.getLandOwner(x+i, y-j) == null 
				|| !World.getLandOwner(x+i, y-j).equals(p.getRuler())) 
				&& World.getObjectAt(x+1,y-1) == null) {
					return 2 ;
				}
				if ( x+i<=72 && y+j<=64 && ( World.getLandOwner(x+i, y+j) == null 
				|| !World.getLandOwner(x+i, y+j).equals(p.getRuler()) ) 
				&& World.getObjectAt(x+1,y+1) == null) {
					return 4 ;
				}	
				if ( y+j<=64 && ( World.getLandOwner(x, y+j) == null
				|| !World.getLandOwner(x, y+j).equals(p.getRuler()) ) 
				&& World.getObjectAt(x,y+1) == null) {
					return 5 ;
				}
				if ( x+i <= 72 && ( World.getLandOwner(x+i, y) == null
				|| !World.getLandOwner(x+i, y).equals(p.getRuler())) 
				&& World.getObjectAt(x+1,y) == null) {
					return 3 ;
				}																				
			}
		}
			
		return  rand.nextInt(8) + 1 ;
	}
	
	public ICastle findNearestCastle(IKnight k) {
		int nearestDistance = 1000 ;
		int x, y ;
		x = k.getX() ;
		y = k.getY() ;
		ICastle nearestCastle = null ;
		for ( int i = 0 ; i < otherCastles.length; i++ ) {
			if ( otherCastles[i].getDistanceTo(x,y) < nearestDistance )
				nearestDistance = otherCastles[i].getDistanceTo(x,y) ;
				nearestCastle = otherCastles[i] ;
		}
		return nearestCastle ;
		
	}
	
	public int captureCastle(IKnight k , ICastle c) {
			
		
		int dir = k.getDirectionTo(c.getX(), c.getY());
		Point np = World.getPositionAfterMove(k.getX(), k.getY(), dir);
		
		if (np != null) {
			// if the castle is in the adjacent square, capture it. Otherwise, try to keep moving
			if (c.equals(World.getObjectAt(np.x, np.y))){
				
				capture(k, dir);
				return 0;
			}
			else {
				if ( World.getObjectAt( np.x, np.y) == null )
					return dir;
				else
					return rand.nextInt(8) + 1 ;	
			}
					
		}	
		return 0;	
	}
	
	public void protectPeasants(IKnight k) {
		IPeasant p = findNearestPeasant(k, peasants ) ;
		if ( p != null ) {
		
			int dir = k.getDirectionTo( p.getX(), p.getY() ) ;
			move(k,dir);	
		}
	}
	
	public IPeasant findNearestPeasant(IKnight k , IPeasant[] ip ) {
		int nearestDistance = 1000 ;
		int x, y ;
		x = k.getX() ;
		y = k.getY() ;
		IPeasant nearestPeasant = null ;
		for ( int i = 0 ; i < ip.length; i++ ) {
			if ( ip[i].getDistanceTo(x,y) < nearestDistance )
				nearestDistance = ip[i].getDistanceTo(x,y) ;
				nearestPeasant = ip[i] ;
		}
		
		return nearestPeasant ;	
		
	}
	
	public void moveAndCapture(IKnight knight, IPeasant peasant) {
		// return if the peasant is null or has already been captured
		if (peasant == null || !peasant.isAlive())
			return;
	
		// find the next position in the direction of the peasant
		int dir = knight.getDirectionTo(peasant.getX(), peasant.getY());
		Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), dir);
		if (np != null) {
			// if the peasant is in the adjacent square, capture it. Otherwise, try to keep moving
			if (peasant.equals(World.getObjectAt(np.x, np.y)))
				capture(knight, dir);
			else
				move(knight, dir);
		}
	}
	
	public boolean knightCapture(IKnight knight) {
		for (int i = 1; i < 9; i++) {
			// find the position
			Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i);

			// make sure the position is a valid move
			if (np != null) {
				IObject object = World.getObjectAt(np.x, np.y);
				if (object != null && !object.getRuler().equals(knight.getRuler())) {
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}


}