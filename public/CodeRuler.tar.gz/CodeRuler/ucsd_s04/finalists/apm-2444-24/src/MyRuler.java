import com.ibm.ruler.*;
import java.awt.*;
import java.util.*;

/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "AW URBASE R BLONG 2 UZ";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "Team 24";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		knights = getKnights();
		nearestCastle = getNearestCastle(knights[0]);
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	 IKnight [] knights;
	 IPeasant [] peasants;
	 ICastle []  castles;
	 ICastle nearestCastle;
	 ICastle nearestCastle2;
	 ICastle niceCastle;	
	  
	public void orderSubjects(int lastMoveTime) {
		
		turncount++;
		if (turncount % 5 == 0) castleProduction();
		knights = getKnights();
		midknight = knights.length / 2;
		
		int turning;
		if (knights.length < 15) turning = 50;
		else turning = 15;
		if (turncount % turning == 0) nearestCastle = getNearestCastle(knights[0]);
		
		nearestCastle2 = nearestCastle;
		if (turncount % turning == 0) if (knights.length > 20) nearestCastle2 = getNearestCastle(knights[knights.length - 1]);	
		
		peasants = getPeasants();
		niceCastle = getFarthestCastle((IPeasant) peasants[0]);			
		castles = getCastles();
		//randomWalk(knights);
		randomWalk(peasants);
		knightWalk(knights);


		// put implementation here
	}
	
	int turncount;
	
	int midknight;
	
	public void castleProduction () {
		int size = castles.length;
		for (int i = 0; i < size; i++) {
			if (knights.length * 2 < peasants.length) createKnights (castles[i]);
			else createPeasants(castles[i]);
		}
		
	}
	
	protected Random rand = new Random ();
	public void randomWalk(IObject[] peasantknight)
	{
	
		int size = peasantknight.length;
		Point testpoint = null;
		int direction;
		int j, i, randdir, thedirection;
		IRuler tempowner;
		boolean flag;
		for (i = 0; i < size; i++) {
			if (peasantknight[i] instanceof IPeasant) {
				testpoint = null;
				//int direction;
				//int j;
				//IRuler tempowner;
				flag = false;
				
				randdir = rand.nextInt(8);
				//int thedirection;
				for (j = 0; j < 8; j++) {

					thedirection = (j + randdir) % 8 + 1;
					testpoint = World.getPositionAfterMove(peasantknight[i].getX(), 
												peasantknight[i].getY(), thedirection);
												
					if (testpoint != null)
						tempowner = World.getLandOwner ((int) testpoint.getX(), (int) testpoint.getY());
					else tempowner = null;
					
					
					if (testpoint != null) {
						if (tempowner == null || !tempowner.getSchoolName().equals("Team 24")) {
							if (World.getObjectAt(testpoint.x, testpoint.y) == null) {									
								move((IPeasant)peasantknight[i], thedirection);
								flag = true;
								break;				 
							}
						}
					}
				}
				if (!flag) {
					 niceCastle = getFarthestCastle((IPeasant) peasantknight[i]);
					 if (niceCastle != null )
					 	move((IPeasant)peasantknight[i], peasantknight[i].getDirectionTo(niceCastle.getX(), niceCastle.getY()));
					 else move ((IPeasant)peasantknight[i], rand.nextInt(8)+ 1);
				} 
			}
			else {
			
				if (!knightCapture ((IKnight) peasantknight[i]))		
				move ((IKnight)peasantknight[i], rand.nextInt(8)+ 1);
			
			}
		}
	}
	
	public void knightWalk (IKnight [] knights) {
	
		int size = knights.length;
		Point testpoint;	
	
		
		int getx = 0, gety = 0;

		if (nearestCastle != null) {
		
			getx = nearestCastle.getX();
			gety = nearestCastle.getY();
			
		}
			
		for (int i = 0; i < size; i++) {
			
			//if (i > midknight) nearestCastle = nearestCastle2;
			
			if (!knightCapture ((IKnight) knights[i])) {
				if (nearestCastle != null) {
				
					testpoint = World.getPositionAfterMove(knights[i].getX(), 
												knights[i].getY(), knights[i].getDirectionTo(getx, gety));
																	
					if (World.getObjectAt(testpoint.x, testpoint.y) == null)	
						move ((IKnight)knights[i], knights[i].getDirectionTo(getx, gety));
					else {
						moveToward((IKnight)knights[i], knights[i].getDirectionTo(getx,gety));
						//move ((IKnight)knights[i], knights[i].getDirectionTo(getx, gety));
					}
				}
				else move ((IKnight)knights[i], rand.nextInt(8)+1);
			}	
		}
	}
	public void moveToward(IKnight knight, int dir)
	{
		int temp;
		Point nextSpot;
		int getx = knight.getX();
		int gety = knight.getY();
		temp = (dir + 8 - 1) % 8;
		if ((nextSpot = World.getPositionAfterMove(getx, gety, temp)) != null) {
		
			move(knight, temp); 
			return;
		}
		temp = (dir + 8 + 1) % 8;
		if ((nextSpot = World.getPositionAfterMove(getx, gety, temp)) != null) {

			move(knight, temp);
			return;
			
		}
		temp = (dir + 8 + 2) % 8;
		if ((nextSpot = World.getPositionAfterMove(getx, gety, temp)) != null) {
		
			move(knight, temp);
			return;
		}
		temp = (dir + 8 - 2) % 8;
		if ((nextSpot = World.getPositionAfterMove(getx, gety, temp)) != null) {
		
			move(knight, temp);
			return;
		}			
	}
	
	public ICastle getNearestCastle (IKnight knight) {
		ICastle nearestCastle = null;
		ICastle [] otherCastles = World.getOtherCastles();
		int distance = Integer.MAX_VALUE;
		int size = otherCastles.length;
		int getx=0, gety=0, dis;
		for (int i = 0; i < size; i++) {
			getx = otherCastles[i].getX();
			gety = otherCastles[i].getY();
			if (distance > (dis = knight.getDistanceTo(getx, gety)))
			{
				distance = dis;
				nearestCastle = otherCastles[i];
			}
		}
		return nearestCastle;
		
	}

	public ICastle getFarthestCastle (IPeasant peasant) {
		ICastle farthestCastle = null;
		ICastle [] otherCastles = World.getOtherCastles();
		int distance = Integer.MIN_VALUE;
		int size = otherCastles.length;
		int getx, gety, dis;
		for (int i = 0; i < size; i++) {
			getx = otherCastles[i].getX();
			gety = otherCastles[i].getY();
			if (distance < (dis = peasant.getDistanceTo(getx, gety)))
			{
				distance = dis;
				farthestCastle = otherCastles[i];
			}
		}
		return farthestCastle;
		
	}	
	
	public boolean knightCapture(IKnight knight)
	{
	    IObject object=null;
	    Point np = null;
	    int getx = knight.getX();
	    int gety = knight.getY();
		for (int i = 1; i < 9; i++)
		{
			np = World.getPositionAfterMove(getx, gety, i);
			//valid move?
			if (np != null)
			{
				object = World.getObjectAt(np.x, np.y);
				if (object != null && !object.getRuler().equals(knight.getRuler()))
				{
					capture(knight, i);
					return true;
				}
			}
		}
		return false;
	}
	/*
	public void checkCastles()
	{
		ICastle [] ours = getCastles();
		for (int i = 0; i < ours.length; i ++)
			for (int j = 1; j < 9; j++)
			{
				if 
				
			}
		
		
		
	}
	*/
	
	
	
	
}