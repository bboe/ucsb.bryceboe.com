package com.ibm.ruler;
/**
 * This interface is implemented by all castles. It does not define any new methods. See the IObject
 * interface for information on inherited methods.
 */
public interface ICastle extends IObject {
}