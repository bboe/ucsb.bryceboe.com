import java.awt.Point;
import java.util.*;

import com.ibm.ruler.*;
/**
 * This is the class that you must implement to enable your ruler within
 * the CodeRuler environment. Adding code to these methods will give your ruler
 * its personality and allow it to compete.
 */
public class MyRuler extends Ruler {
	private Random rand = new Random();
	private IObject offensiveTarget;
	private ArrayList aKnights;
	private boolean done = false;

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getRulerName()
	 */
	public String getRulerName() {
		return "Champ6660";
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#getSchoolName()
	 */
	public String getSchoolName() {
		return "TEAM 2";
	}
	
	public IObject findTarget(IObject object1) {
		IObject return1 = null;
		ICastle[] otherCastles = World.getOtherCastles();
		IKnight[] otherKnights = World.getOtherKnights();
		IPeasant[] otherPeasant = World.getOtherPeasants();
		ArrayList objects = new ArrayList();
		for (int i = 0; i < otherCastles.length; i++)
		{
			objects.add(otherCastles[i]);
		}
		for (int i = 0; i < otherKnights.length; i++)
		{
			objects.add(otherKnights[i]);
		}
		for (int i = 0; i < otherPeasant.length; i++)
		{
			objects.add(otherPeasant[i]);
		}
		
		IObject[] otherObjects = new IObject[objects.size()];
		for (int i = 0; i < otherObjects.length; i++)
		{
			otherObjects[i] = (IObject)objects.get(i);
		}
		
		if (otherObjects.length != 0) {
			IObject ourObject = object1;
			int min = 10000;
			int result = 0;
			for (int i = 0; i < otherObjects.length; i++)
			{
				int distance = ourObject.getDistanceTo(otherObjects[i].getX(), otherObjects[i].getY());
				if (distance < min)
				{
					min = distance;
					result = i;
				}
			}
			return1 = otherObjects[result];
		}
		return return1;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#initialize()
	 */
	public void initialize() {
		aKnights = new ArrayList();
		IKnight[] knights = this.getKnights();
		boolean isOffensive = true;
		OurKnight defensive = new OurKnight(knights[0], false);
		ICastle ourCastle = this.getCastles()[0];
		int castleX = ourCastle.getX();
		int castleY = ourCastle.getY();
		defensive.setDefensePosition(castleX+1, castleY);
		
		
		defensive = new OurKnight(knights[1], false);
		defensive.setDefensePosition(castleX, castleY+1);
		aKnights.add(defensive);
		
		defensive = new OurKnight(knights[2], false);
		defensive.setDefensePosition(castleX, castleY-1);
		aKnights.add(defensive);
		
		defensive = new OurKnight(knights[3], false);
		defensive.setDefensePosition(castleX-1, castleY);
		aKnights.add(defensive);
		
		for (int i = 4; i < knights.length; i++)
		{
				aKnights.add(new OurKnight(knights[i], true));
		}
		
		ICastle[] otherCastles = World.getOtherCastles();
		
		int min = 10000;
		int result = 0;
		for (int i = 0; i < otherCastles.length; i++)
		{
			int distance = ourCastle.getDistanceTo(otherCastles[i].getX(), otherCastles[i].getY());
			if (distance < min)
			{
				min = distance;
				result = i;
			}
		}
		ICastle closestCastle = otherCastles[result];
		for (int i = 0; i < aKnights.size(); i++)
		{
			((OurKnight)aKnights.get(i)).setTarget(closestCastle);
			
		}		
	}
	
	public boolean canMove(IObject object, int direction)
		{
		Point p = World.getPositionAfterMove(object.getX(), object.getY(), direction);
		if (p != null)
		{
			IObject object1 = World.getObjectAt(p.x, p.y); 
			if (object1 == null) 
			{  
				return true; 
			} 
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.ibm.ruler.Ruler#orderSubjects(int)
	 */
	public void orderSubjects(int lastMoveTime) {	
		
		// move the knights
/*		for (int i = 0; i < aKnights.size(); i++)
		{
			OurKnight temp = ((OurKnight)aKnights.get(i));
			if(!temp.isAlive())
				aKnights.remove(i--);
			else
				temp.ourMove();				
		}*/
		
		// check if there are new knights
		IKnight[] knights = getKnights();
		for (int i = 0; i < knights.length; i++)
		{
			if (!aKnights.contains(knights[i]))
			{
				OurKnight temp = new OurKnight(knights[i],findTarget(knights[i]) ,true);
				aKnights.add(temp);
				temp.ourMove();
			}
		}		
		IPeasant[] peasants = getPeasants(); 
		for (int i = 0; i < peasants.length; i++) 
		{ 
			int direction = validSquare(peasants[i]);
			if (direction == -1)
				move(peasants[i], rand.nextInt(8) + 1);
			else
				move(peasants[i], direction);
		}
		
		ICastle[] test = getCastles();
		for (int i = 0; i < test.length; i++)
		{
			createKnights(test[i]);			
		}		
	}
	
	
	/**
	 * @param peasant
	 * @return
	 */
	private int validSquare(IPeasant peasant) {
		int toReturn = -1;
		for (int i = 1; i < 9; i++)
		{
			

			Point p = World.getPositionAfterMove(peasant.getX(), peasant.getY(), i);
			
			if (p != null)
			{
				IRuler blah = World.getLandOwner(p.x, p.y);
				if (blah != null)
				{
					if (!blah.equals(this))
						return i;
				}
				else
					return i;
			}

		}
		return toReturn;
	}


	class OurKnight
	{
		private IKnight theKnight;
		private IObject target;
		private boolean isOffensive;
		private int x;
		private int y;
		
		OurKnight (IKnight theKnight, IObject target, boolean isOffensive)
		{
			this.theKnight = theKnight;
			this.target = target;
			this.isOffensive = isOffensive;
		}
		
		/**
		 * @param knight
		 * @param b
		 */
		public OurKnight(IKnight theKnight, boolean isOffensive) {
			
			this.theKnight = theKnight;
			this.isOffensive = isOffensive;
		}
		
		public boolean isAlive ()
		{
			return theKnight.isAlive();
		}

		/**
		 * @return Returns the isOffensive.
		 */
		public boolean isOffensive() {
			return isOffensive;
		}
		/**
		 * @param isOffensive The isOffensive to set.
		 */
		public void setOffensive(boolean isOffensive) {
			this.isOffensive = isOffensive;
		}
		/**
		 * @return Returns the target.
		 */
		public IObject getTarget() {
			return target;
		}
		/**
		 * @param target The target to set.
		 */
		public void setTarget(IObject target) {
			this.target = target;
		}
		
		public void setDefensePosition(int x, int y)
		{
			this.x = x;
			this.y = y;
		}
		
		public void ourMove ()
		{
			if (target == null)
				return;
			if (isOffensive)
			{
				if (target.isAlive() && !(target.getRuler().equals(theKnight.getRuler())))
				{
					// Do offensive stuff
					// check if can attack around, and do so if able
					if (!knightCapture(theKnight))
					{
						// nothing around, on to the target
						int wayToMove = theKnight.getDirectionTo(target.getX(), target.getY());
						if (!canMove(theKnight, wayToMove)) {
							wayToMove++;
							if (!canMove(theKnight, wayToMove))
								wayToMove-=2;
						}						
						move(theKnight, wayToMove);
					}
				}
				else {
					target = findTarget(theKnight);
					ourMove();
				}
			}
			//defense
			else
			{
				if(!knightCapture(theKnight))
				{
					if ((theKnight.getX() == x) && (theKnight.getY() == y) )
					{
						return;
					}
					
					
					int direction = theKnight.getDirectionTo(x, y);
					// nothing around, defend your position!
					if (canMove(theKnight, direction))
					{
						move(theKnight, direction);
					}
					else
					{
						direction++;
						if (canMove(theKnight, direction))
							move(theKnight, direction);
						else
						{
							direction -= 2;
							move(theKnight, direction);
						}
					}
				}
			}
			
		}
		
		public boolean knightCapture(IKnight knight) { 
			for (int i = 1; i < 9; i++) 
			{ 
				// find the position 
				Point np = World.getPositionAfterMove(knight.getX(), knight.getY(), i); 
				// make sure the position is a valid move 
				if (np != null) 
				{ 
					IObject object = World.getObjectAt(np.x, np.y); 
					if (object != null && !object.getRuler().equals(knight.getRuler())) 
					{ 
						capture(knight, i); 
						return true; 
					} 	
				} 
			} 
			return false; 
		}
	}
}

